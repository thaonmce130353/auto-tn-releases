(function () {
    'use strict';

    const CURRENT_AUTO_VERSION = "1.0.0";
    // build-content.js --release đổi false -> true (string-replace đúng dòng này) cho bản "khách hàng" (rút gọn): ẩn mục
    // "📜 Log chi tiết" + bảng công cụ log đã lưu khỏi HUD. Bản "quản trị" (đầy đủ, --release KHÔNG bật) giữ nguyên false.
    const TN_RELEASE_BUILD = true;
    // build-content.js đổi false -> true cho build CÓ bản quyền (iPhone, hoặc PC --licensed). Bản PC dev của chủ sở hữu (extension/content.js)
    // giữ false: không có vỏ bản quyền, hộp "Bản quyền" ẩn. HUD dùng cờ này (không dùng TN_IS_PHONE) cho mọi thứ liên quan bản quyền.
    const TN_LICENSED = true;

    if (window.__TN_AUTO_INITIALIZED__) {
        return;
    }
    window.__TN_AUTO_INITIALIZED__ = true;

    const APP_ICON_B64 = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAALQAAAC0CAMAAAAKE/YAAAADAFBMVEUAAAD39v15gMIiE1k1MneSfNQeHIAzKpKXlq2NiaCBfZXo09qhnbC6JB7Ld/iyvdeDfJRdWnC9yeO7zeqNfJM4LUUxJDmlqcBSSV+pPEWskpXj//+njZHc/v+GeIvDwNOwlZhuYHOiiIu3nqElGCxuZn14b4IyIjWzmZ18dYqBcYTr//+PiZ+lobmemrXJxtmzscmzrcCThJdmWGy5o6WKhJqph4j+//+MfpGFfpOqp76EWmJ3aXunnbC5t86blq2FaXhcT2aZjJ6tjI5iWnW7u9nDpKsXDSNVRWC+naa6tMWckqWMi66kgYGbgoaHh6aUe4LAucyTjqVKP1c5LECLbISkhaB/eZLE4vnV0uSjpMqSkbiegJqimKqeoMDP6/yDf5z0///LyeKdeXoLAg1zbourrdCvpbfY2Ot+UlmXl8BNKzR0QUp4eKB3dpZhXIJDNku9n7CWkKt0WWXSzN1/f6VsTlckHz6AW3DAw+GafJNqZIpWT3Systbh4vHI0O20lqusqsWUdYqLdHvR/f8mDxleNT6Umsy03Pd8ZG6kqNaMaGursd+okKSSlrO2uuOwvfOBg6/D0vrs7vqyzPmLksW1jqOVcXRgQk2htem+AgN/YHyHirg5GyTBwPBvbpfV2PqkdouVqeKyz+iYodc0Ll2vhJzg6vxyTmnIAwOsf5NKRGy0+PuOeaTBqrdNT4mYV2twcrBdxO6da3+GR1Tk2OiJndiex+6FbJfTAgKyAwPv4PClAwOT9vl35/Wkl8mXjOLIrr/hAwPks/piY5ViiOutxtU5RqjVnPjPu8xZct+8n73ppg2WAwO7lvOmm+xaV6VdoOZ+vuxOW/A1gum/md5xY8yZg7utcHEnUdVeVr0wauFBUM2ftsuAnvC4gn1Boenhwch1jtf4tAutd/B5cOokKNL6yPzUPwYWIqlfJZ3YmA9fccR7Q6DFlI+OXqnJsKQlTvOFPc1eKn7xxQ/ZaQmDbMmnXuTmuBCpPUb30A7yXeD/0QyDICj25RD/9A6Kws62AAAAGnRSTlMA/v7+/f77/i3y7/7x/Pxgw16Iv4ia28nYscm1aeQAAFm0SURBVHjanNhbbCJlFAfwtb5oY+M1MVo77LTO6EyZ4TKiwA6MMw4JKSgCKhTksihQ0WLFbSNul4qrwtYupZSq1LVbWxOs9yZabF01aZo+1Rdf9GVf9GXjZqNRN1mNt/MNtF01Xg/MMNB9+OW/5zvzwZ5/qosuveKKK6/Mmy+55OKLL2EYRquy6uDNJTohy4g4zl+C6XVJvXixmcBF4mIjRmK4Xebxiy9pp9rZiy/WmEm5/WK7VxyS2+3t7RcH44E0GS61UxfHqWDKWQo729NtqIpv1Gr+uYUrr7ji0kv3/P8C8BVX9mtUVjMreAwGk8fjsDBmhhXUFI8x7GTWjmNqHW1U9SU56YDo5QwOihNFnBZxjlNTRkxgfZoDBE85uCHRS3i8Lka8KxjMJGRPwJlxOYloKuUqlYajx8C8vPJGsVatTDYac9VqPXfFRf9XfHV23mbWMp4Mk9e6rVarG0K2CAIjOCSBDWR5OuQI0ZLGmnyUd3OcI2TCRRzy5jk7TpA0acibLNMGHveQXlGMO4YMjNcr42yCdUYTTlbtKlHOVNDFOtPOcaRuQNSVudqHjXKxuD/SWPwf7kuv7KqfHMtbVFaBsapUGo3b3afV6kJqg4E0SgY2bDNhFqOe9tiybtzeR+NmgRB5EsdFUeTtHM2TZIb19ffhvMljt8s+4a5ofshOEBTvsQVd+UQ0QDlLvqDT5UpFqcQryyjqarlaKTc+rfmLXb2TxeLilZf+R/JY4403Fs19MTMT69do86grMkaTwRBy8JiJMmvNGb2B0ustw7YB45BFRZkdOG+U1AYThXtxwkvSBJUxsf0mkhQIu+hj7T6d107gFCl6zdnhsM3pZIngcDwYjQZT6ehcAdSNSLVWqa00yv5isXcezuD+9+yLrk7NzS981LDqVFqtSqWy5hFZzSaToVAISzI4a2VYB0YKjqScmrYMGXIY4+BpyWLAMGgLQsRFWIomg8+q43mPwc7FWY6w2u2ETPIiVCw/nAinwwYiHE+7os6SMx2ea1OiXqjUFhq14hvFp7oqfj+g/3XaV2yeDMwnFj4sjtnMKlueZYMZz5tvWnSoLKTFzFlgaZpNvCCE7Klp6wvEAGVIErQlxMMy5DgOJzjOzvOUz6Az8eoMxxEZUjRzXpwjYbDEZa8hNhxMRIdZYjAsxqOuYGkwPTm53NbW8NfKoK5V/UU/QoN5cXPxyn8V88vv/NAB9cPnr1mLk4kEk8moM1q3TpvPaxlaZ+VCKrdWp8cFxiIW6mM8F1N7LJxBZ+BgAgIZDrQUaZLyqEmfQIlyVG2HxcjhNAxFDOcIL5NwJZwPBz2jzugQ5YTGTk/NTSxD1Kg/GhC13/9UJBIpgnlzc3HzH8O+9POOWag1eK6tnfhcWwuzAqtS5XUwoLUC1qch1G6rRhviBG1S/niukhFtNoee85j1uEIGNDpEjidNaopWq3EiLuBxg13kwEwa0R+98awrFSDSpYcfDstedTCViQ4WUFs3irW5aqNRrhYjT0Xm/X4wowpf8ffmq5aWEFghI/WJdyYnbDGzwGhjVkbSq1Q+k0rbrzHjaquWTM3NZSlPVstzgtmA8yStBM0DGxqFI00mklBTMPJMnIezcyS0B4aLHC6LdkZwJqJyyjA6yA6JbLgUnZoaL88srxRrY5VqteyvRrqKlUpkbHPz5Oam2eO++u/M1ywh8C4a2D9bIyyj1cTMZof+gEptcmtVOavJYFUZnJW5OmtgVRwumNU4FI3x0NKghgK0z4eTBpKnBM4AQxA+JaGnORz+iZdinOMlOc0So6X4XaZU0DB8rDAx0bZcbEz6q9WKv1rs9PvHin4wa08KarP7sr8e2h075o5TTfMnUEf9VqsmIzBSv8oj6DTa6WxGrdWwU3NzdZunFKMh5xAngpXjMRjUiMeDnaIo3OTjcYHGjMiM/oEdBguUXZbU4QAhh9WjB1nRy36cSQcL47XxjYXqRKRajRSL1a6uyNji2NimVcsAWqW+5K/UHbM7OZ89vbY2u3YCmU/M6hZtlNqGzHlLv3lgoFTKq7TB7NxAXRdV6UTBzPB2UVSWIEah5lDQNEbyJoo3GXg9LE0eP8JxIyOPinbR7rXbMXU44ROjDDU6aLiLCqSgqSdemSgsF8vzxWqkWmz4OwG9qKBLJavKw7Rf9He9sYTQp7+fhdZA5LXZpaXFKXXMcUCj15oPqMwX5MM2mypsGxuYjrEZN2fImykwQz0KaprGFTaHkxhP+kjegJoG548cER99dORRu10EtHeINJQOlUQ57Bl92MOJwY8zx6cmJgqTbZ9WK5FqpFytVjsj84uL8wOb1pPhsMbNsmT7X5qXoJB868dTrZiXVlfXf1iJCaqY3mrty2kHVPmxrEZ7qH8sN+2Oqxy4VmuAmGFAg/oIjiM1T4OThqFH8RhG04/iR5AZSrSPjIy88MzQXaIpaguQ9rTZNHrc4PV9zA5uzMzNFMZXGpBzV7kBS7GO0P5NWIvhfoYRKOqyP5svRxEvNdFrp77//mwzZiCvr68+Mm7VGK2xvvc0fdPWgVhMo9JA0DmP5wAv2EIghsLhePRWHsdonudBTpIkTd+K0dgRVIjMjdiB/MIzzzwz5KXTAVtUlFmBeNglyh87XYODsBInJhbKkWK93ChW/fV6sTI/ls1ubmb7Wbc6aqKu+tM95YdVIG8Hffb7rdPIvKSQV5c6/BpKG4u5p80D/QO5mDsWyw7kpjW8JsTbdPwIeHCoI/C89VbeCOrDNE/DEzt8GDsMn93aZI8gM1I/eBducNkyshhn9Q+no3YY1cGNY3OFmcmVRqQ4X4OVWKxPA7oyMDa2OK3J97lcoL78D+j2jia52SNbW6fPdZxoxbwKnz1y3BzrT743oJuO5WIHVDHNQC53gcPYTwtW/QhwjmwXCGkjDScUM5jvvPMwmLfZI002oEV1Om8m7QTrIQ6WxIMTztLgxsRk20RtAWbdAvR0cb63WKn7I/A2Z9WES04XuP9wU3lnhwzd0XHu9OlzZ2d3yGtrD43H+hnLLVqw9ve7+2PZHCTO97lptwUsgAZsqyBcjD58GMyH7zx8J6CVAjpCK2xAD3mxdMkahX122HPQ5ZNTQWfw7TbU1ZDyHKArxcq0P9Lpj0T8uWw2W4IKl0qX/a45Bn9YXVo6dfaUUh1nT58+vbV1arvgxvhDJWbGpmO6C3ID/X2qmG0gZ51+ix8Ihdx3PnDkUXiA+vBuYXcDGMTbhdBIDWxUKGrO50yoZVF2sr7BEnH842Dw+Abqath7TNS20XW0B8kt+k9CwYIMs+fPvcvSHQi99cv3UOfOKeYvf/rppx+///6X78+eOPHJCU2e77uA6a/Pj7l1A5psTqOZvjN0QFKF9u3bh8RQLfAu9Y474IlKcQN7p0NAbfe5wkxc5OIpIRqmDgaDqamNtrm28YmVxivNpOtFGNZdXdMRuJ0vQm2ePBm+5LzJ4YsjNCzAH2EFQiEzqq2t70+vfYLQj6elAZu1HptXhWIxVX9OO913RNMX0ihBgxdp4dHCKtxueOlG1XSjtAG90yB8sMT4ZI4IJnzBUtw5HExtbEwW2uZWFlYA7UfoSD3S2dv5VMQPVYTdE7B3J0g7BWhYgCjsVsxN8zkUMzKvPZbuy+Vj/WP9R/s0blVOpf1AT8estuSRZ48cUdK9Dw44ITLyboPPUwN6Z4bA1ONKTjYjE3I8lXEFosHhwcDw2zNzy+MTbSs1tP2odBU7I5He/V1dT0GPFAENJZh2OpqiKNh2LMGa++STs+e2dmPe6miaZ5eed6oO2fpt8zpHTKs9kDMPaHhHzKbq3vfss614my3xe+118FDU3fDn36uH7GpnhpEJTi6ZXYmoK7xxLPD28lzh2MTMFw2E9keKnWDu7OwENqzHRdhZs6Tv8u2OJklibQkKbtyg3o4Z5t5a07y0vvpYeCxgU8ViklanhbuiOXeUZMayOiAfVqw7dXt398074uvgvBM2oJG6hX7B63NGzQQhy9GAIZGKJoY3EsPL4+NT4wttCwraD91xS29vL2IDGppaICmSbAVNElSpA2IG8gnY2Z39qWk+B2akXltaX5/FDh2yWfOxpENn1lljmYEDpDof0zyBzMA5nwwFbngAGgrOu2pl8DXVI17SGdX6ZEIkEqXMpIsJbjgTG1PjMzO1L1bK86irn6pPd3Yq5qf8RTB7SJJ0OZtRX+VTsyd/gJgV8+zqFqAhZlB3rAEaxvXq7M/hQwGrWWu1WEIWXYxhcg5M0Mb6up/dThm5bkfnbTUi79bvowY1oAk2rTWg/nCGPdkSGx7eyE8tpwJt5YWFhUgZkq5HenfNm1o1RVIuV2sLcrEgGIb3bW/pVtd/QimjzoZV2DSvffJuIZhl2Lw5GVJbtLbMATcmCTGr5c7nd7pYyXj79bqbkfRaeNlVA3pHjdBDOENkPLASR+Nm1lZy2lJvDweWlwMzC9WFhXKlXK0DGgrGhx++wuTVpni6FCXIuNIdmaiPikYVMwjXz/6IVuDp71F/nIB2Xl+Frn45ZU54BHPSojclbUyyH/1eE9OFngcIGhWtdFtuMCLyva3XbXRLrUSN0DLDRVmZlEflDHso7LSVNjZShY3gK4XKK7WFSnnuAjCj6vIvgrnkSmdYiqCo+OVKd/h8JtOxd080zetb57Z+3FqCPdO50+dOzSrm2Y6pjDXlcDA6CZPMNrUqaQxRVm0SoUHcooIaPa5rqXvuvrtHMV97bUt9/gSB9pAZe5ohCByiFg4dcoZdw8eHExB1obpQKNf8FX/nfsUcyaLtKXwVyKcpE9Xcol7mM0WjpmEatQYQT537/sezaBdyagsu1teXPvlkdvWdQUsiI4WSFox2ZAWPBnMY2VhSdyPM5W10K8/ddPc+effe5vVu1k10q0FkwRsHNMwPWZ3PuoIp1/GNQGHj40KtNlNbmI9UwQw9HRlD6JNhq82VZkrpaLod0O2+qMnkM838sAoFCf/65aklKNglnf71y/VZGNKrHcelvpResiT1JMbYjFbJ6FBbrVLftfehht4m73rhjA7gQimXLTWKWtnxKWiP92GWIHhOHqVYmzOQiB48Hp5YTn1cq84UyuVIpd6cdmNj6Ba+qWyanC6oi/ZcpKUg6KirNDW7DtbVH7fADhdojpz98RQM6aV148G3GI9eYiwYZrSpQ31kyGhWWYzu65AZNcYuFynhvHsNz5Z5J2pQIzQheeWMHCc5+XU5k0+lxp3HB1PZtqnARHWlba48X5/fD+Y63MRBvTh2ElUJ1aV7Lo0J8ajBo6bSJGBXT51FgYMZTWd4h74HvLaB6TIZTM9ImNHBSG5aCmF97qP6PmDsBI14ykmh3qag917brN0Bct7OyU5g3lGPgh61q/P50tS4ayNsKywHDpUX2rLz5c55iBrQcGMp+gcgbfQjCJJfsefSsazPpzbBDJy5e3UdPQANvbHaXILw5vMZMenIQEsI0p1YXp0MkUkjq0l2H9U190SgAWAz1laB+bbbrv36HlC36k9Roy879lFWJOKwEr0Uo00NToRHE+FA20xiorFy8oLyfASi7urqArQ/UoHNR6uKV+65SltXkSRBqj30xq3rUMiszJElZUivv3uM0CfVHqPeIVkOS4Kk46UQrVF13xlKAnpn6W3X3r17Wy3Sc+bxHnQNf2stxp1ZzQOa5l+wjzKiTBGoP1hreHA8+3AgFSy0fTxZXPli/3y5Pt/ZuoejHkE//SrHG/49l0Wt0wxnUvt40hB2/QBq1M7wMqsM6Q56ykBapIyH1kshiWcNST0VwoT+o892H7Xsone8cNwIL0i698zXN8FVdzPp3aXYupljRwDNAprER0ftHm1ieaZ+PDg+PA7o6soX/lvKsPnY3wtotGFSCr7HPPXUU125PZfF49YcQ1E+dUaiiY196Fcm1BprJ2bXVzveGT6IGfUhNfw/SNDJRk8oSUqSUet+ft91R0N3AENBt8hIDLX3xu7uHvjk66/B3333jXt/P6ux5sbaNDJilwW77PMR4qg3ak4sH+tlhycGA22FyWrti09vgd/VAa1kjdzNgqvOC/a0R9NpVS5j8hgogiPIgwcffReGH7TGWscPD8TTJCdh+pDHg9FHHXraoU8aMQg6r9u3r9tx9I7zW0Mht6rnxW549/W39/b0PPkixA11/qimYSXy2Asj4kH1EELLsvcgk1gu1APDk8NB+E5ebays1G8pVyK9SI3YrUIX+wENX3KjqpxA4DhB0nCWh0+a7r717rtfjD8cx0mOBqoj48GMksNoNFpChF5vMGuvfWhf99Gj3dd276ABDOgeVDfe+M2LL36z97ozX53pQVfX7qJboxqSpukHX+DS2F2yz0TJ8pDI2qYKcx87J2dgozdRXaytFCHq5k0RoeGJHlC9t1ywh027XGmfaiBD8EYMzDgnCem0q3QcZhHPE5yEGy16T1SPSRJkbsFMEuzv3M8+tO+OkNR97Q4ZvErESsHrq69989mZC7/6+pv3H+/549RT0Jj49Au4gb9LpqI+GB9ez6FjM5PZ1ERhKjAzXl1sfNrY31utov44P2vA77+ld09MG6dMJGHNmU2IjBN8KIphJhPP4wSH80aeCDkkg1rCQwaJDhkpyehhzDc98MC+bgugd8woZHje1AMHXH1z98t7z5z57qszzz2poH+316Npmue56+9/hjDgQ0206PUlZmamp1MLK8dShVcqi41GoxeirmyjFTA69u/v7drTrtKSeFyWdbk+Ew5K3GQhjej3cJ5TfrsVJYfeoxZo2iJJT0qkXsIygvuOhx7Yd12yG6F3urkHeVEp8Hue7H7xzFdf3dhz5sk/ozH6Ue6u++9/kDSIQ0TcFyVGZS9xaCZwy8DMK4WUs/BKtVhrlOu3dMLvkIp6t6l7e+FyDyELKrUMEYf6NR4SXh0CQuM4KYtGiRMpC2w0BCMtOaA9KCzEq1k2+SxKGsa0MoMVMkoZzK0C9Hd37D0D3XH0u+v2no8GMwbmB1+44en77zKpvV4innZRgJYPHdu8RTPzykpgqjBRrjYWy/P79/vLkd+jlQtIGuM9Vp0BB57uQJ+J5i0SZcQonsRFzMHZySRmtLgypN7okI4SpBTCLULfHWB+9k6UNCplXuzG3Dx/8913PYe/+/qbr8/AOvwD+taRl4a8gH7BYBpC6KhvdNQrHiqcvCU7U3hl/NixyXJjUUF3Viu9qM6fHgj9G9vm9tNmGcdxMEuMzr9gQKFK63o+2b0FWgqFcnrZSmGzBVZKGaWc2nIqo3bQMToYpxUKtWtgUFm3Ep24xbGZeGFIthj0xhgv5mlkJl5odC7xygsTv8/bQpn6XUdJ3cWHr9/n9/ze3/PAMyEKdHGhEGeUOonEIcRak6u4CB3Pwu5DKNS0eMCk0uHITc5mOfgqjVBWR6AjyHRyCULpcOyjH/vzUt7NP5//Mf9COgA9MXjt+vXT+ZevTypMHAJtMhRgd+nrmGmifoyH4xvh1bm1B1cYaFtoIWff6LQQDy7EZisdhWIlR63JxbkKT67CMF8n5/apHXIVS1Ov5c2z+A4NTy2neQ5VoYakI3JOM89Av2B0RcV+rJ9/8mvFnytv//H8eN4B81kwT1/ruX75ev7lN69tqguqGhho5YUPqvpaZkZtU/HwxsZUOL4WNVsXQgKbzYp8APrfTr9i4oMaBRqpHRCydDW5uUaZCnNxFD+ejIVYiGD0PFteqFWq5FwaR1zzRV1ds5Fz85a004dtrkguxee///HJ72+ffSsvBc08kg8OT4L58vU3ezA8lSsbqvpIplvdcLp2bjwRD0/d34hPEejEGoFOIB//gsbfjDxayMPQHmWP7C4FSp1O6QC2jOYpLTK5SohLEgNqmsu3aMS0nKuk+RbZqSKk49y51zWvZyedJvUuxZsUqdVvHf/jw9/fzQbzAXLdYE9Pz3UYTZAbGjRIZF+53VVvItCeYLM/Hr4fBvXM2kJoKRRaQnWzLiQOQae2mYy9O+c09XIM7JVCpQpvQhoRpzUWnsWhk6vqhXKx2IUqoqNxQqvmyvj8Ytk0iTSesy5mZx9E+sDmNPUb737y5/vH0FSnmCeQDGJzknnyeqmmoby0odzXWt/qc1c1rHtX56bi8fsbG/eDuI9gi4UStkSWYMEM5jQ0RKAfP97TFNJClRxeaiw62oJnQR5KtA6TfJ5Yrm1p5tFsrkMuHHeUOjRsIdIBZkCfmz/+OozOSyUar0NiPlr58703GGjGZQDDZfzt6Tndc/p0u7qggVPa4Pa56lvd7g/6fMHupjCgoxtx/wKgE3jcSmApLmcJDjMT3zOe7ew8e3xRKrJoaU0hrkjIagotNKJskaOAtGp1oqlVubyUtrDEejnXqIbRJQQ6AqfnLwI6vQz/xYxPV+A04kH66Ilrl9thMpCxCBmdphtKGWjTgMvtvtDn8zY3I86YegTNBHoplMjKpLAUc16AtgnQ5T0/+vTZ48d5suLiQpFGY8wdkgwINRaZhYXzKY5S5/hso1tXzpOpWsUSk4VmqySaQbIMCXQ2qWZJaFD+l/r4e5vZr4P5VF3J4OTlA+W/+Sbx/BS/DzOxPhy5XHX53G5AL4ZnsA6Xo35Ah6ilkBXMgpxlko80M5UlyMx4Cui9vcd5jppcSW5N7tCQUSsyyjRCroKFE2KNuMXaolbgccsgxg/FVmNOM9jbSzKNBu+NvOxU8fg/ZizQM8dgM5BJmWPU3t7eV1WFQOcPTygaOJwqQBsItA/x8BDoaCgFnRmKURRmCKEQWAkyA03Zcmwp6GfP9o5na4olY2NGY1tNTY1QLFSw+KVCx/iHLVmGKp1DOG4SaWUqBX9Iwh/ugSYHMXk8ln3uWB4ThLTXaWbok+y817GZTCbjDGICjZPbSWyJ19RVHHtVg9tZ20KcbrA3Oadm4vGo+caa+UYK2oYMW5eRjwOj8Qla06OAfvYsr6zs+Kn5YklbW2ebSCYyaQr4cgVbIxptnVtQ8GUF49p64XgNm62R6FTXSDBRATD7nIbjyDVDfZgcyHnQGx9ml51CzWCqHGIB5MrKBjYbP/Zgj0JxgUD7WpubXb6H7gZfs2dm5v5G1Gpd2IcGIUxeth5Akw1dsA/9vKLsxLGtty5K9V60TSKNtp6rY5WyHE2jBcvNpQ7VgJSnFOulpSyJgz3Rk4S+jvqFyoXz7lky7kXNJp4T/uRjIpT3dvbJyOAk/jWY2yvz2yvPnz+vUA8O9+DYhVtVzuEA2tBda/etlzesGwwdSMeC4AA6hLoBLZvTTpPeNAld8XxoqP94XvVOXp1F1JirpGtE3HqardCI5oQDMY6KNhXX87RivYZdk8tiX2M2COgysXsyKdjOlBSUY9TubHzByLQs7+x752axB0Lt7ecr209fuHm+Sq3Y3Ny81qPmljLQ9toWQDsvVHmchu54NBqjzAv+A2hQC8whvEFJZgZ6e2h3R7LdWFFWdiJSduJ1XVuxyoJrHQ6+QiUbHeUG57gWtbSQMyCtFw+oGh189uRkV1dX72SSfBKGM0qxp+Aj504yeu/jSFEvPu+5Xtned8G9fiH/NJuZmfZcY20qyu2cqip7d4vBt+50X/D4WhfjmJVSVgIdowQEGuMDK87JraAlyCQgFKAbt3d3drePPjsZKbp3b++Nd3JzVQ4jT0ar2RrpmqggOEWrtOMsrqOwgC3GAbl8+hqpHUXgZlwm6OBOkaf4h4uwzRN9HJntSp7QKhrOn/6g4XTV9MjIyCY+WlmpYpfzyqtKXU3dTrfT6bbX+tbX59D52xhonMbhao2ZnDdjeyQyW5lncRtFZWVsUU8rdj/99Nmde/fuPX787JikWLer0TpUbFWNNCgSznSo6vUshahGo1Brx2m5vKQXSvIeUoo9yY+woAsEcyQyC6MJNT7CSHqw5ONZnDuinGyubG5yCHS5c7TF7l5dL/cYfL71cIKibImFG4hHAHXPbCZGm5cZYcOxwuzMTEFWxvynT/sBXQbmO48f3ynrNDpwlU0nZ8tqRr0WYXBA6R1gF4hkdBVfquUKVUxrSdTOqPLyZeIt4nIgEPaSLhCC0YS3d7K3Fz8HI2Rr+NrmyObmCptjKq+y13Y0+5LQnzx0LuJ/PhbiXHABLq+FmInYFZzOMeMlzNlDZgH+uzVD/nQorv/0070UdESybSkcorGR50rXZHJtsFY/rlAMSGkFVyMt4KtKBnv2iRveJBUsH6GAwb1dvWmhoQI0Q91Fct7bu7nZtY+MSrk5MjiycobtM5VW+Zo6PL6Hq+4Li9217sXVTlsixxoKzkXNZFcBsDmQk4Uv5HDLmpNYWIgt4WQg49XjbU+Cnx59fO9eUWRvLxIxDmkkMprWyaR+77yqJdihV7O5WlxEkefSLBUfjx2Tw4Nvtue3t+dXtrefzn9zYhobHpZk174Q6FnCfLLsxMlIF7M2sfhGRoAMYCBvjqyUYLCC9r+01BXEWNq5euFC80y3c3WqA3U4a20uvoBNBW4jw/A6hJMuooQgkAB3IJDxyiW9dWGbQN/5GNt5BJu50aHROWRtMY1c2BT0sthsnb6+lFso5Yt1JYjycNH06fa+04zZ7vw+tJxFXZOgLoLAS4gJ8gnU6rKTRcNkEwJzSQmWIANfAmLWmTOXuHZ7ValhtBuRXvzAPROcKXSGw3i6ssLoZRJlK4ghZIRM88xWdCMUakv0SsYrd73UcuPRPUCfA/SJ3Uapw0g7amSJYlor7vALcS1JK+MrlG0qVqFwehhO98Lq83gWvel29r3JktdNowLe6/373iwpdgQYBQ/MpPkomwUyUKeJtXidmThzaV+8Vjv2blyFXJ9C/ehIzOV+tDrlx7btn8OaC1iXgZvcVKxMjQZwLLEkyFqOZrz62xoVanu6d+fOnXMn9k6W7WIb39LUOBpjDrlo1NtRqlazci0KVrFjWDOuK5kexkobLhmuzP/g4fqF85XTp6bBjBjfu9eLOsfgQthYmKHNsQiYGZ+TsO+kJMe3mHc0tHpbXOWL4XXnahs1c8Nzd2oUjvoRaVS8ZWbIEUCoCXsAvZKAWkIFybqS8erdqG1Ngvb0zp3He3t71UNG2ZbDKJXAaGFxB65lYqhgZHNFxpLpcZF8YgLlC1bPTvedhvqmJ4r2U0G+RIBcBpGnsOqKiuo3jp0rIomYBjMDfPbsO2chfHfpbIGJU3V11GDH+nM6m5ao0Qf6j6bmzFk5wWgUgTAz3R2gswQB8oam1AazQ2YrHmzXnyyPDgGaaO+ZsWaopt8o0SfaNKrxWFNwAHctJSxFvUQzzBoV4xycFC+UsKJIZHB4GnUYrIyYfRDIpMFG8wHmLUAfP4lCQXxOIUNvv40vckArMdfqaMbp0Oriw3BbFuWPmt2rc15BANeRkQmUNwYafueQN2I0lUWholgzXnH99ES8+/T53h6Yq3eP9TdubTXiMoqMpfX7Tfp6tVpWWMrS18gH5YAumUDNwh9SI5Ib48HqQ5ZPkIavGsIXQPdXVx8/MYtspKHfP3vrbVDD60tvC+1VrU3OVrcn7Hk448VQN25ufhifywL0FdCGSJJJLGwMNOaOeOFWAsogoF96Utv/FE01srFz8vGO5K3tzM5Ym04ZjAlLvUq2JZetLhTR8kGLni6qI3EgyEnW/W9BTNJcdhzMKQEa1O+WRVLQoAYyfCYiAZkf4JSLPa0u32r8YXe8iRJQczesH03NmAFNQhzKSkNDtiwYDeYs6xVzxmv2u08W6X5Y/axi68Rfezu7Q9RY2xi6jlghW603qXFfkB7n6eSD43pdkXyCiQLEwB5UZRw2I8p4IGBwoRR09a2Ts6jKBBo+w+ZbB9AXhaWGWrvBvh4Oe9Ze8tsENvNG1uLd+FwgGsWg0cykg4HGG6o38ZokJYtA85z3Fwfms48+39nNQ0IqOjMzg2ONpo6YlMPnjXIsMjZdrFTL+NPSjlNFqgj6iRc0gSiTbhrtMwpGRUoA32Kg330f+QA08gGb3wdwCvqsw87pdjtdHM/M3dG5u1YbnqyiVv9XU3Hrg+Uc7IdWQCPaAbiLRJPmH9B4z0E8HCZXbdgpmn1jaahiDxrKpIJtlEkck/LsLG6TXaOmpVKFTjbIHy2MTJwidRh/mTcU5DoAn3wdy48Zq2PscUiA7gc08jGShAZzGnreUt687m51+7rDUyGcXBBoc1Rw96WZIMqaIMGkA5WDrMMAgaYo/BNiu9WcIRO6lFedtfOOzqFn0E4m5W/KLFR2Gnl2E5c7I1arZDJ5aY1l0BLUFNWdAuy+EGLwQihxef9lJlYD+tbHI/vlA4G+dQB9UWswXPC4yl3hcAw320AD6o2A96upKfOB0SQbSeiAgEBTOTcCtsCVjNc0dpNu3ZPQn3n69PnzrTEq0X10SNnYqOKYOGq1X6sQaS1suVE+WBg82yWvi/yLF8Qpm/F4WP0faFC/dwgaOoCWNvt8rb5yz6p3LT4TBJsgy+Z/YLsbnrqCxiNpdA5zUIR05MBoYGsrKys5qNOvOTDsNcW8rMHs7adbjVTmnOxTUXGjnIMJMNsSUw4oaa5am8vit3REuk4xzKcOmAl0agYJ6MPM1QfQZSWDiMeL0KA2ipwuV2u5b300Fu5eCyIFNryiWXosxUNGQ4gxMdocipnQVuL1SgYta/UJl9ZwTFTSPzSUmRkTHe0USYQcHDyzVW14+KJZXCxFPj0qLpqQHxh9IiXG5/1pXsW/nSbUh6DPppk1RpxPOV2lvsXQ2mp4zZuFKkzZqBs3qLsvxbHYBMTogEAAaMZqyvzoyVeVlecrK4Gd8UqN3bQUfMjHrL9EQmWO6bcypcX1XCWPx+E20h1ajMfkCs24WrRGd9XVkUifAjRwTzLZYPIMZIYZ1GBNOw2h6H28Hw9An00yz78tkzoNLoOr3BcMzSx2r/kJM6htUcGNr+I3rFlJo/EpSqEgEKCoR9/8dhPP8vmV+fmVGa9a6LG1db6SV6AszESF1i51SsW8AhjN1cu4LeMW3NtWFwvZ42u62QmyVUOABnYZoNNr8K1qIB/yuj8JTUKNppRAp/MxjxsMgHbW2ss9oegcnPYnmQWUn1gdzbGBGUYTaLzQLG18++ij8/mE+nx+foZdkxld17GErXbpEtXpvTpEtY0rhTjeUkuLhayBcTDzhV4uSy+V15UUJftOQJNIg5hApwa98PbFircP/X4S+nCoEelCj8Hp4fiaQvG1FjhNEZEsbGSN3d1AOgLolJLMpOOIffuIMRrQoM6oScTXWfXKAoN+iUqMX5VQuD8/oITRIr1WqW4RsgtYfHGxQhOrr9MVpaGJytJHiG+RjfAFq0G9s0Oo370VOYA+2MbnjVc9Bg/6Dn8o7B+dSkGTLJhvUOGXlgMEGswMNF4/fP/oc0CnlDE201zAEyoHGjOXMsWG3KVGndGoxf0PrV6kVLMMgFapxsWKYn9JHQ1oUKeYy7LT0BCggZyGBu8OqBnokhWyElPMTJ/3ZW6rx4BId8dC4bHRKf9YymmUvQfmpZfQTzNG28BNmo4n3z764jD0uFJWz+GJOsGsdXUOdaomjLkiJUvrHS9gF3CV9WyVStmhVHtbeicspP9MFw+EA8gpZtQ7uJ3C7t/qh89QzQ6B/vhMyUrSaSiZjt1clxP5KG+JLcSpjqk1BjpZKcxByvvTFcZo2+3bFJUToKK/fPHoh++OEN6bBD0jV1ko5I3HlpaWxMJM2VAuh+XILRRq2/RK/PIgfslNrVIN6Lm6kLC3hK7rmk1XvINVmIJGqtOrsH9rZ3eH6Mv+i1iJZ0bg9KF+mm6UujyAdjfFFuYItDUVjywgjvlt96O3c2B0zm3sKQHBg1+Q6C8+P3ITyBCgJUqtWOqPJcZEhZRD08gz8elch7jTO4DLqBy+Usxj8UVSttTLHyyqmy/6F/ShA+Zq8idV7KCdnV3ICKf7L74/ciltNZHcsS1ykni4Owj0aNxPrhsAGvsIAuG3Xrl/hZSO2wGyT97+9pdHX3zx1ZEjHx25mVSGpF7c5k/EJF96l2jemJJnwq8Rits6tUIVj81hFYiVfP6omOUfULC6ijQlRedIqCGGOb0bMjWPIcYfxARGE+0YidW3Rj6+tHlgNZjP7jbWepy1hnXfOIHWE2i0cUxbh4xQN27f2AAv+iV0ooFHv3z/6IvfgHzkt5dv3gQ4oKX6zkRM/6W3sUAxVlNKK3nK5jaJTIiTOo6axRML+QVBocbPY7OK7s2/Q1YilHQaOnSMWH1IFTtPjw49BXUS+tLIrZWVQ9B0o8QA6FrXendsOU4FZ7yATkpAoM0PAtErOaRRuh0IPPgBqxDh+OijIz9hNTJOd/o7E/4Oo76QW1qzVF5Oa12L3jahpp7WcQGtvlqvrg+q9Ho1l7XSW6fZz0c60yBm9CL07tHt7aNDoGZC/f7wrXc3U9DwWf7lthROX631uBb9sfud3hehqZzbGDY+QGcH6Nu3H3375AsY/fLLn39+5POfP7p55MiRjM5Ogb8lVy9WlyozTeXcAq0n2CYqqNfWW3CHTMUzXGW3tNAxMR+/PdvVNV9X9EKoAZ2mZh4MU0Yf3f4U0EOM1RffvTVSspO2Wq6TbBfWOp3iq82e2mDsvpc4jSAkmZmaYcMRopVplG5//cOTn3746XMgQy9/910S+h82zvWnrTKO48Bkxkv8A7z0iNpqa9vTdtb1HGgLlUY9rbJWZz3FVqzS1sZ5qQelc23XSSx2XKYIk7igXMRla5zAEBPCxSAyMQEKDOUimURYSOYL3+gL3/h9Tg9eEn8y9s58/Pp9fr/f85zf8zwX8NMxtVpRkTA/olQy7ljAbXYA2oyOyWDztMiDUS5psDFlsvqXsBSJp/ED5D3oPWpsZ/eE/nl4dHR0WBAEGtRIeife+LpZlBrUBoN1WNDCHmxLpK4l+MlIU0aEloTGRiXbcLAw2duD+9SN2bGN6c3VrWsi8fX42biOQBdatDRllbnlFuoJudLzcgCLUaMxWq0Emgnh1nXQzWtMZrwXoHqp1HyoVDowz7tD6vCk+Bv6JsI8PMznoSH12f7v6lViAjEYntEPWwh0CkprJ+Lvd2aaYqjbeWjkDBzObM0uLy+vLy/mFhdzudXZrY0NQEPs/TOzM8giBSkNxRodaqNFqKhkPLX2RAilhmWsWtaIEUNO7fG36MOMEfO8ClUppD4pQYvu+Hee/hfzz4BGiNTEH8fhj+GjJYdPmAi0Q+BZP6B1msgRrf+Hrsamppj4LUgUGvQ9q6vry8tXlq8sDuYWx6+sL6+vitTghj+wIgv0FGf0aJShNkVFjectu8CEPHIrgebcCrlc72CCft5sipodCgVTfrG0+fGTEjSopSIuUecrDKCJo/PUPGwtQpfXjzYfwBVQk8Fg8I0KGm0doHX+I1b2h7nGzkzrZweBS6oL/urc+Q06A3pwfHAQf9YRv/22urG7MbMfaiP3FXA0hUaDCYdKGOUrdgqfh9SVDr0a0GZA43t5nBJKTBqNT6GUIesdMp8+LTFDajD/qyRK0B0EWqIWlUb6qD9804kSFagBHSqk2BaiNCY13fqJycbeeNL/8k+9sRifIAdfq2Am0FcGx8bHB0Wlf0Ps7Exf2z8zs3YBnrbzHCM38nqlUVmT1OPirtpRoebcbg3HYr9lwrWFML7ia6MYFJOZ3sW81e2Qeo/6nwnCfHnBWgQ01uHwsAQtpo/+c/X9zfUf5aFtVJtOR6BTlL+uSuMtfr8xnvSe//S6hZWVlS87O78EZJ55ENRjg8TdhHl1exbrEeUcSlsoTn2ADShsCmvCjE/seGuhguF8RpbTK+VyhTnACzYVE3WbbSql6e3SF0/e9/hJiXkvfSD+lT1eI9RI0xK0mPKGzjWfBTShRu7gWUsLbk2ylL+qSqub7Mo2xSLfvDewMDM7PT27vjSNAPOV8UH8DF65AmoCvbS5NjC7C3NDaZeeUmNeXmnTJxwVlZUllXJrpUcHU3Mcg4H9UIKmQiqlwa01Y1bMgIOwQ3c+f1rcuSAkaIS0EEXqjnOPfv3dzzeR+oLqgorYPXT8I0CXidDsKK3TOQGtodmqOqtlsquht7V634WBorUNAC+tT29ubuaImaE1gR68Qiy9Or197Zut3Y216/ftK3CZqRDLyBiKJwsP0JVahTxlUTMc5ZCXyF1h3KwtU5nUUVxikBnIUd5dt54+/fe2VvLH3zKTgIcRj36NOg5mUeiPPqwHNFmJNleColIE2s+nnEes1PzlOxrjmeuRhSenV1d/I8iLucHxsTEQi9CLUH19fRru+Hh2/8zaw5/OFFBmDntvh8tVxuCmDJE6qpTrLA4FS4UUlQ6aorR6mcJkUGswG2s6Sk7ubn8IB6T/aT4Qks7oSkEO6m5Efwcc3t/f313/4dnXJU87+GGKhtLOI5qwxXkkSmUmn822tq7NbGwsbS/trK7DHIuD49ks1mCeepn8zqH/GLj22+7+jYf3bxRQPhenUPM6mULNHCiB1CVGppLV6ZVWyqVUuOx02BZ1lJkwgGVBrobUp0+evvXBf1qm/1EaWh/v6OgAN4mhL0pf+pB8HSoXoTWjAqCrnM46bZhqAfTERDLbmlzZWVoC9Cqgc7nx8SwSB2IMIaKP52D3otmljd3dfTP7Czgz7TNTsAPDGA9UysHtcR/QpnRGI0UbbJyOGjZ/xapUNpOJpWwq2VEckZ58Hl+ACLOkNZixEoENkaH0HvdxdNJDQ91DL77z0tn6evQeh2WYDbaMCjRlqXK21LXwtLbO6ZqYiI/08p07G0uI2fXcNLzRcH92jHRLY+ioG4CN1Ee0Xl2a3ZjZ3d1fQPv0gsZo0RqNHndlhQKvcSgdeFJC52YsdEiv0xjCLtn3jjIDxnqpEKQ+dPJ5tKcPPSS11NJErxiS0OCWoF87N9Td0XH0MI49VIfxIzthcgiAthPoqhaaRvqwBOP2kWyga2MHQi+BOIf8jD1LA0pNdmwse39DFmrjJ0cK487Mxu7MWgGnp10KD6VRq5VWvGVBBr/dJW6YmmFpmrKry2jBFjLj/6tMZubIWgQyKrlEfau0D4DUx/EPsIG8F4DuPnf80XMnThyGyoRbZrIOJ3iKigPa2ULRKWeVK5gJtGaTiS34A9CLi5A1C84G7AGyYqBDhVnQhSAdrmzsrExeX2DRcSGGsQDaY8WsS1mFXK5WqHX2EEnRAU2ZwifoRWiTysBRGKGWjsZgDgIthujqf0z9uYQMe3T3v/Zaf7dEjTCFRvmw6GncV9EJFqfT4k3zycZn207tQY8RafPg2Ua8BDNCzh7HBsfROs3Obu/sTK3tL9DZkJCNFjRNRqsCb0fA1DgS01n0Kh8dtpvKFAaaBzSSlUrlc7lsJtuJ/OYFYufLy9+jm68Beo85D0+gPz/efRTQCNjaIAzTCXoPmqerq1k8IBLubWhr3SHMs7nFLPGyuAobReaR54hRxuEPJJD1na4MPB2yuvQeQDNWdVRxoEKB51kYGaBdJkcgqUdvJwvxHOfAwpeVmcwUZ7DZDokdNaGWTP3vDoTQPiDK/NrXn58b6v/8u9eGTotS19cfljlGBUAHdE4CnRIEf3V10u4Ntz59WxKmhqUXG7OEmXQdOUBjYn2xobAQUo+NEaV/WxrZ3b2+IOR26RmGYz3RaFQJaJgad9H0OkGmCVCcSaFUGSh8W0QNB7XBTOlx3wVnvfn+Y49aytZw9QMkjueF/vrzju6Oz18bwmd3MuXxxkcmk76NCofpQJxAV6doIeWMfGaJhGOQenJnaXYW0GNjdwAZSXqr99mRkcXpxcDVwoO3Ee2R9n6bndm9fn/BzW5XiEB6otYoc6BCrsAdH6OHpSizPUVTNgUKSyjs4gxEalW5wezSY3QdyCT2TsYkaGlfjrxBkMUKc66/G4Mk+QmRszj2ERJUIkzTFixDbSRlEai6ps/i1YFEprEhvPHb7CzKIaws5uaxxcXOxpHcdNFVQKPUwNVgXgAzoH0uhxGVxIgWmsHzPUoCzegtVECjo2hzGToOG01xIVKClarDBoeLs9kMEnOeWgIHdx4d0Nhidf+IL9fdYCbzQGQk5LBJZhvlRWhc9HRq/X4LTVcnk/ZIPBHva7iNSE3KIaknuVzDtzOLi4tbI1sTw6OFVxMjs9O57GbuGrI0gdZwahxH01YlWn+8oKQ4AGijnuNTUQsl6NFEw9WCxWVQilIfMqCTarY9I1ETg4jMeXBR8g7EOUI89MXQ0BcX30G8hKjH9C03SvGJhCBCt/j9LsrSmgzavZFAON3bkEQdn83lNomqubbAtdQdua1r14p6WgtHvx7NooUaGdkCsgjN6RmHUkbpGbVOXQZ/lJTUMrZQOECqS8BlUpjKUFYol1kmuvrkCZvZxflsRyVqydQitHQVsaOfIF9EwBcEGJ6+ePEsWg/DMC8+AUHb/QQaHgwmA357/EywLZ5uuKN4Z3uJCD12ZXWw8drB+8eXc6szI1uZg4U/92bHF8eyI8Xb1+ehabPHwSg1rqhR51PAH/IDSiVOU3Q+uY6iaFuZQYaRelrH2ZQyUL8rUlswWo/2NC81ZAY1kMl/wbnu06KJEURfEH+BqL94tr5MpTC3UVSYHw4DmpiatUBorz8ei7SHw+29tz1NquLi4OLI4HpucKxhEHuB1ZlrC0Lhz5ez839sjmcb5+e3Z0RPUw4G0GqaNWo1yB2AVpQJbXiRq0RjofgQeSnH5KBpl9hPMzhXP4HVqAM1oB+TeiYEJlKeB2DpRQiLACn+7AWELkE37RplhYTADwsWvxbQfp0lYPdPTATiZ+xtmb47Gnp2kPZmc3DH8uDWOun/d69f6Pj55z977rhle2xscXbt9+I1NLEFIcqjxpm6h8aAKatAS433zPDGi0uvkRNoTqVQQ2pXAM8P5qUuPX3IhBxibga15A8J+vTJIeLkoSHMM+A3LI2QmM+WqMpNw7yVTlDhBG/x+gl0yh6Le70T9tb2dCKcbroj27cyu7SeGx/LrY9fWV1dXV7d3S0a6v/zlpHRSeiMtmNlgfijwMXJ3Wqc1bC0JpryKEH9CFeoVvNkgJCmedpQ5jaUqcw0jAypUczJvMEJ1EZQi9AP7lE/dCcS8zlEdzdg8Qsh6fzi2ZKPyj/yjbKsELaER8N2P4vnG7RBu8VOqGOZtD3RNBkG9e8rs5vT2ez6DnhXl9enN3794s9blpNPj2V71vbvJ7vafYCmzAoHA2grRbl1boXygJIuNFa4w5ReoaQEnjbjYF1WJkMiMRuUKvRNJ8kn5kM2CxVqvn0vf4CaFHNk6H4w/4tX0hnMiO8ENyytwws9MT/rd1b7U3irwD4RibTi82c4iQn17NN9v092zV26Y3x1Z2P5Sm56fePPP/9YxQZ3pHht4ZuFC/v2fbqPbLcYo4/BlyEz69KkonKZL1wYfUSuDiPbyV20QOtlyqhBhblpCoPgSADYkT9P4hDO3pv/tX8h2OKACqARgJawS8+efV1kVg2bjYEwjY8OiYDXzwLaH7TH48FIa1NXX18s3PllK17m6u079cml+ezYldzg8io2Mn/8uYQ601dcPPnlwDFCTKBvlqsdDINjsKiOCmrUdCJsfKtSbgyHsa/VBegwZVBF3Uh7tMCFbEpsYVQvvfg8qeKHfDT3lEQtZT2xvtwK6ufzUteXghg7WhLl7xqGa7V8wuLkCxNC0J+qdvr9cXswHs+09oG6KdnV2Zk81fhsb1HR1hbqIvazOzs7s4vz2WxP8eTkZBGYz58nzJ8W3Kiw2tQ4SAe0XRcQBL1HXkOgExajwm2hhykfPgeoZSVm3sWZZVhNxnffeVE8r3m+meYwgECo89VFQid3aQ+h8Zcm2jDtQZjhDv0TFvxrq6jCUd7uT/mdES+UziRb25suTWUy8eQHPae6Ot9/tmlhoWil+P2GscUr0zk0qiOTk9PbKxcuHDt/XqIuUBrNardHzZnxikQ4ocEG0VNTIa/hEzq30uPieZo1qbRuk0pB0xw25GW4VPnGOy+dfPBBUNto7nHCLFFLFeYpXLYgzagIC2TEYZUK7vA8YeGxmdUVtiUCEX/KWe0NTl3OfNI6eWmu1d4etycxiNzV0/V+Eszzv/wy2bOIrnpkc3t7c3PtAuIYiM/DIoBmzYxbocZ1HB0d4K24XIzHnOQevg1P+tXqEjSPtlStxcUom8BxZhPWpPFd1IzSx0iatgVew84LIZVwSWgyDEa60TwwCZnqIxtOOCmetrawbW0J3hvRIetZrl7uwrqbQ/YIeoOtyc4PPunpxJubmYHJ+V9u2d7e3tpc3JwE9IIITYA/xa+CGzl0/yasKq0Rn1rcFYy8Ng9t0TC1mjA97NKaZBqrTFbCCbhnRAyiEgfxTkPsxx30nWQzIJka0Hj+4BkITaAPkdFBMo5nQnqXlbn0T1bSCYtcyyYKRxP26hTrdAavTrXOXZq6nI54A+3BdCzW836yp7Oz6+nWgYWVubnJucmVrc3Jyc1tAv0KkRrUledREdVmsxqfDtVqjY5nK5iS2ioR2p4yKt1CW4Iy+1RqFhtxGWn2bKbyckiNEC1yNESjKkodKqKDSP3MM0RrUIun6DjdFalp9/m36IT2Va1O2PNH8aWrV7suXerqao+0W+xpfARNf4l3Qk9hfLe3aOba5C/FxcXbKyuT29eI0GAGNKEu0Ls8WjVD+9TuqNsapo4ZKwFd6+EL7azDU8MdDPN6DQY2NTKZzMFzLp/JVK5iiNQXkUUefPAo9TkMsrcrJy1ec3NzP+QGLIYOxDAYUJPMrtpvPqZ57ac1Ohr+CGci7MQvE5dHh69O9XUFz6QjdMYOl3zch+fQejvnTz3dubA2//vvxX+srMyuLFz4Bsyghj+u23ddAe1gNHKr4Fa7rS9HA/ZKo/ytqidqXx4utAc1ypeto4lhyupTRVlzmU3GwdYGGIRRARrUF08+eJeWfhAGQUjHeh2kNW3ODxuIf9mewuigSSXoX/n0mEXwX8DBI/zBx/q8c+1V3nB4aiodDETa272BdKy9yXsh9VnnSG/P5PwnXQNrK7+vrPyxsgZz5KkB/eabgBYYt1uJ20QYoalFVazFUyVVT8g9icJgXK+sqaLbwoJGIzNpWJvaIRNcrhCoVUz93njpYwb6cwiel1pEPt7RLMoNZEATbqh+2DDcUnfhFX0i+uYFLSW0tfGxpvn5iDMzFe67PJGO2XFbXBf32ou6vMf0yS9HGhs757tOFf++Au7fFyRzID59c9++/ThUV1sZVu/QG62et5D1auTMy8TTbW3eIIcXNEKFCd6l8ZW5zRwuuhvEDAJqmbgWX4RFDqW+QyKR+iZCffy+4x3HQZ6PPPXR8q+pI9ULA6mw9uE3PTSF+kK3zs9n/H1zU/b2SCQYgEGqKW88055sf8XiL8Kjt8TbnbjMlY5cvjzf/t57dUeOfAypr9u//1PsxtVW2qjXq921tW5NzCo3EuiawkJ/kDJ6nNFh5CctHK0NmX2hspCAxskkK1eViwaB2KU2+laxsc774ziIxWiWQoQ+IRMeebVqYCBFBxcuvMLSFJG6c+5yxts31xTxVkfsAX97OkJ57WlvsuiIq+7jNIgRrU2tU1NXr0511eHGQN17Z+pQLovOY8RNTVkZl15tBLTWrlGqa6qeqKw5SKA1DE6AIDWHjxduNmRAo6fnOX0zGlRVvUgN6HJd8/OkSYVBCDSw75awJXJAH/5a/8K9ylePBWn72spClGbDB/lA61xrxuvtm0z7/We8sVi1N+K3Z2Dr5EB1+Mg3Z9JzlzDf3ReeAvXU3JFXEMfOX7ewVXTmhgI942Kxr9W7mdpaqyaV8hgBfQzQXi/FGdVV2tE2njezBkjtM7sMNlCHbEZQE4PgJkBpOfvUxccekqTGKgQusM0isaT0UdnogRfu9bz6JPZCC2sLdZSObRsWYqfmvV4vHhROe6vPBHEWEox440F7uz1Z5A+8N/DewO89z/Zmrl6aIhGMZCJn6r65gM9ybz6BwSvOo2QpXKStfZllW3Q1DKArAB33Unqr0VlFH4TUrFmlxg0MzoXLAgKo1bJ3y0FNsN/VhFBpUGEgNjEIiPcizwyhv+Nw46HykSd0FurJfbC2yxkoFAJdp5r83nQGj916nc54wH8G993j8TgG9Yq8QvWZ9vcGep/tAjDRWjgTiUTOtH+5dQ23kkieVjN6jnV7amt0bEsqSqAfqTl4MBZkzZy2qkrfVhjmWdYm84X0OGEyGzha1Lrs3Tz1u27zi6VII/9QE2xILa1DOLp5tOKFN++peORVDZd45IV78C4Gq2sbpmOtpzLezISXPOz3XnUmBr3b0UNB61h7MIDnYNLpRNslECOm2tvb07hi2RepSh9BP61Uwx2s0VNbxVlxGFED6CfUBNrq4+zuqiimfMOulEbmMJv1IQo5j8IvUKvyhbHUYH6RxGmx4RPP9fKOzssM5hOC60kMpr0qf7JWRxkxV/eIVefn24RArKkJCcM7kZns6Qx2nkqeaceqzMREai+vc1Zj6H7q8mXCPNXZ09OHtep0Vvf4C26AiTUUq6l5uZZl3axWZ6ypefXV6MGDgaDGYaN0NZC6LQGpHbKQzxHSUzTncxFqAyMTqV80+MQh6hdLCfbtoMZqbM4zAxnl/GuH/BUM1D3pefKYxed7FRdNlNoUpLYnWwm115uZn//g6aaexmR7uimd9tpj/mAsnQ4EvO+FD04Vn/uOQLeemkf0ZWCoGwH9V2dnG5NqGcbxsuxtzd5fPjSZDWQaz8ODjimkIAz2MKAInofDgAMjBkgU8EQSIXAMm7nMjpGzl0WiTbLJyLle5tYHbLpGtalfyK2Pzdbmam221df+N9rbeu/KzsnO1vl1nf993xfXdd3XLVOa7Yw2kAhoaBlDR2S2AM9rh4amCsa+53xTVMAxMbSIFjJq2DKOWUxmZPYoM6IQy4BKRaifHLYAmlCjWQhTxQj2+RIkZ/lDk6Oqai1XRWtamDOpFSoTGi9RyaaDlyYWQD0XgbDnXnpp1htbmo+WSwXP7Gwh6PFkI0uFrOfKoVZr4+WvsRpbHy/MH+zv78/N+a8n0CmR2q5MJLSMTMlc9jhsLqnYMTR0qWA0mAbk8lRAgQAHaxGxoK9br7DjEj+FT+sYM6AKkO16QPbrDSdgn438OIs+JjE9qNvA1WqSGqgluox2guNYljWEVZfVSNosRAvzkcL8XNEzNxeb9VoLUW9ZE5nFYWPERrK0sDu0eKHVWl3+utn87HJhahlxLM5RQAeU2DsYOJrRSBLwtNYWFotlQ1euGwu9wpjCqEkFonC13EyhBIOxKmaRHdR2EaFW2kYA3U2If+ZuX0r8Zf7ZGCYhc7U8oK+uspwkE45ynCTECjKJI6yJvm9cjhYiBVBHInNzs0s7S0zUXyoW5mJ+eXB+brm5PLR+YaP5NLO72zxSB7FIswS784obZA6RgqFd6RTDcAmNJ0IHDOwZdMRX5QaCGo1LcyVOMBFDo+iMIph5wj5hH7XLzaDuDmDk6hhgf4P9CFpLiT31xNs6k8mEiCGfT+avujoj7uO5oI/tZUOsCwMJJXL5+8bsGfXaHMhjs7NlTzSSppnIXIwRRVeOW0MrLzzwWWu8sLvbGtX4vaVS+ahxRKCR8RA5wjaKcfCXNRG/z2Zgpar3h9azHnMt0yPSMEzgEtaiXKRODStQ11fi0wBaRBi3CNcbhlWB4TGAAvcp8hd+egQfZs8GgZpgujyxpCFTvZo16MSUO2TqwVJ08TaJyq15X5N1ayIRBKVz85GI1+b1omPGW6L9c3NLiytHjaGpCxtPt+yKVrNZNwRoutFotRqtK65P2c1FxhWnKY2uamQKVp/VFJJKFEMrUx6FIcNZ3GqRDUNYsRbtaqVegTS7C5fSRPIUNeFW0MDGLvIeqNvYMMJMsHUEGT+0mXHFOnN1hg+L+xZNIQduq+GiapHTRxm3Jhs1ghq+hkTQH+SNieSRctxa9gwFLzQWpy6+9fRndvtnreZRP+56Thhbra6dK65Xi2gNFb5MabRs3sjMB7Q2LiTu6Vt0r0fGR6qZEZRs5doofB2UMzQmJHSDWjSRsk9oZQp3sKi1oO41htipTf3UuauJ6UBMDMiA5jJXbYp7eeGSJTTYGwpJleIwLR0NgtoYleP0RhxSjMzH0hhBV8QyLOXoIfPG0+tTk4D+yPzO083W0wMD24j0Sl1d+LhlpkWBuJoWmdiyMTunUoaFkFjCTbhX5NpuLsPpJ5DTQyp8aF0uUsj6xpGITCjtbi0VpGSjdreR1sPZiEQeAS4MEnn73H6GzuVwmd2QyVx9tUknZiakoW4BrtaxtIpVR3FSaYJBY4FQRyLzHhskAkEXZo1Dn228sNKGRiPly61mPZ/c2yoHwkddV9wlh6Mr9KjGEarGglOxYVVeioWS0b+/EqX1pmpGZ3ZrNcjhrA9Fg3a1a1ih7w8HZHY37dAwDpkmmGW0+mFVH4RNNE3sF+ozaF2yTc1nMpt7vWLDek9I6iO/BZthJCyDSrlIJApmQb1QgHm8VlBHshH3lfTqhamVixtPf/YZ+i9arQuVSjpwdORKHF1xKxydsI7TIoFNRqbm0wMqTsqGlBnuw+C6yKKrZvgeuYim3ItTDz8cdWsoF46Y3nAgpZhgUmqFY9hnJ9gDw67+p1APOrffuJoj+iDQnDhT3UwIYpE2FBr0iUOCIcSLDCx1ST4BbDmcnc0uZLPGSIz4W2L6ZOjC6sUsgQb1Z49/9tlb9QAC/CNJ781X3Epr6IA6ZQyw1cvR7JJK7xJwpTPMid+Xr1/y9XDVjDAQZSj60kp0CGcMsiE+DEoI22iE8rS6mOob9mmmjJRjWOV6/X7sdufYr59Tt6ENxNd5qXTmqi1JqG+letVJSxL6/qga0sk5VuvWiNAM53ajPmyEu1+a8vcN4gqsefHi6iqzcmEV+oChbQSXAV3xeE/45ituohgbRVPFDFsJBv3W3oEwD2idLmR/P7puf0ZAE63JHFXQisWVdVBPqC3Do7RsJHwZbWagZiglal7GbBGpM2U39DE2BmIC/fo5NaDzhhxMOjPD1tLff7tydO3pSSp5ctqqhiSiDBsQqRFno0CA7jL34qJGIjwqmF6VFlcmV1c/W0mdQb+DBp1JVyKcqIQxpvw6xp+iaI0hVPNPFWyWHplBwDkrNbCWieB61PcoC4GMTMgZ9SeXVhZBLVfrhyla2ZOg1FqRRqsW4c72/Y/IskY1LVOqUOFENqxtgDa8PagDtg7QYUOex0yPk50fTlorJ9eeXNvYu+rb/ZOr4uZMKCGntUUKKTM0Xrm7n5UKnOlVnlswIm0yukKfQz8OV3eHXYlAIIEZoUU1jTa5jFAxTvldAy4lx4VYNiQRJHY7Lvg9N8NWqxCIiFGIsO89TKgxDZJS9aSLNC1XpEYxV1bzzGNP+bPkvRRV9xio29jw9etkOLwOzIZ8e8vGCKzv1r747v3vrjo9PWnFr9ra//akQyGEDG5tQCujRJeC3cIbvGDipFyuvNxwInPyUvHdjTNodOhMJ1xHpUAfJmffRRe1tnwm788abSpJyiVwLKAxDU6hyK5ohrH/8YJunFDbL0UvgTqoINTdPdbiZaubJEwCAwqf85HugpGi1Y4+UJM6ODHJ62QqnAHC5nSGXOfpybXXfru2c019+ao29dFVtc7T0x80vSGe0Q7qDJpRYUbKC5yUT5ZjgQJNOvIXFlZXXwY01IGuF1W8MxEgI0JvKhZxXnGVQoHGTFm1Qci0JxdIOGpcO7Wif4IPiTNCP3rYNQrRejB6H1YjSs001dfjLXpL8iilvezqf0GvH3vKs0AjqQOJgPocG5UnHZBNBkPuuOv02mtPvv2+87BarFel31979batVt377tsf7XpO8Km1Dt0bUp7npNJ8abZcskUuOKdXpyPLk0QfEAegNwZKdZkVw1ghai6X5GtMwe/SSWiZ8OobUilcPWhyjerV5HoUuQ/DdVMTKMTJF0XB9cXFKG7B01R/Dz78l4xRDX25e3r6qdGHHnFM+VWUWul8/ZwZo5xgBqhDl28dn/547ffffn9VvJxJMHkpK86wNTqR2wT2d3oU/ca5GalUEMR8HMhl5IEvEmh6+SKgSXsRmqE2LpTiAVt7LPKdNVumSmUjPkFXpDju0TfIvZ0QVj09oDeuUP0mFvZkvxpZdYt7UaQJXoKvcT2b7h2JIfAqouaYen1y+km95Uln1hNIqWXn1BICvr0dlkAhe83j4+MvTk6uEks7N6+2G8QZcls+k3Q5itbt77b7B7gZwvwGm18qp0vxEmKQSafz3emLC9jzAIzEFaDfqicSZ3P377hcrVFGj5mT0kUdYnT8GcHV4kGTNay3yKdk/Rwcz/b0M24U86OLIgaVXKRCiK9HLse8JT8OBu1T+ulHpn33j+FES1H61wn19pmFt8Nhie7weLd53FnNiN8I5Tuvrphxh4IlN5pYTjeSauxv81KplJeGpJXZUjqNbFK6FLv4uvPd1cm5F9596+WNl4k8AK2PB6AOoo9kkjFGzK+yqahEPCjF8J5nHwWmMNiXkzytdxt7R3h8K+3vE8ntlOMS5qkzGjSxMBShpuHrGArzvicszkecvvud/obHSw8AevtXg7M79ls/dn33aGhGPMMebV0dG2UzVVADGx7//uRa4Q2pIA1xS0vxNBrvPcgneV8YA/T0UePd1Y0Nkk0hzXIXbGmog9jNmmJhXGAD631iA4//EKDF7ExI163klE/rp4o9PQKoTf19crvG53BHjYAeH1fYi7S2t9+PTIu3qDGOPjUw9pTTNzaZ8ha8tmFAD29v18+h+7eWd09Pv9P1YIiCeEbY2dz06EENR0PagsCKv69KhZkQrupX4qWSN56r5OLWC04CXT9aJfqAPNrQ9fTP7xIxjAqRR1TJ6jhWDOhHeSmgpRaLIaO/ZyBIDfaYpFiaI8ogg5zfhBuu1oyPUnYNjcKjx1MueYtMxHdxGNuGxal3pgqx+jDxdL1+zt3fsbL/448InUwzLObt7P1w9eGchWd5EOfjFSkGpFW5Gba0lKtAF1ZrJW8tVdL16THIYzp1EdDE2qK++MvM/RsHM5lktDdkGAwRRxMT47pij0LPZwbuHTaCugfC7hmRBdVI+qEQSqh9WkbEOEaUnrLXWy4WvfS40wnqgYtPWec9gbaf6+cW3vlw//g7tLImeRauFiN7e7iUMmVqSUO6gjF02J5D4qUyBkml8TEgHreVcvF0fRKeXp2+eOFdQv10W9Qbk78+bsBVA8HBUF7HionxhJqF+cwjbKb/wWGNGvPzdGKxzqCVU2qZCpkxRmMeH0/B2dpel79cjpU9xTSteH16zDmQchLqOqE+t0B9/+uDzu1c0pA0kT/JmWrn5ubhpqGWzFWS7BkzP1vCQDcIGk3KMYy3wXKsE+jVSQIN6jNoOPpnu5sSCSEdB8HBpMSw6yF6NI8LoUzPQ8NqdTfmK/J8zyAlpylZn0+uUGjMCkXKURS5JLSnVI55PUy8fFmCmlZK+7rTu9Ag0vjZdo6by534F8AWpPgd2MMfNvcymUSyksN3Z8yVfBiBRTwQT1pjlbSVQE8D+i3cfXh34y2CTah/+2AHLc7o+NDPyGLsPoj1IGORT8pmuP4HfRQGg/dimqVEYddqHd1KsxnTNMxm/B8YHDI/oUZPATLf+bDTWdS/7owteM7VkbLKOvePj3cb9aM6thEdqKVvZDo/r2aSMBATZmEuV8sl4vEEboPmSol0qYQv67QTG8dFoo+Nc2g4+le7QzCJWSk5+4DcXouPSll82y2SYX3zg8/o0YOgdKFnw2WGqpV93cjrjZvNInUtTDsckVipDFcbS+XSZu51nwKVOE8hduZqq6yxv988brZKR0dH9XAPxxPn1ra4JBlxBGYx/DyXqCUrCTCTu3PVajltLZes5bqzTX1hFdCgBvQVvzOBxaFCoM+YZ3ieJwKRDshVoGb5wWH9MOr+qHHJzOguU7l6ZQqYvFeiTjmUskIMKQmMPS8vLR3u5anRaWd9rnDu6qOD4+ZuV7NVjjUaR/WcTuCxoXJJAwaKYU22mefBHAZxvGLzWnOZai2ZTnutZatz7F10NSCHeQ593e+hb8m0ZfGLp9vHInZ+wSKXtS8R8z0Y0gtspUo2Tjl6cRNeRZnlepMZB45DlYrEyqWSH2napbWOra3Y9sVp73wD0GDegaN3m13NhrfRaFi3e17FQudyNSy2zAwGDUGVa3ETFmG8kkv7Y6V4JVkNQSJWb8k6MHbm6mn8CGqI4/d2Bw9Wwt2mJkuRuJpFBmtiVAy1s2JuZEDvkMEcvlFHnyQs6bUoBi0i5LZTMhV1Tp0F9Qcds1t7/dOeBSuoU402NKhbBPpoG7l1knOq5eNcm3kmNFvm8rkKoG1FfzqeyMVryZg1bUPqBvrAIpxEtphQ/8lzUHdKCfOv0IQarCw/IpLrkKjALwuD3XofqThaLA4VenAwzpix281mXKaQqecItcdoxJjPjrU3O7Zy9QXPdt1xBOhmc/fD3f2DBt042krmknByrcrt1cAMSYdKXmx9CZjNj7vC0EUuF694rTZ0s6emndjvSPmXyBqQf6QmG/TPosY/QjBE48TZUbMORxmPX+IHB1DcpS0ymRKtQyZJH9KXdrMG1NQ5dWR2reObtTc/+HILc1jqjtHGzkEbevdg56i0tZfbTtZyuRqXrM3gmMEhVinXkgliadx+R6RkJTqpXE7B09bYAKA3Vs+gIeg/MSmMIL8hPsMnrsZPCPEE3/vyfgEfTFmw6zBweJQizVoGnQSzXB2MXWT025QUVmO57CnMetY6Zte+ROZ+2ROvjzY6D5pdX18Jhex8fljZS7atVjOIAY24LrnEnS3CcLiCkyWXwyXWmi0OZPjan3JOg3p6cvrdP2fGbg2FwJtkFwEzj+wKXA1ri4R0MQ33kBG7IXZwWIlahkUJYkLt0irkQY/VxixYMf/JE8FDZR1zH3zwwZsL8x+Usc+1dpu7VzabzdmtH/IoF9cryP0mBQz9Ixv0awaoJQnsZNibiNsCNsRKpRjmX8G8MZroA036004w/yW1lD8DlyJS5NsCwTfka2bm1QH7BMnvDusGuwf6epVan5KcOCO9feEAJXdHrDajMZED9dzcPFQN6rUFuLujowvAVy4jjf/FFz9s1hJ11AMrOUzbg3dmyCI05GqGcCUWq1RsGFNYTZZr+TIcjQyq36N/agyh3vNjf8l8rmvQ8gSUyJr/+YjEoDOMPhMGZWaNHDV+BY5xWjWqPJs/0IfKv8hd8KaMkZyhvLQ2X0B5uO3qNzEf8c2D/WbX7vLO/nHXyRc7h9+jiJmPm97A8ZUJSeY4Lp+Hn8PxWK5iDQTCyRwi07zVCz97/JGCBYmfV1bf/Ttm7Hz4mCaA8kwgRNZwN5DPRvghiMcWMoInG5Uit0rpFpl9kLYL2Ggoci94KSNGsllL3qmFNvTa/PwHb6Lp5MX94x93u374/PgY1J01nB15MBNflA0CmJNhiDofj1lt6XyyAUF5vY2Y1+v1eIzMGJL02Ov+3m7hOYGoAvrgIWsescc5Mx4WIhNVH+Vhrwr4uK4X2UUis5nCeePqCyvV8oJVU7DBYcn4yvwHxPCgHQyV+Rd3fjz+4ovPD3ZOT7/6crOafxTQQiY0mOY5iMWQQ9SfA2XJW4p7vUdpHJ6emNfPePwL+kceuf1fPK96B8+z2DTa4gZ1OxAhzE/C148iXie7CafjsDZl47ggOq6RMzKZVhZ2jcojaUXRmkh7OdsCXjch0B8QZjSB7Xz+w8HnX3zz5s7p559+9emhGIMYocG0SUiEk/lkolLBCKmKd75c8XrRRRbzeEipDrlTI4OXM/+N3XInzwvt9df29Rn0Y+SFr0c5vh2h4MvEc70jA2qKVnX7EDfhyrwy7BChYEKX07Ec74klgQ1oiHp5+cWdr776Yufgm8OOD3Z+RPfXF1fzAta2riJgbE0+F64g5i9VkhU4Ol1uNCL+SAS9kUj8Ggv//s3gOwSBbHjgFTICoQbzk2TgI/ROYhL8HQr1+PolFopCe1OvBbV/hzrVp8JdIZkVn2SEwSmTkOuYX1j7APpYfhEda59/fow+qo4Pvv3xGE12tVpykwvv5StIuYfTSegau0c87i2kS4VIBPW4bDaLCtJ/e1X6lrshDQDyAnH6oxDHY+0hle0jk8UShUieGO3vpShaq8cdk/GJlEtN4a6JMRAolefT0pQPU2L9U4CGHeAo3/m8E81snR1fnHadbm4P5hGAVPb2EmGc4IiRcvlqqVAqV2KoBxQiyPkGs8Hsf0NuY9+RATeEInBiMSZGP/YsmMVYiUQc7cxIiNP3KtW01iJDpGqRq110EQ0NDD7nxeYqBsr0LOd9qVzb+uDNnZ3OnYMDPL/c2WzuH/xw+uOP209ij9aVkznE0HFrGrFdma1ewrt9c/MLC1mk16eCP7/K/N+5yWnDcQKLyX6vvor4Bm4mvKBG/A3qF3p9alxlBbVLJWfOqP2BUtq/dOjx10zlrLe2tbQGZNItenh4uHXc1cT+1/Xjj1v8jKS8BzGTHdnvn53frKzsxVemlqemskbjbTfByf/brrvljjvuvvtOzIo1mXAq8hzULj2LYWHs4ED3jeobr8dT9TfccINIcb2f6rvhxtT1+Ei9VcqW056IZwlvlnUsLR8AvAPvcx+e4nzs6uo6/urzwwaztxf3xmJekjvxzC9gt5jK3nbbrf8I/BMw6vLFq8nRdAAAAABJRU5ErkJggg==";

    const CONFIG = {
        autoSkipFight: true,            // Bỏ qua trận đấu thần tốc (chạy kèm mọi tính năng)
        autoReconnect: true,            // Tự làm mới & bấm "Vào Game" khi game bị ngắt kết nối (chạy nền)
        activeFeature: null,            // Duy nhất 1 tính năng chính hoạt động khi Auto (Chống xung đột); mặc định chưa chọn
        
        // --- 8 MODULE ƯU TIÊN HOÀN CHỈNH ---
        // Module 1: Tự Động Leo Thông Thiên Tháp (riêng); Quét nhanh dùng thêm chế độ quét Thông Thiên + Tứ Linh (towerSweepOnly)
        autoTongTian: false,            // Tự động leo Thông Thiên Tháp
        buyTowerSweep: true,            // Tự mua thêm lượt quét Thông Thiên Tháp
        towerSweepOnly: false,          // chỉ do Quét nhanh đặt: Thông Thiên/Tứ Linh chỉ quét & đánh ải mỗi ngày, không leo
        towerDailyRoutine: true,        // Nhận thưởng và Quét ải mỗi ngày: Thông Thiên (2 free + 1 mua) & Tứ Linh (10 ải mới + 2 quét free)
        autoTuLinhThap: true,           // Cử tướng Trợ Trận & Leo + Quét 4 Tháp Tứ Linh (Ma/Thiên/Nghịch/Dị)
        
        // Module 2: Phụ Bản Ngày & Bí Cảnh Tứ Quốc
        autoClimbDailyDungeons: false,  // Leo PB Ngày (không dùng trong M2; M2 chỉ quét miễn phí)
        buyDailyDungeon: true,          // Tự mua thêm quét PB Ngày
        autoBiCanhTuQuoc: false,        // Quét Bí Cảnh Tứ Quốc tầng Đủ Vượt 10 lần
        
        // Module 3: Thủ Vệ Tứ Phái
        autoSectDefense: false,         // Cử tướng, chọn bạn bè, tự chọn Buff cột giữa & nhận Chiến Lệnh (Hub row removed 2026-11-12: giống hệt bước Quét Nhanh, chỉ chạy qua Quét Nhanh ⚙)
        
        // Module 4: Cửu Uyển Nhi, Cổ Thần Địa, Cực Âm Địa
        autoUyenNhi: false,             // Nhận thưởng Chiến Lệnh Uyển Nhi
        autoCoThan: false,              // Lên trận nhanh Cổ Thần Địa & Khiêu chiến map
        autoExtremeYin: false,          // Tự động đánh Cực Âm Địa (Hub row removed 2026-11-12: giống hệt bước Quét Nhanh, chỉ chạy qua Quét Nhanh ⚙)
        
        // Module 5: Di Tích Tiên Giới
        autoImmortalRelic: false,       // Quét bệ Lv1-Lv4, làm mới Lv1-Lv3, cảnh báo Lv4 thì HỦY để khai thác (Hub row removed 2026-11-12: giống hệt bước Quét Nhanh, chỉ chạy qua Quét Nhanh ⚙)
        
        // Module 6: Minigame Ảo Cảnh Pháp Trận
        autoMinigameMemory: false,      // Tự giải lật thẻ bài 4x4, nhận 3 rương 100/200/300, nhận NV, like BXH (Hub row removed 2026-11-12: giống hệt bước Quét Nhanh, chỉ chạy qua Quét Nhanh ⚙)
        
        // Module 7: Kiếm Hành & Minigame Điêu Long Khắc Tinh
        autoKiemHanh: false,            // Gieo xúc xắc Kiếm Hành liên tục mỗi 3.5s
        autoMinigameDragon: false,      // Bắt QTE 380ms Hoàn Mỹ, nhận 5 rương mốc & Chiến Lệnh Điêu Long (Hub row removed 2026-11-12: giống hệt bước Quét Nhanh, chỉ chạy qua Quét Nhanh ⚙)
        
        // Module 8: Hoạt Động Ngày, Tiên Minh & Nhận Cuối Ngày
        autoTroChien: false,            // Trợ Chiến Linh Thú (Tab Hoàn & Nhận nhanh) (Hub tab + row removed 2026-11-12: giống hệt bước Quét Nhanh, chỉ chạy qua Quét Nhanh ⚙)
        autoTamTienDai: false,          // Nhận quà miễn phí Tâm Tiên Đài và Chiêu Mộ (Hub row removed 2026-11-12: giống hệt bước Quét Nhanh, chỉ chạy qua Quét Nhanh ⚙)
        autoTienHuu: false,             // Tặng nhanh quà Bạn Bè (Tiên Hữu) (Hub row removed 2026-11-12: giống hệt bước Quét Nhanh, chỉ chạy qua Quét Nhanh ⚙)
        autoSkinBanner: false,          // Banner skin (Ảo Hình): Quà Ảo Hình, Chiêu mộ 1 lần, Chiến Lệnh
        autoJadeMine: false,            // Núi Cấm (khai thác ngọc): nhận quặng, đặt xẻng phẩm cao trước, Chiến Lệnh Cấm miễn phí; sau Ma Đạo trong Quét nhanh (Hub row removed 2026-11-12: giống hệt bước Quét Nhanh, chỉ chạy qua Quét Nhanh ⚙)
        autoThienThuan: false,          // Thiên Thuẫn (chỉ trong Quét nhanh, sau NV Tiên Duyên): thưởng Cảnh Báo Lừa Đảo + N.Vụ Hàng Ngày
        autoXianYuanQuest: false,       // NV Tiên Duyên (chỉ trong Quét nhanh, sau Nhận Cuối Ngày)
        autoDailyReward: false,         // Nhận Thưởng Ngày: điểm danh, thẻ tháng, quà ngày/tuần/tháng, điểm VIP (chỉ phần miễn phí) (Hub row removed 2026-11-12: giống hệt bước Quét Nhanh, chỉ chạy qua Quét Nhanh ⚙)
        autoThaiCo: false,              // Thái Cổ Thu Hà: quét tầng trước 2 lần miễn phí, Like top 3 BXH (Hub row removed 2026-11-12: giống hệt bước Quét Nhanh, chỉ chạy qua Quét Nhanh ⚙)
        autoArena: false,               // Đấu Tiên Đài PvP (giới hạn lượt, chọn đối thủ thấp)
        arenaBattleLimit: 5,             // Số trận Đấu Tiên Đài tối đa mỗi lần chạy Auto
        autoMaDao: false,               // Ma Đạo gộp: Thưởng treo máy, Tác chiến nhanh, Ải chính tuyến, Ủy phái Sử Thi
        autoTienMinh: false,            // Tiên Minh: Trả giá, Bí Cảnh, Tỉ Thí, Vấn Đạo, Viện trợ, Cung phụng (Hub row + ⚙ removed 2026-11-12 theo yêu cầu người dùng: chỉ chạy qua Quét Nhanh ⚙; tienMinhDungeonLimit giờ luôn dùng mặc định bootstrap)
        tienMinhDungeonLimit: 3,        // Số trận Bí Cảnh Tông Môn tối đa mỗi ngày (2 miễn phí + mua thêm)
        autoCuoiNgay: false,            // Nhận thư, Like BXH Đạo Thành 3 lần, Nhận rương Sôi Nổi (25-100)
        
        // Các tính năng kinh điển bổ trợ
        autoClimbYMAbyss: false,        // Leo Vực U Minh
        autoSweepDungeons: false,       // Quét sạch phụ bản đã vượt
        autoXianYuan: false,            // Quà Tiên Duyên
        
        // Sự kiện đang mở (banner tướng Thần Lâm / Đạp Thiên): tính năng chính 'autoBanner' (làm việc ngày cho TẤT CẢ banner đang mở)
        hudOpen: false,                 // iPhone: thẻ HUD đang mở (HUD cập nhật); khi Auto chạy mà thẻ che màn hình, game hạ xuống 30 khung/giây để đỡ nóng máy
        gfxBoost: false,                // iPhone: canvas theo đúng độ phân giải màn hình (x3) + 60 khung/giây (game mặc định x2, 45); luôn TẮT mỗi lần tải trang, không lưu lựa chọn
        verboseLog: false,              // true = hiện cả các dòng log chi tiết từng bước (gỡ lỗi); mặc định chỉ hiện thông tin quan trọng
        bannerGoldPrice: 300,           // Quà Tiên Ngọc trong bảng Quà banner: mua mặc định, chỉ khi đúng giá này
        bannerZlBuyGold: 300,           // Trần Tiên Ngọc mua điểm Chiến Lệnh mỗi banner (0 = tắt); chỉ mua trong 24 giờ cuối

        quickSteps: null,               // QUÉT NHANH: mảng khóa tính năng được chọn (null = tất cả); thứ tự cố định theo dãy gốc

        activeTab: 'tinhNang',
        intervalMs: 800,
        running: false
    };

    // Cấu hình KHÔNG được lưu: mỗi lần tải trang là bắt đầu mới với mặc định ở trên.
    // Xóa bản lưu cũ của phiên bản trước (nếu còn) để không còn dữ liệu cũ.
    try { localStorage.removeItem('TN_AUTO_CFG_V293'); } catch (e) { }

    // Ngoại lệ duy nhất: tự vào lại game làm mới trang và cần chạy tiếp lựa chọn đang chạy. Bản chụp
    // lựa chọn nằm trong sessionStorage của tab, hết hạn sau 3 phút và bị xóa khi vào lại xong.
    try {
        const rc = JSON.parse(sessionStorage.getItem('TN_AUTO_RECONNECT_V2') || 'null');
        if (rc && rc.resume && rc.runConfig && Date.now() - rc.startedAt < 3 * 60 * 1000) {
            Object.assign(CONFIG, rc.runConfig);
        }
    } catch (e) { }

    // Ngoại lệ thứ hai: lựa chọn các bước của QUÉT NHANH là cài đặt của người dùng nên được nhớ giữa các lần tải trang.
    try {
        const qs = JSON.parse(localStorage.getItem('TN_QUICK_STEPS_V1') || 'null');
        if (Array.isArray(qs)) CONFIG.quickSteps = qs;
    } catch (e) { }

    CONFIG.running = false;

    const isTopWindow = (window === window.top);
    const isStandaloneGame = isTopWindow && !!window.DailyDungeonCtrl;

    // =========================================================================
    // PHẦN 1: GIAO DIỆN ĐIỀU KHIỂN (TOP WINDOW)
    // =========================================================================
    // Nền tảng của bản build này (build-content.js --target=pc): tiện ích trình duyệt trên PC.
    const TN_IS_PHONE = false;
        // ============================================================================
        // FEATURE REGISTRY: một nơi mô tả mỗi tính năng để scheduler, Quét Nhanh, HUD, nhãn log
        // đọc chung, thay vì sửa tay ở 8 file. Tệp này nạp sớm (ngay sau bootstrap.js), nên mô tả chỉ chứa dữ liệu
        // và các hàm gọi trễ (lazy arrow) tới module tính năng nạp sau.
        //
        // Mô tả (desc):
        //   key        khóa CONFIG (vd 'autoRiseGold'); registerFeature tự tạo CONFIG[key] = false nếu chưa có
        //   label      tên hiển thị trong log/HUD (RUN_LABELS)
        //   runOnce    (gắn bằng featureBind trong module) () => khởi chạy một lượt không đồng bộ (đặt sau runBegin); có runOnce = tính năng "chạy 1 lượt":
        //              không kết thúc do idle, không chạy lại sau khi tự vào lại game
        //   hudStatus  (gắn bằng featureBind trong module) () => {open, remainSec, ...} | {unknown: true}
        //   event      {rowId, color, icon, desc(), hudLine(status, fmtRemain)}: dòng "Sự kiện đang mở" trong HUD
        // ============================================================================
        const FEATURE_REGISTRY = Object.create(null);

        function registerFeature(desc) {
            if (!desc || !desc.key) throw new Error('registerFeature: thiếu key');
            if (FEATURE_REGISTRY[desc.key]) throw new Error('registerFeature: trùng key ' + desc.key);
            FEATURE_REGISTRY[desc.key] = desc;
            if (!(desc.key in CONFIG)) CONFIG[desc.key] = false;
            return desc;
        }
        // Hàm của module tính năng nằm trong khối isGameContext nên registry (ngoài khối) không gọi trực tiếp được:
        // mỗi module tự gắn hàm của mình bằng featureBind(key, { runOnce, hudStatus }) ở cuối tệp.
        function featureBind(key, hooks) {
            const d = FEATURE_REGISTRY[key];
            if (!d) throw new Error('featureBind: chưa đăng ký ' + key);
            Object.assign(d, hooks);
        }
        function featureDesc(key) { return FEATURE_REGISTRY[key] || null; }
        function featureKeys(predicate) {
            return Object.keys(FEATURE_REGISTRY).filter((k) => !predicate || predicate(FEATURE_REGISTRY[k]));
        }
        function isRunOnceFeature(key) { const d = FEATURE_REGISTRY[key]; return Boolean(d && d.runOnce); }
        function featureLaunchRunOnce(key) {
            const d = FEATURE_REGISTRY[key];
            if (!d || !d.runOnce) return false;
            d.runOnce();
            return true;
        }
        // Trạng thái mở/đóng của sự kiện: undefined khi tính năng chưa có hàm trạng thái hoặc hàm ném lỗi.
        function featureHudStatus(key) {
            const d = FEATURE_REGISTRY[key];
            if (!d || !d.hudStatus) return undefined;
            try { return d.hudStatus(); } catch (e) { return undefined; }
        }
        // Các dòng sự kiện trong HUD: HTML giống hệt dòng viết tay trước đây.
        function featureEventRowsHtml() {
            return featureKeys((d) => d.event).map((k) => {
                const d = FEATURE_REGISTRY[k];
                const e = d.event;
                return `
                                    <label class="tn-opt-item" id="${e.rowId}" style="border-left: 3px solid ${e.color}; display:none;">
                                        <div style="min-width:0; flex:1;">
                                            <div class="tn-feat-title" style="color:${e.color};"><span class="tn-feat-name">${e.icon} ${d.label}</span></div>
                                            <div class="tn-feat-desc">${e.desc()}</div>
                                            <div class="tn-feat-cfg" data-cfg-for="${k}"></div>
                                        </div>
                                        <input type="checkbox" class="tn-mutex-feature" data-key="${k}" ${CONFIG.activeFeature === k ? 'checked' : ''}>
                                    </label>`;
            }).join('');
        }
        // Mô tả các sự kiện "chạy 1 lượt" (xem feature-registry.js; runOnce/hudStatus được module gắn bằng featureBind). Thêm sự kiện mới = module <x>.js + một mục ở đây
        // + vị trí trong QUICK_RUN_QUEUE / QUICK_EVENT_STEPS (quick-run.js).
        const eventGoldPrice = () => CONFIG.bannerGoldPrice || 300;

        registerFeature({
            key: 'autoFullMoon',
            label: 'Tiên Dị Địa',
            event: {
                rowId: 'tn-row-fullmoon', color: '#fab387', icon: '🌕',
                desc: () => `Báo Danh → Quà Tiên Giới (miễn phí + 1 quà Tiên Ngọc ≤ ${eventGoldPrice()}) → Kính Trung Kính → Ba Ngàn Mộng Cảnh → Khôi Ngục Chiến → Chiến Lệnh.`,
                hudLine: (st, fmt) => '🌕 ' + (st.acts || 0) + ' hoạt động đang mở · ' + fmt(st.remainSec)
            }
        });

        registerFeature({
            key: 'autoNewDevilSea',
            label: 'Ma Hải Mịch Bảo',
            event: {
                rowId: 'tn-row-newdevilsea', color: '#89dceb', icon: '🌊',
                desc: () => `Quà Ma Hải (miễn phí + 1 quà Tiên Ngọc ≤ ${eventGoldPrice()}) → Khiêu Chiến → lật ô Mịch Bảo → Chiến Lệnh.`,
                hudLine: (st, fmt) => '🌊 ' + fmt(st.remainSec)
            }
        });

        registerFeature({
            key: 'autoFestivalAct',
            label: 'Kim Thu Thập Quang',
            event: {
                rowId: 'tn-row-festivalact', color: '#f9e2af', icon: '🍁',
                desc: () => `Quà Kim Thu (miễn phí + 1 quà Tiên Ngọc ≤ ${eventGoldPrice()}) → Tầm Bảo 1 lần → Phong Lâm Chiến → Hành Trình.`,
                hudLine: (st, fmt) => '🍁 ' + fmt(st.remainSec)
            }
        });

        registerFeature({
            key: 'autoRiseGold',
            label: 'Sinh Hoa',
            event: {
                rowId: 'tn-row-risegold', color: '#f5c2e7', icon: '🌸',
                desc: () => `Quà Xúc Xắc (miễn phí + 2 quà Tiên Ngọc ≤ ${eventGoldPrice()}) → ném xúc xắc 1 lần → Chiêu Mộ Phe → Tầm Bảo Tiên Giới → N.Vụ Ngày → Sinh Liên.`,
                hudLine: (st, fmt) => '🌸 ' + fmt(st.remainSec)
            }
        });
    if (isTopWindow || isStandaloneGame) {
        // Chỉ hiện thông tin quan trọng: 'result' (mua/nhận thưởng/kết quả), 'run' (bắt đầu/hoàn tất/dừng), 'warn', 'err'.
        // Các dòng chi tiết từng bước ('info', 'action', ...) chỉ hiện khi bật "Log chi tiết" (CONFIG.verboseLog).
        const LOG_ALWAYS_SHOWN = ['result', 'run', 'warn', 'err', 'error'];

        // Log đã lưu (chỉ khi bật "Log chi tiết"): vòng đệm ~2000 dòng trong localStorage, còn sau khi tải lại trang / vào lại game.
        // Dòng: [thời điểm ms, loại, nội dung]. Sao chép bằng nút ở tab Cài đặt (logBufText).
        const LOG_BUF_KEY = 'TN_LOG_BUF', LOG_BUF_MAX = TN_IS_PHONE ? 2000 : Infinity;   // iPhone: 2000 dòng; PC: không giới hạn số dòng (chỉ bị giới hạn bởi dung lượng localStorage ~5MB của trình duyệt)
        let logBuf = null, logBufTimer = null;
        function logBufLoad() {
            if (logBuf) return logBuf;
            try { logBuf = JSON.parse(localStorage.getItem(LOG_BUF_KEY) || '[]'); } catch (e) { logBuf = []; }
            if (!Array.isArray(logBuf)) logBuf = [];
            return logBuf;
        }
        function logBufSave() {
            logBufTimer = null;
            const b = logBufLoad();
            for (let i = 0; i < 12; i++) {
                try { localStorage.setItem(LOG_BUF_KEY, JSON.stringify(b)); return; }
                catch (e) { b.splice(0, Math.max(1, Math.floor(b.length * (TN_IS_PHONE ? 0.5 : 0.1)))); }   // đầy dung lượng localStorage: bỏ phần cũ nhất (iPhone 1/2, PC 1/10) rồi thử lại
            }
        }
        function logBufPush(type, msg) {
            const b = logBufLoad();
            const plain = String(msg).replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&amp;/g, '&');   // bản log lưu là chữ thường, không phải HTML
            b.push([Date.now(), type === 'error' ? 'err' : type, plain.slice(0, 900)]);
            if (b.length > LOG_BUF_MAX) b.splice(0, b.length - LOG_BUF_MAX);
            if (!logBufTimer) logBufTimer = setTimeout(logBufSave, 1000);
        }
        function logBufClear() {
            logBuf = [];
            if (logBufTimer) { clearTimeout(logBufTimer); logBufTimer = null; }
            try { localStorage.removeItem(LOG_BUF_KEY); } catch (e) { }
        }
        const logFmtTs = (ms) => {
            const d = new Date(ms), p = (n, w = 2) => String(n).padStart(w, '0');
            return d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate()) + ' ' + p(d.getHours()) + ':' + p(d.getMinutes()) + ':' + p(d.getSeconds()) + '.' + p(d.getMilliseconds(), 3);
        };
        function logBufText() {
            const b = logBufLoad();
            const head = [
                '# Tiên Nghịch Auto - log chi tiết',
                '# phiên bản ' + CURRENT_AUTO_VERSION + ' | ' + (TN_IS_PHONE ? 'iPhone' : 'PC') + ' | ' + new Date().toString(),
                '# ' + navigator.userAgent,
                '# running=' + Boolean(CONFIG.running) + ' activeFeature=' + CONFIG.activeFeature + ' verbose=' + Boolean(CONFIG.verboseLog) + ' skip=' + Boolean(CONFIG.autoSkipFight) + ' reconnect=' + Boolean(CONFIG.autoReconnect),
                '# ' + b.length + ' dòng'
            ];
            return head.concat(b.map((r) => '[' + logFmtTs(r[0]) + '] ' + r[1] + ' ' + r[2])).join('\n');
        }
        function logBufInfoText() {
            const b = logBufLoad();
            return b.length ? 'Đã lưu ' + b.length + ' dòng (từ ' + logFmtTs(b[0][0]).slice(5, 19) + ').' : 'Chưa có log nào được lưu (chỉ lưu khi bật Log chi tiết).';
        }

        function addLogToUI(msg, type = "info") {
            if (!CONFIG.verboseLog && !LOG_ALWAYS_SHOWN.includes(type)) return;
            if (CONFIG.verboseLog) { try { logBufPush(type, msg); } catch (e) { } }
            const logBox = document.getElementById('tn-log-content');
            if (!logBox) return;
            const now = new Date();
            const time = now.toLocaleTimeString() + (CONFIG.verboseLog ? '.' + String(now.getMilliseconds()).padStart(3, '0') : '');
            const p = document.createElement('div');
            // Lớp tn-log-line/tn-log-<loại>: điện thoại vẽ dòng log thành bong bóng chat (ui-styles.js), PC giữ kiểu cũ.
            p.className = 'tn-log-line tn-log-' + (type === 'error' ? 'err' : type);
            p.style.marginBottom = '3px';
            p.style.fontSize = '11px';
            p.style.lineHeight = '1.3';
            p.style.borderBottom = '1px dashed rgba(255,255,255,0.08)';
            p.style.paddingBottom = '2px';
            
            let color = '#a6e3a1';
            if (type === 'warn') color = '#fab387';
            if (type === 'err' || type === 'error') color = '#f38ba8';
            if (type === 'action') color = '#89b4fa';
            if (type === 'run') color = '#89dceb';

            p.innerHTML = `<span class="tn-log-time" style="color:#888;">[${time}]</span> <span class="tn-log-msg" style="color:${color};">${msg}</span>`;
            logBox.appendChild(p);
            logBox.scrollTop = logBox.scrollHeight;
            
            while (logBox.children.length > (CONFIG.verboseLog ? 150 : 70)) {
                logBox.removeChild(logBox.firstChild);
            }
        }

        function updateRoleDisplay(role) {
            if (!role) return;
            const nameEl = document.getElementById('tn-role-name');
            const infoEl = document.getElementById('tn-role-info');

            if (nameEl && role.name) nameEl.textContent = role.name;
            if (infoEl) {
                const power = role.power || 0;
                let formattedPower = '--';
                if (power > 0) {
                    if (power >= 1000000000) {
                        formattedPower = (power / 1000000000).toFixed(2) + ' Tỷ';
                    } else if (power >= 1000000) {
                        formattedPower = (power / 1000000).toFixed(2) + ' Tr';
                    } else if (power >= 1000) {
                        formattedPower = Number(power).toLocaleString('vi-VN');
                    } else {
                        formattedPower = String(power);
                    }
                }
                const lvl = (role.level !== undefined && role.level !== null && role.level !== 0) ? role.level : '--';
                infoEl.textContent = `Lv: ${lvl} | LC: ${formattedPower}`;
            }
            // Đã có cấp độ / lực chiến = đã vào game: bỏ dòng nhắc "Hãy vào game" và hiện bảng đầy đủ (chỉ hiển thị).
            if ((Number(role.level) || 0) > 0 || (Number(role.power) || 0) > 0) {
                const h = document.getElementById('tn-auto-hud');
                if (h && h.classList.contains('tn-wait-game')) {
                    // Chuyển mượt: chiều cao chạy từ cỡ "chờ" sang cỡ đầy đủ, nội dung hiện dần (không nháy).
                    const h0 = h.offsetHeight;
                    h.classList.remove('tn-wait-game');
                    const h1 = h.offsetHeight;
                    h.classList.add('tn-ready-anim');
                    if (h0 && h1 && Math.abs(h1 - h0) > 2) {
                        h.style.setProperty('transition', 'height 0.35s ease', 'important');
                        h.style.setProperty('height', h0 + 'px', 'important');
                        void h.offsetHeight;
                        h.style.setProperty('height', h1 + 'px', 'important');
                        setTimeout(() => { h.style.removeProperty('height'); h.style.removeProperty('transition'); }, 400);
                    }
                    setTimeout(() => h.classList.remove('tn-ready-anim'), 500);
                }
            }
        }

        // Tiến độ QUÉT NHANH đã lưu (null = không có): nút chính thành TIẾP TỤC, hiện thêm nút CHẠY LẠI TỪ ĐẦU.
        let quickSavedInfo = null;
        let quickActiveInfo = null;     // {idx,total,label,hourly} khi đang chạy Quét nhanh / Thu hoạch
        let quickPendingUntil = 0;      // vừa bấm bắt đầu, game chưa kịp báo: coi như đang chạy dãy
        let quickStepsCatalog = [];  // [{key, label}] các bước Quét nhanh, do game báo
        let quickEventsPending = 0;    // sự kiện đã chọn mà game chưa báo trạng thái (chưa tải xong)
        let quickSkippedEvents = [];   // sự kiện đang bị tự bỏ qua (game báo không có sự kiện đang mở)
        let quickTotalSteps = 0;     // số bước của dãy Quét nhanh, do game báo (HUD không có QUICK_RUN_QUEUE)
        let quickHourlyTotal = 0;    // số bước của dãy Thu hoạch (nút ⏱), do game báo
        function updateQuickButtons(saved, active) {
            quickSavedInfo = saved || null;
            quickActiveInfo = active || null;
            if (active) quickPendingUntil = 0;
            const qa = active && !active.hourly ? active : null;
            const ha = active && active.hourly ? active : null;
            const btn = document.getElementById('tn-btn-sweep');
            const fresh = document.getElementById('tn-btn-quick-fresh');
            const group = document.getElementById('tn-quick-group');
            if (btn) {
                const main = btn.querySelector('.tn-qb-main');
                const sub = btn.querySelector('.tn-qb-sub');
                if (main) main.textContent = qa ? '⏸ TẠM DỪNG' : (quickSavedInfo ? '⏯ TIẾP TỤC' : '⚡ QUÉT NHANH');
                if (sub) sub.textContent = qa
                    ? 'Bước ' + (qa.idx + 1) + '/' + qa.total + ' ' + qa.label
                    : (quickSavedInfo
                        ? 'Bước ' + (quickSavedInfo.idx + 1) + '/' + quickSavedInfo.total + ' · ' + quickSavedInfo.label
                        : (quickTotalSteps ? '1 chạm · ' + Math.max(0, quickTotalSteps - quickEventsPending) + ' bước' + (quickEventsPending ? ' (+' + quickEventsPending + ' sự kiện đang tải)' : '') : sub.textContent));
                btn.title = (quickSavedInfo ? 'Tiếp tục QUÉT NHANH từ bước: ' + quickSavedInfo.label + ' (đã xong ' + quickSavedInfo.done + ' bước)' : (btn.dataset.baseTitle || btn.title.split('\u000a')[0]))
                    + (!qa && !quickSavedInfo && quickTotalSteps ? '\nSẽ chạy ' + Math.max(0, quickTotalSteps - quickEventsPending) + ' bước' : '')
                    + (!qa && !quickSavedInfo && quickSkippedEvents.length ? '\nBỏ qua vì không có sự kiện đang mở: ' + quickSkippedEvents.join(', ') : '');
            }
            btn && btn.classList.toggle('tn-qb-running', Boolean(qa));
            const hb = document.getElementById('tn-btn-hourly');
            if (hb) {
                const hi = hb.querySelector('.tn-hr-icon'), hl = hb.querySelector('.tn-hr-label'), hs = hb.querySelector('.tn-qb-sub');
                if (hi) hi.textContent = ha ? '⏸' : '⏱';
                if (hl) hl.textContent = ha ? ' DỪNG' : ' THU HOẠCH';
                if (hs) hs.textContent = ha ? 'Bước ' + (ha.idx + 1) + '/' + ha.total + (ha.label ? ' ' + ha.label : '') : (quickHourlyTotal ? quickHourlyTotal + ' bước' : '');
                if (!hb.dataset.baseTitle) hb.dataset.baseTitle = hb.title;
                hb.title = hb.dataset.baseTitle + (!ha && quickHourlyTotal ? '\nSẽ chạy ' + quickHourlyTotal + ' bước' : '');
                hb.classList.toggle('tn-qb-running', Boolean(ha));
            }
            syncMainBtnVisibility();
            if (fresh) fresh.style.display = quickSavedInfo ? 'flex' : 'none';
            if (group) group.classList.toggle('has-saved', Boolean(quickSavedInfo));
        }

        // Điện thoại: BẮT ĐẦU AUTO chỉ dành cho tab Tính năng. Ở tab Nhật ký nó ẩn, trừ khi đang chạy MỘT tính năng riêng (cần để dừng);
        // Quét nhanh / Thu hoạch tự bật-tắt bằng nút của chính chúng. Chỉ là hiển thị, không đụng CONFIG.
        function syncMainBtnVisibility() {
            const hud = document.getElementById('tn-auto-hud');
            if (!hud) return;
            const quickBusy = Boolean(quickActiveInfo) || Date.now() < quickPendingUntil;
            hud.classList.toggle('tn-main-idle', !(CONFIG.running && !quickBusy));
        }

        // GIỮ MÀN HÌNH SÁNG khi Auto chạy (iPhone): Safari tạm dừng tab khi màn hình tự khóa nên Auto sẽ dừng. Screen Wake Lock
        // (Safari iOS 16.4+) giữ màn hình sáng chỉ trong lúc Auto chạy và tự nhả khi dừng. Chỉ chạy trên cảm ứng; không ảnh hưởng PC.
        // Trang bị ẩn thì khóa tự nhả: xin lại khi trang hiện lại hoặc khi chạm màn hình (có thể cần thao tác người dùng).
        let tnWakeLock = null, tnWantWake = false, tnWakeReported = false;
        async function wakeLockAcquire() {
            try {
                if (!tnWantWake || tnWakeLock || document.visibilityState !== 'visible') return;
                if (!navigator.wakeLock) {
                    if (!tnWakeReported) { tnWakeReported = true; addLogToUI('🔆 Trình duyệt không hỗ trợ giữ màn hình sáng; hãy tắt tự khóa màn hình khi chạy Auto.', 'warn'); }
                    return;
                }
                const lock = await navigator.wakeLock.request('screen');
                if (!tnWantWake) { lock.release().catch(() => { }); return; }
                tnWakeLock = lock;
                lock.addEventListener('release', () => { if (tnWakeLock === lock) tnWakeLock = null; });
                if (!tnWakeReported) { tnWakeReported = true; addLogToUI('🔆 Đang giữ màn hình sáng trong lúc Auto chạy.', 'run'); }
            } catch (e) { }
        }
        function wakeLockSet(on) {
            try {
                if (!TN_IS_PHONE) return;
                tnWantWake = Boolean(on);
                if (tnWantWake) wakeLockAcquire();
                else if (tnWakeLock) { const lock = tnWakeLock; tnWakeLock = null; lock.release().catch(() => { }); }
            } catch (e) { }
        }
        document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible') wakeLockAcquire(); });
        document.addEventListener('pointerdown', () => { if (tnWantWake && !tnWakeLock) wakeLockAcquire(); }, true);

        function updateBadge(running) {
            wakeLockSet(running);
            const badge = document.getElementById('tn-status-badge');
            const btnMain = document.getElementById('tn-btn-main');
            syncMainBtnVisibility();
            if (!badge || !btnMain) return;

            if (running) {
                badge.className = 'tn-badge tn-badge-running';
                badge.textContent = 'ĐANG LEO AUTO';
                btnMain.className = 'tn-action-btn tn-btn-stop';
                btnMain.textContent = '⏹ TẠM DỪNG AUTO';
            } else {
                badge.className = 'tn-badge tn-badge-ready';
                badge.textContent = 'TẠM DỪNG';
                btnMain.className = 'tn-action-btn tn-btn-start';
                btnMain.textContent = '▶ BẮT ĐẦU AUTO';
            }
        }

        // Có gì để chạy: đã chọn một tính năng chính (chỉ một tính năng mỗi lần, kể cả "Tướng Thần Lâm / Đạp Thiên").
        function hasRunnableSelection() {
            return Boolean(CONFIG.activeFeature);
        }

        // ---- Bản quyền (chỉ iPhone): key + mã thiết bị lưu ở localStorage của trang chính (HUD), gửi sang khung game ----
        function licStoreGet(k) { try { return localStorage.getItem(k) || ''; } catch (e) { return ''; } }
        function licStoreSet(k, v) { try { localStorage.setItem(k, v); } catch (e) { } }
        function licDeviceId() {
            let id = licStoreGet('TN_DEVICE_ID');
            if (!id) {
                try { id = crypto.randomUUID(); } catch (e) { id = 'dev-' + Date.now().toString(36) + Math.random().toString(36).slice(2, 12); }
                licStoreSet('TN_DEVICE_ID', id);
            }
            return id;
        }
        function licNormalizeKey(s) {
            const n = String(s || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
            return /^TN[A-Z0-9]{20}$/.test(n) ? 'TN-' + n.slice(2).match(/.{5}/g).join('-') : '';
        }
        // Nhãn thiết bị hiện ở trang quản trị (chỉ để chủ sở hữu phân biệt máy; không dùng để khóa).
        function licDeviceLabel() {
            const ua = navigator.userAgent || '';
            if (TN_IS_PHONE) { const m = /OS (\d+)[_.](\d+)/.exec(ua); return 'iPhone Safari' + (m ? ' iOS ' + m[1] + '.' + m[2] : ''); }
            const browser = /Edg\//.test(ua) ? 'Edge' : /OPR\//.test(ua) ? 'Opera' : /Chrome\//.test(ua) ? 'Chrome' : 'Trình duyệt';
            const os = /Windows/.test(ua) ? 'Windows' : /Mac OS X/.test(ua) ? 'macOS' : /Linux/.test(ua) ? 'Linux' : '';
            return ('PC ' + browser + (os ? ' ' + os : '')).slice(0, 80);
        }
        function licSendConfig(force) {
            sendCommandToGame('LICENSE_CONFIG', { key: licStoreGet('TN_LICENSE_KEY'), device_id: licDeviceId(), device_label: licDeviceLabel(), force: !!force });
        }
        function licMaskKey(k) { return k ? k.slice(0, 8) + '-•••••-•••••-' + k.slice(-5) : ''; }
        function licShowStatus(d) {
            const ver = document.getElementById('tn-lic-ver');
            if (ver && d.version) ver.textContent = '· Phiên bản ' + d.version;
            const upd = document.getElementById('tn-lic-update');
            if (upd) {
                if (d.update && d.update.version) {
                    upd.style.display = '';
                    upd.textContent = '🆕 Có bản mới ' + d.update.version + (d.update.note ? ' — ' + d.update.note : '') + '. ' + (d.platform === 'phone' ? 'Chạy lại phím tắt cập nhật, đóng hẳn Safari rồi mở lại.' : 'Tải file zip mới, giải nén đè lên thư mục tiện ích rồi tải lại tiện ích.');
                } else { upd.style.display = 'none'; upd.textContent = ''; }
            }
            const el = document.getElementById('tn-lic-status');
            if (!el) return;
            const color = { ok: '#a6e3a1', checking: '#f9e2af', waiting: '#f9e2af', offline: '#fab387', denied: '#f38ba8', nokey: '#f9e2af' }[d.state] || '#cdd6f4';
            el.style.color = color;
            const locked = d.state === 'ok';
            el.textContent = (locked ? '✅ ' : d.state === 'denied' ? '🔒 ' : '') + (d.message || '');
            // Kích hoạt xong: khóa ô nhập và che key (chỉ hiện 5 ký tự đầu/cuối); "Đổi key" mở khóa lại.
            const inp = document.getElementById('tn-lic-key');
            const btn = document.getElementById('tn-lic-save');
            if (inp) {
                const hold = locked || d.state === 'checking' || d.state === 'waiting';
                if (hold) { const k = licStoreGet('TN_LICENSE_KEY'); if (k) { inp.value = licMaskKey(k); inp.disabled = true; } }
                else if (inp.getAttribute('data-unlocking') !== '1' && inp.disabled) { inp.disabled = false; inp.value = licStoreGet('TN_LICENSE_KEY'); }
            }
            if (btn) { btn.textContent = locked ? 'Đổi key' : 'Kích hoạt'; btn.setAttribute('data-mode', locked ? 'change' : 'save'); }
        }

        function sendCommandToGame(action, data = {}) {
            const iframes = document.querySelectorAll('iframe');
            iframes.forEach(f => {
                try {
                    f.contentWindow.postMessage({
                        source: 'TIEN_NGHICH_AUTO_HUD',
                        action: action,
                        ...data
                    }, '*');
                } catch (e) { }
            });

            try {
                window.postMessage({
                    source: 'TIEN_NGHICH_AUTO_HUD',
                    action: action,
                    ...data
                }, '*');
            } catch(e) {}

            try {
                if (window.parent && window.parent !== window) {
                    window.parent.postMessage({
                        source: 'TIEN_NGHICH_AUTO_HUD',
                        action: action,
                        ...data
                    }, '*');
                }
            } catch(e) {}
        }

        window.addEventListener('message', (event) => {
            const data = event.data;
            if (!data || data.source !== 'TIEN_NGHICH_AUTO_GAME') return;

            if (data.action === 'LICENSE_NEED_CONFIG') {
                if (TN_LICENSED && licStoreGet('TN_LICENSE_KEY')) licSendConfig(false);
            } else if (data.action === 'LICENSE_STATUS') {
                if (TN_LICENSED) licShowStatus(data);
            } else if (data.action === 'ROLE_INFO') {
                updateRoleDisplay(data.role);
            } else if (data.action === 'LOG') {
                addLogToUI(data.message, data.logType);
            } else if (data.action === 'QUICK_RUN_SAVED') {
                // Khung HUD cũng chạy cùng script nhưng không có dữ liệu game: bỏ qua báo cáo của nó, chỉ nhận báo cáo của khung game.
                if (data.fromGame === false) return;
                if (data.total) quickTotalSteps = data.total;
                if (data.hourlyTotal) quickHourlyTotal = data.hourlyTotal;
                quickSkippedEvents = Array.isArray(data.skippedEvents) ? data.skippedEvents : [];
                quickEventsPending = Number(data.eventsPending) || 0;
                if (Array.isArray(data.steps)) quickStepsCatalog = data.steps;
                updateQuickButtons(data.completed ? null : data.saved, data.completed ? null : data.active);
            } else if (data.action === 'AUTO_FINISHED') {
                // Tính năng đã hoàn tất: trả nút về trạng thái dừng (dòng kết quả đã được game ghi log).
                CONFIG.running = false;
                updateBadge(false);
                // Nút Quét nhanh không còn ở trạng thái "đang quét" (trạng thái chính xác tới ngay sau từ QUICK_RUN_SAVED).
                updateQuickButtons(quickSavedInfo, null);   // tiến độ đã lưu (nếu còn) do QUICK_RUN_SAVED quyết định
                if (data.message) addLogToUI(data.message, 'run');
            } else if (data.action === 'AUTO_RECONNECT_RELOAD') {
                if (!reconnectTopPrepare(data.reason, data.resume)) return;
                addLogToUI('🔄 [Vào lại game] Đang làm mới trang game để vào lại...', 'run');
                setTimeout(() => location.reload(), 800);
            } else if (data.action === 'AUTO_RECONNECT_GAME_READY') {
                reconnectTopDone();
                // Làm mới trang đặt lại running=false; chỉ chạy lại Auto nếu trước đó đang chạy.
                if (data.resume && !CONFIG.running && hasRunnableSelection()) {
                    CONFIG.running = true;
                    updateBadge(true);
                    sendCommandToGame('UPDATE_CONFIG', { config: CONFIG });
                    sendCommandToGame('TOGGLE_AUTO', { running: true, resumed: true, config: CONFIG });
                    addLogToUI('▶️ [Vào lại game] Auto đã được khởi động lại sau khi vào lại game.', 'run');
                } else {
                    sendCommandToGame('UPDATE_CONFIG', { config: CONFIG });
                    addLogToUI('ℹ️ [Vào lại game] Đã vào lại game; Auto vẫn đang tạm dừng như trước khi ngắt kết nối.', 'info');
                }
            }
        });

        function initUI() {
            if (document.getElementById('tn-auto-hud')) return;
            const style = document.createElement('style');
            style.textContent = `
                #tn-auto-hud {
                    position: fixed;
                    top: 15px;
                    left: 15px;
                    width: 760px;
                    max-width: calc(100vw - 16px);
                    max-height: calc(100vh - 16px);
                    display: flex;
                    flex-direction: column;
                    background: rgba(24, 24, 37, 0.98);
                    color: #cdd6f4;
                    border: 1.5px solid rgba(203, 166, 247, 0.45);
                    border-radius: 14px;
                    box-shadow: 0 12px 48px rgba(0, 0, 0, 0.8), 0 0 16px rgba(203, 166, 247, 0.25);
                    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
                    z-index: 9999999;
                    user-select: none;
                    touch-action: none;
                    overflow: hidden;
                    box-sizing: border-box;
                }
                .tn-body-flex {
                    display: flex;
                    flex-direction: row;
                    gap: 12px;
                    padding: 10px 12px;
                    overflow-y: auto;
                    overflow-x: hidden;
                    flex: 1;
                    min-height: 0;
                }
                .tn-col-left {
                    width: 300px;
                    flex-shrink: 0;
                    display: flex;
                    flex-direction: column;
                    gap: 6px;
                    min-height: 0;
                }
                .tn-col-right {
                    flex: 1;
                    min-width: 400px;
                    display: flex;
                    flex-direction: column;
                    background: rgba(17, 17, 27, 0.55);
                    border: 1px solid rgba(203, 166, 247, 0.22);
                    border-radius: 10px;
                    padding: 10px;
                }
                .tn-feature-panels {
                    flex: 1;
                    overflow-y: auto;
                    max-height: none;
                    min-height: 400px;
                    padding-right: 4px;
                }
                .tn-feature-panels::-webkit-scrollbar { width: 4px; }
                .tn-feature-panels::-webkit-scrollbar-thumb { background: #45475a; border-radius: 4px; }
                
                /* THANH NÚT CHẠY CỐ ĐỊNH Ở ĐÁY (STICKY FOOTER) */
                #tn-hud-footer {
                    background: linear-gradient(180deg, rgba(30, 30, 46, 0.98), rgba(17, 17, 27, 1));
                    padding: 9px 14px;
                    border-top: 1px solid rgba(203, 166, 247, 0.35);
                    box-shadow: 0 -6px 20px rgba(0, 0, 0, 0.7);
                    display: flex;
                    gap: 10px;
                    align-items: center;
                    z-index: 1000;
                    flex-shrink: 0;
                }
                #tn-hud-footer .tn-action-btn {
                    margin-bottom: 0;
                    height: 40px;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    box-shadow: 0 3px 10px rgba(0, 0, 0, 0.4);
                }
                #tn-btn-main {
                    flex: 2;
                    font-size: 13px;
                    letter-spacing: 0.4px;
                    font-weight: 800;
                }
                #tn-btn-main { flex: 1.15; min-width: 0; width: auto; }
                /* Nhóm QUÉT NHANH: nút chính + (khi có tiến độ đã lưu) nút ↺ chạy lại, cùng chiều cao/bo góc/phông với nút chính. */
                #tn-quick-group { flex: 1; min-width: 0; display: flex; gap: 2px; }
                #tn-quick-group .tn-action-btn { margin: 0; width: auto; min-width: 0; }
                #tn-btn-sweep {
                    flex: 1;
                    flex-direction: column;
                    gap: 1px;
                    padding: 0 6px;
                    line-height: 1.1;
                    text-align: center;
                }
                #tn-btn-sweep .tn-qb-main { font-size: 12px; font-weight: 800; letter-spacing: 0.3px; }
                #tn-btn-sweep .tn-qb-sub { font-size: 9.5px; font-weight: 600; opacity: 0.75; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 100%; }
                #tn-btn-quick-fresh {
                    flex: 0 0 38px;
                    font-size: 17px;
                    font-weight: 800;
                    padding: 0;
                    filter: brightness(0.88);
                }
                #tn-btn-hourly .tn-hr-label, #tn-btn-quick-fresh .tn-fr-label { display: none; }
                /* THU HOẠCH: nền sáng nhạt (khác QUÉT NHANH); đang chạy = nền đỏ như nút dừng, hiện bước đang làm. */
                #tn-btn-hourly {
                    flex: 0 0 34px;
                    flex-direction: column;
                    gap: 1px;
                    line-height: 1.1;
                    font-size: 16px;
                    font-weight: 800;
                    padding: 0;
                    border-radius: 0;
                    background: linear-gradient(135deg, #e6ecff, #c9d4f7);
                    color: #11111b;
                }
                #tn-btn-hourly .tn-qb-sub { font-size: 9.5px; font-weight: 600; opacity: 0.75; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 100%; }
                #tn-btn-sweep.tn-qb-running, #tn-btn-hourly.tn-qb-running { background: linear-gradient(135deg, #f38ba8, #eba0ac); color: #11111b; }
                #tn-btn-quick-cfg {
                    flex: 0 0 34px;
                    font-size: 16px;
                    font-weight: 800;
                    padding: 0;
                    filter: brightness(0.88);
                }
                #tn-btn-sweep { border-top-right-radius: 4px; border-bottom-right-radius: 4px; }
                #tn-btn-quick-fresh { border-radius: 4px; }
                #tn-btn-quick-cfg { border-top-left-radius: 4px; border-bottom-left-radius: 4px; }
                #tn-auto-hud::-webkit-scrollbar {
                    width: 4px;
                }
                #tn-auto-hud::-webkit-scrollbar-thumb {
                    background: #45475a;
                    border-radius: 4px;
                }
                .tn-accordion-header {
                    background: linear-gradient(135deg, rgba(69, 71, 90, 0.8), rgba(49, 50, 68, 0.8));
                    padding: 6px 10px;
                    border-radius: 7px;
                    margin-top: 6px;
                    margin-bottom: 5px;
                    cursor: pointer;
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    font-weight: bold;
                    font-size: 11px;
                    color: #cba6f7;
                    border: 1px solid rgba(203, 166, 247, 0.25);
                    user-select: none;
                    transition: background 0.15s, border-color 0.15s;
                }
                .tn-accordion-header:hover {
                    background: linear-gradient(135deg, rgba(88, 91, 112, 0.9), rgba(69, 71, 90, 0.9));
                    border-color: rgba(203, 166, 247, 0.5);
                }
                .tn-accordion-arrow {
                    font-size: 9px;
                    color: #f5c2e7;
                    font-weight: bold;
                    transition: transform 0.2s;
                }
                .tn-accordion-content {
                    transition: all 0.2s ease-in-out;
                }
                .tn-accordion-content.tn-collapsed {
                    display: none !important;
                }
                #tn-hud-header {
                    padding: 7px 10px;
                    background: linear-gradient(135deg, #45475a, #313244);
                    border-top-left-radius: 12px;
                    border-top-right-radius: 12px;
                    display: flex;
                    align-items: center;
                    justify-content: space-between;
                    border-bottom: 1px solid rgba(255, 255, 255, 0.1);
                    touch-action: none;
                }
                #tn-hud-title {
                    font-weight: bold;
                    font-size: 11.5px;
                    color: #f5c2e7;
                    display: flex;
                    align-items: center;
                    gap: 4px;
                }
                #tn-hud-body {
                    padding: 8px 10px;
                    font-size: 11px;
                }
                .tn-badge {
                    font-size: 10px;
                    padding: 2px 8px;
                    border-radius: 10px;
                    font-weight: bold;
                }
                .tn-badge-ready { background: #585b70; color: #cdd6f4; }
                .tn-badge-running { background: #a6e3a1; color: #11111b; animation: tnPulse 1.5s infinite; }
                /* Hiệu ứng tải (danh sách banner hero / skin): vòng xoay nhỏ + khung xương nhấp nháy. */
                @keyframes tnSpin { to { transform: rotate(360deg); } }
                @keyframes tnShimmer { 0% { opacity: 0.35; } 50% { opacity: 0.75; } 100% { opacity: 0.35; } }
                .tn-spin {
                    display: inline-block; width: 10px; height: 10px; margin-right: 6px; vertical-align: -1px;
                    border: 2px solid rgba(203, 166, 247, 0.28); border-top-color: #cba6f7; border-radius: 50%;
                    animation: tnSpin 0.8s linear infinite;
                }
                .tn-skeleton {
                    border-left: 3px solid rgba(203, 166, 247, 0.35); border-radius: 6px; padding: 6px 8px;
                    background: rgba(17, 17, 27, 0.55); animation: tnShimmer 1.2s ease-in-out infinite;
                }
                .tn-skeleton i { display: block; height: 8px; border-radius: 4px; background: rgba(166, 173, 200, 0.28); }
                .tn-skeleton i + i { width: 55%; height: 6px; margin-top: 6px; }
                @media (prefers-reduced-motion: reduce) { .tn-spin, .tn-skeleton { animation: none; } }
                @keyframes tnPulse {
                    0% { opacity: 0.8; }
                    50% { opacity: 1; filter: drop-shadow(0 0 5px #a6e3a1); }
                    100% { opacity: 0.8; }
                }
                .tn-role-card {
                    background: rgba(17, 17, 27, 0.85);
                    border-radius: 8px;
                    padding: 8px 10px;
                    margin-bottom: 8px;
                    border: 1px solid rgba(255, 255, 255, 0.05);
                }
                .tn-role-name { font-weight: bold; color: #89b4fa; font-size: 13px; margin-bottom: 2px; }
                .tn-role-info { font-size: 11px; color: #a6adc8; }
                
                .tn-section-title {
                    font-size: 11px;
                    font-weight: bold;
                    color: #fab387;
                    margin: 8px 0 4px 0;
                    text-transform: uppercase;
                    letter-spacing: 0.5px;
                }
                .tn-tab-bar {
                    display: flex;
                    background: rgba(17, 17, 27, 0.95);
                    border-radius: 8px;
                    padding: 3px;
                    margin: 4px 0 8px 0;
                    border: 1px solid rgba(203, 166, 247, 0.3);
                    gap: 3px;
                }
                .tn-tab-btn {
                    flex: 1;
                    padding: 6px 1px;
                    border: none;
                    background: transparent;
                    color: #a6adc8;
                    font-size: 10px;
                    font-weight: bold;
                    border-radius: 6px;
                    cursor: pointer;
                    text-align: center;
                    transition: all 0.15s ease;
                }
                .tn-tab-btn:hover {
                    color: #f5c2e7;
                    background: rgba(203, 166, 247, 0.12);
                }
                .tn-tab-btn.active {
                    background: linear-gradient(135deg, rgba(203, 166, 247, 0.4), rgba(180, 190, 254, 0.4));
                    color: #fff;
                    border: 1px solid rgba(203, 166, 247, 0.65);
                    box-shadow: 0 2px 6px rgba(0, 0, 0, 0.4);
                }
                .tn-tab-panel {
                    display: none;
                }
                .tn-tab-panel.active {
                    display: block;
                }
                #tn-auto-hud.tn-user-resized .tn-col-left,
                #tn-auto-hud.tn-user-resized .tn-col-right {
                    min-height: 0;
                }
                #tn-auto-hud.tn-user-resized .tn-feature-panels {
                    display: flex;
                    flex-direction: column;
                    max-height: none;
                    min-height: 0;
                }
                #tn-auto-hud.tn-user-resized .tn-tab-panel.active {
                    flex: 1;
                    display: flex;
                    flex-direction: column;
                    min-height: 0;
                }
                #tn-auto-hud.tn-user-resized .tn-tab-panel.active > .tn-opt-list {
                    flex: 1;
                    max-height: none;
                    min-height: 0;
                }
                #tn-auto-hud.tn-user-resized .tn-tab-panel.active > div:first-child:not(.tn-opt-list) {
                    flex: 1;
                }
                .tn-opt-list {
                    display: flex;
                    flex-direction: column;
                    gap: 5px;
                    margin-bottom: 10px;
                    max-height: none;
                    overflow-y: auto;
                    padding-right: 4px;
                }
                .tn-opt-list::-webkit-scrollbar { width: 4px; }
                .tn-opt-list::-webkit-scrollbar-thumb { background: #45475a; border-radius: 4px; }
                .tn-opt-item {
                    display: flex;
                    align-items: center;
                    justify-content: space-between;
                    background: rgba(30, 30, 46, 0.65);
                    padding: 6px 10px;
                    border-radius: 6px;
                    cursor: pointer;
                    transition: background 0.15s;
                }
                .tn-opt-item:hover { background: rgba(49, 50, 68, 0.85); }
                .tn-opt-item input[type="checkbox"] {
                    accent-color: #cba6f7;
                    cursor: pointer;
                    transform: scale(1.15);
                }
                .tn-feat-title { font-weight: bold; display: flex; align-items: center; gap: 6px; }
                .tn-gear-btn {
                    background: rgba(69, 71, 90, 0.7);
                    color: #cdd6f4;
                    border: 1px solid rgba(255, 255, 255, 0.12);
                    border-radius: 5px;
                    padding: 0 5px;
                    font-size: 11px;
                    line-height: 16px;
                    cursor: pointer;
                }
                .tn-gear-btn:hover { background: rgba(203, 166, 247, 0.35); color: #fff; }
                .tn-feat-desc { font-size: 9.5px; color: #a6adc8; margin-top: 2px; line-height: 1.3; }
                .tn-feat-cfg { font-size: 9.5px; color: #f9e2af; margin-top: 2px; line-height: 1.3; }
                .tn-feat-cfg:empty { display: none; }
                #tn-settings-overlay {
                    position: absolute; inset: 0; z-index: 1002;
                    background: rgba(0, 0, 0, 0.55);
                    display: none; align-items: center; justify-content: center;
                }
                #tn-settings-overlay.open { display: flex; }
                #tn-settings-card {
                    width: min(340px, 90%);
                    background: #1e1e2e; color: #cdd6f4;
                    border: 1px solid rgba(203, 166, 247, 0.5);
                    border-radius: 10px; padding: 10px 12px;
                    box-shadow: 0 8px 24px rgba(0, 0, 0, 0.6);
                    box-sizing: border-box;
                    max-height: calc(100% - 16px);
                    display: flex; flex-direction: column;
                }
                #tn-settings-card .tn-set-events { flex: 0 0 auto; }
                #tn-settings-card .tn-set-btnrow { display: flex; gap: 6px; flex: 0 0 auto; margin-top: 6px; }
                #tn-settings-card .tn-set-btnrow .tn-action-btn { flex: 1 1 0; width: auto; min-width: 0; margin: 0; padding: 6px 0; }
                #tn-settings-card .tn-set-list { flex: 1 1 auto; min-height: 0; overflow-y: auto; padding-right: 2px; }
                #tn-settings-card .tn-set-list::-webkit-scrollbar { width: 4px; }
                #tn-settings-card .tn-set-list::-webkit-scrollbar-thumb { background: #45475a; border-radius: 4px; }
                #tn-settings-card .tn-set-head, #tn-settings-card > .tn-action-btn, #tn-settings-card > .tn-set-hint { flex: 0 0 auto; }
                #tn-settings-card .tn-set-head { display: flex; justify-content: space-between; align-items: center; font-weight: bold; font-size: 12px; margin-bottom: 8px; color: #cba6f7; }
                #tn-settings-card .tn-set-close { background: transparent; border: 0; color: #a6adc8; font-size: 14px; cursor: pointer; }
                #tn-settings-card .tn-set-field { display: flex; justify-content: space-between; align-items: center; gap: 8px; padding: 6px 8px; margin-bottom: 5px; background: rgba(17, 17, 27, 0.7); border-radius: 6px; }
                #tn-settings-card .tn-set-label { font-size: 10.5px; font-weight: bold; }
                #tn-settings-card .tn-set-hint { font-size: 9.5px; color: #a6adc8; margin-top: 2px; line-height: 1.3; }
                #tn-settings-card input[type="number"] { width: 56px; padding: 2px 4px; background: #181825; color: #cdd6f4; border: 1px solid #45475a; border-radius: 4px; }
                #tn-settings-card input[type="checkbox"] { accent-color: #cba6f7; transform: scale(1.15); cursor: pointer; }
                .tn-action-btn {
                    width: 100%;
                    padding: 8px 0;
                    border: none;
                    border-radius: 8px;
                    font-weight: bold;
                    font-size: 12px;
                    cursor: pointer;
                    margin-bottom: 6px;
                    transition: transform 0.1s, filter 0.15s;
                }
                .tn-action-btn:active { transform: scale(0.98); }
                .tn-btn-start { background: linear-gradient(135deg, #a6e3a1, #94e2d5); color: #11111b; }
                .tn-btn-stop { background: linear-gradient(135deg, #f38ba8, #eba0ac); color: #11111b; }
                .tn-btn-sweep { background: linear-gradient(135deg, #f9e2af, #fab387); color: #11111b; }
                #tn-log-content {
                    background: #11111b;
                    border-radius: 6px;
                    padding: 6px 8px;
                    flex: 1 1 0;
                    min-height: 0;
                    overflow-y: auto;
                    font-family: Consolas, monospace;
                    font-size: 10px;
                    border: 1px solid rgba(255, 255, 255, 0.05);
                }
                #tn-log-content::-webkit-scrollbar { width: 4px; }
                #tn-log-content::-webkit-scrollbar-thumb { background: #313244; }
                /* Thiết kế thống nhất PC + iPhone: thẻ hai/ba tab (Nhật ký | Tính năng | Cài đặt). Phần riêng từng nền tảng nằm ở platform/pc và platform/phone (build chọn một). */
                #tn-auto-hud {
                    touch-action: pan-y; border-radius: 16px; overflow: hidden;
                    background: #181825; box-shadow: none; border: 1.5px solid rgba(203, 166, 247, 0.55);
                    contain: layout paint style;
                }
                #tn-hud-header { padding: 8px 10px; min-height: 28px; flex-shrink: 0; }
                /* Thẻ tài khoản (đã dời ra giữa đầu bảng và thân): một dòng, tên bên trái, Lv | LC bên phải. */
                #tn-auto-hud .tn-role-card {
                    display: flex; align-items: center; justify-content: space-between; gap: 10px; flex-shrink: 0;
                    margin: 0; padding: 6px 12px; border: none; border-radius: 0; background: #11111b;
                    border-bottom: 1px solid rgba(255, 255, 255, 0.08);
                }
                #tn-auto-hud .tn-role-name { margin: 0; min-width: 0; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
                #tn-auto-hud .tn-role-info { white-space: nowrap; flex-shrink: 0; font-size: 11.5px; }
                #tn-hud-body { flex: 1 1 auto; min-height: 0; }
                #tn-hud-title { font-size: 12.5px; gap: 6px; }
                .tn-body-flex { flex-direction: column; gap: 8px; padding: 8px; overflow-y: auto; -webkit-overflow-scrolling: touch; }
                .tn-col-right { order: 1; min-width: 0; width: 100%; box-sizing: border-box; padding: 8px; }
                .tn-col-left { order: 2; width: 100%; flex-shrink: 0; }
                .tn-feature-panels { min-height: 0; overflow-y: visible; padding-right: 0; }
                .tn-col-right .tn-section-title span:last-child { display: none; }
                /* Hai tab ở đầu thẻ: Nhật ký / Tính năng (một tab một lúc). */
                #tn-auto-hud.tn-mview-chat .tn-col-right,
                #tn-auto-hud.tn-mview-chat .tn-log-title { display: none !important; }
                /* Tab Nhật ký chỉ giữ ô "Log chi tiết" (trên khung log); các tùy chọn toàn cục khác ở tab Tính năng. */
                #tn-auto-hud.tn-mview-chat .tn-global-opts > div,
                #tn-auto-hud.tn-mview-chat .tn-global-opts > label:not(.tn-opt-verbose-row) { display: none !important; }
                #tn-auto-hud.tn-mview-chat .tn-global-opts {
                    order: 0; margin: 0 !important; border: none !important; border-bottom: 1px solid rgba(255, 255, 255, 0.08) !important;
                    border-radius: 0 !important; background: #11111b !important; padding: 2px 6px !important;
                }
                #tn-auto-hud.tn-mview-chat .tn-global-opts .tn-opt-verbose-row { margin: 0 !important; }
                #tn-auto-hud.tn-mview-chat #tn-log-content { order: 1; }
                /* Hộp Bản quyền: ẩn hẳn ở build không có bản quyền (bản PC dev của chủ sở hữu); chỉ hiện ở tab Cài đặt. */
                ${TN_LICENSED ? '' : '.tn-license-row { display: none !important; }'}
                #tn-auto-hud.tn-mview-chat .tn-license-row { display: none !important; }
                #tn-auto-hud.tn-mview-feat .tn-opt-verbose-row, #tn-auto-hud.tn-mview-set .tn-opt-verbose-row { display: none !important; }
                /* Tab Tính năng: chỉ danh sách tính năng. Tab Cài đặt: "Chạy song song toàn cục" + Probe (cột trái), không có danh sách/nhật ký. */
                #tn-auto-hud.tn-mview-feat .tn-col-left { display: none !important; }
                #tn-auto-hud.tn-mview-set .tn-col-right, #tn-auto-hud.tn-mview-set .tn-log-title, #tn-auto-hud.tn-mview-set #tn-log-content { display: none !important; }
                #tn-auto-hud.tn-mview-chat .tn-col-left { flex: 1 1 auto; min-height: 0; display: flex; flex-direction: column; }
                #tn-auto-hud.tn-mview-chat .tn-body-flex { overflow: hidden; }
                #tn-auto-hud.tn-mview-feat .tn-log-title,
                #tn-auto-hud.tn-mview-feat #tn-log-content { display: none !important; }
                #tn-log-content { flex: 1 1 auto; min-height: 0; height: auto; font-size: 11.5px; padding: 8px 10px; -webkit-overflow-scrolling: touch; overscroll-behavior: contain; }
                #tn-hud-title > span:not(#tn-status-badge), #tn-hud-title > img { display: none; }
                #tn-mtabs { display: flex; gap: 3px; background: #11111b; border-radius: 18px; padding: 3px; margin-right: 8px; }
                #tn-mtabs button {
                    border: none; border-radius: 15px; padding: 7px 12px; font-size: 12.5px; font-weight: 700;
                    background: transparent; color: #a6adc8; white-space: nowrap;
                }
                #tn-mtabs button.active { background: #cba6f7; color: #11111b; }
                #tn-hud-header { border-radius: 16px 16px 0 0; }
                #tn-hud-footer { padding: 8px; gap: 6px; border-radius: 0 0 16px 16px; }
                #tn-hud-footer .tn-action-btn { height: 44px; margin: 0; }
                #tn-btn-main { font-size: 12px; padding: 0 6px; }
                #tn-btn-sweep .tn-qb-sub, #tn-btn-hourly .tn-qb-sub { display: block; }   /* luôn hiện dòng nhỏ: lúc rảnh = số bước sẽ chạy, lúc chạy = bước đang làm */
                #tn-btn-hourly .tn-qb-main { font-size: 12px; font-weight: 800; letter-spacing: 0.3px; white-space: nowrap; }
                /* BẮT ĐẦU AUTO chỉ cho tab Tính năng (và để dừng khi đang chạy một tính năng riêng) */
                #tn-auto-hud.tn-mview-chat.tn-main-idle #tn-btn-main { display: none; }
                #tn-auto-hud.tn-mview-chat.tn-main-idle #tn-hud-footer::after { display: none; }
                /* Hai hàng. Hàng 1: ⏱ THU HOẠCH | QUÉT NHANH | ⚙ (cài đặt, bên phải). Khi có tiến độ Quét nhanh đã lưu, QUÉT NHANH tách làm hai nút
                   ⏯ TIẾP TỤC | ↺ CHẠY LẠI (không còn nút ↺ lẻ). Hàng 2: BẮT ĐẦU AUTO một mình, rộng hết hàng. Nhóm Quét nhanh "tan" ra (display: contents)
                   để từng nút xếp theo order; ::after là điểm ngắt hàng. */
                #tn-hud-footer { flex-wrap: wrap; }
                #tn-quick-group { display: contents; }
                #tn-btn-sweep { order: 2; flex: 1 1 0; font-size: 12px; border-radius: 4px; }
                #tn-btn-quick-fresh { order: 3; flex: 0 0 44px; font-size: 18px; padding: 0; border-radius: 4px; }
                #tn-btn-hourly { order: 1; flex: 0 0 116px; width: 116px; min-width: 0; padding: 0 4px; font-size: 12px; white-space: nowrap; overflow: hidden; border-radius: 4px; }
                /* Độ rộng cố định: tên bước dài thì cắt bằng "...", nút không co giãn theo chữ. */
                #tn-btn-sweep { min-width: 0; overflow: hidden; }
                #tn-btn-sweep .tn-qb-main, #tn-btn-hourly .tn-qb-main, #tn-btn-sweep .tn-qb-sub, #tn-btn-hourly .tn-qb-sub { max-width: 100%; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
                #tn-btn-quick-cfg { order: 4; flex: 0 0 44px; border-radius: 4px; }
                #tn-btn-hourly .tn-hr-label { display: inline; white-space: pre; }
                #tn-hud-footer::after { content: ''; order: 5; flex: 0 0 100%; height: 0; }
                #tn-btn-main { order: 6; flex: 1 1 100%; }
                /* Chưa vào game: chỉ header + dòng nhắc, ẩn mọi tính năng/nút chạy. */
                #tn-wait-game { display: none; }
                @keyframes tnReadyIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: none; } }
                #tn-auto-hud.tn-ready-anim #tn-hud-body, #tn-auto-hud.tn-ready-anim .tn-role-card,
                #tn-auto-hud.tn-ready-anim #tn-hud-footer, #tn-auto-hud.tn-ready-anim #tn-mtabs { animation: tnReadyIn 0.4s ease both; }
                #tn-auto-hud.tn-wait-game #tn-wait-game { display: block; padding: 18px 14px; text-align: center; font-size: 13.5px; font-weight: 700; color: #f9e2af; background: #11111b; }
                #tn-auto-hud.tn-reconnecting #tn-wait-game { color: #89dceb; animation: tnPulse 1.5s infinite; }
                #tn-auto-hud.tn-wait-game { height: auto !important; min-height: 0; }
                #tn-auto-hud.tn-wait-game #tn-hud-body, #tn-auto-hud.tn-wait-game .tn-role-card, #tn-auto-hud.tn-wait-game #tn-hud-footer,
                #tn-auto-hud.tn-wait-game #tn-mtabs { display: none !important; }
                #tn-auto-hud.tn-wait-game #tn-hud-header { border-radius: 16px; }
                /* Mục Probe (chỉ bản dev): dưới "Chạy song song toàn cục", chỉ ở tab Tính năng. */
                .tn-probe-sec { background: rgba(17,17,27,0.7); border-radius: 8px; padding: 6px 8px; border: 1px dashed rgba(137,180,250,0.4); }
                .tn-log-btns { display: flex; gap: 6px; align-items: stretch; }
                .tn-log-btn {
                    flex: 1 1 0; min-width: 0; min-height: 40px; padding: 8px 10px; white-space: nowrap;
                    font: inherit; font-size: 12px; font-weight: 700; color: #cdd6f4; cursor: pointer;
                    background: linear-gradient(180deg, #45475a, #313244); border: 1px solid rgba(203, 166, 247, 0.55); border-radius: 8px;
                    box-shadow: 0 2px 6px rgba(0, 0, 0, 0.35);
                }
                .tn-log-btn:hover { background: linear-gradient(180deg, #585b70, #45475a); }
                .tn-log-btn:active { transform: translateY(1px); box-shadow: none; }
                .tn-log-btn-danger { color: #f38ba8; border-color: rgba(243, 139, 168, 0.55); }
                .tn-log-btn-ok { color: #11111b; background: #a6e3a1; border-color: #a6e3a1; }
                .tn-log-tools { background: rgba(17,17,27,0.7); border-radius: 8px; padding: 6px 8px; border: 1px dashed rgba(249,226,175,0.4); }
                #tn-auto-hud.tn-mview-chat .tn-probe-sec, #tn-auto-hud.tn-mview-feat .tn-probe-sec,
                #tn-auto-hud.tn-mview-chat .tn-log-tools, #tn-auto-hud.tn-mview-feat .tn-log-tools { display: none; }
            `;
            document.head.appendChild(style);
            // PC: CSS riêng (HUD hiện sẵn bên trái, kéo bằng header, đổi cỡ bằng hai góc dưới, nút thu nhỏ).
            const stylePlatform = document.createElement('style');
            stylePlatform.textContent = `
                .tn-opt-gfx-row { display: none; } /* "Nâng cao đồ họa" chỉ dành cho iPhone */
                .tn-resize-handle {
                    position: absolute;
                    bottom: 1px;
                    width: 18px;
                    height: 18px;
                    z-index: 1001;
                    touch-action: none;
                }
                .tn-resize-left {
                    left: 1px;
                    cursor: nesw-resize;
                }
                .tn-resize-right {
                    right: 1px;
                    cursor: nwse-resize;
                }
                .tn-resize-left::after,
                .tn-resize-right::after {
                    position: absolute;
                    bottom: 4px;
                    width: 8px;
                    height: 8px;
                    content: "";
                    border-bottom: 2px solid #cba6f7;
                }
                .tn-resize-left::after {
                    left: 4px;
                    border-left: 2px solid #cba6f7;
                }
                .tn-resize-right::after {
                    right: 4px;
                    border-right: 2px solid #cba6f7;
                }
                #tn-auto-hud.tn-wait-game .tn-resize-handle { display: none !important; }
                #tn-auto-hud { top: 15px; left: 15px; width: 650px; height: 600px; max-width: calc(100vw - 16px); max-height: calc(100vh - 16px); }
                #tn-hud-title > span:not(#tn-status-badge) { display: inline; }
                #tn-hud-header { cursor: move; }
                #tn-btn-hourly { flex: 0 0 170px; width: 170px; font-size: 13px; }
                #tn-hud-min { display: inline-block; background: #11111b; color: #cdd6f4; border: none; border-radius: 15px; width: 30px; height: 28px; font-size: 16px; font-weight: 700; line-height: 1; cursor: pointer; margin-left: 6px; }
                #tn-hud-min:hover { background: #45475a; }
                #tn-auto-hud.tn-hud-mini { height: auto !important; min-height: 0; width: 400px !important; }
                #tn-auto-hud.tn-hud-mini .tn-resize-handle, #tn-auto-hud.tn-hud-mini #tn-btn-quick-cfg { display: none !important; }
                #tn-auto-hud.tn-hud-mini #tn-hud-body, #tn-auto-hud.tn-hud-mini .tn-role-card, #tn-auto-hud.tn-hud-mini #tn-mtabs { display: none !important; }
                #tn-auto-hud.tn-hud-mini.tn-main-idle #tn-btn-main, #tn-auto-hud.tn-hud-mini.tn-main-idle #tn-hud-footer::after { display: none; }
                #tn-auto-hud.tn-hud-mini #tn-hud-footer { border-top: none; border-radius: 0 0 16px 16px; }
                /* Hộp Bản quyền: cùng cỡ với các khối khác (khối ⚡ Chạy song song toàn cục). Bản iPhone giữ cỡ to cho ngón tay (ui-markup.js). */
                .tn-license-row { padding: 6px 8px !important; margin-bottom: 4px !important; }
                .tn-license-row #tn-lic-status { font-size: 11.5px !important; margin-bottom: 4px !important; }
                .tn-license-row #tn-lic-key { font-size: 12px !important; padding: 4px 8px !important; min-height: 28px !important; }
                .tn-license-row button { font-size: 12px !important; min-height: 28px !important; padding: 2px 8px !important; }
                .tn-license-row > div:last-child { margin-top: 4px !important; }
                #tn-settings-card { width: 460px; max-width: calc(100% - 20px); }
            `;
            document.head.appendChild(stylePlatform);
            const hud = document.createElement('div');
            hud.id = 'tn-auto-hud';
            hud.innerHTML = `
                <div id="tn-hud-header">
                    <div id="tn-hud-title">
                        <img src="${APP_ICON_B64}" style="width:16px; height:16px; border-radius:50%; object-fit:cover; display:inline-block;" alt="icon">
                        <span>⚡ Tiên Nghịch Auto</span>
                        <span id="tn-status-badge" class="tn-badge tn-badge-ready">TẠM DỪNG</span>
                    </div>
                    <div id="tn-mtabs"><button type="button" data-mview="chat" title="Nhật ký"><span>📜</span><span class="tn-mt-lb"> Nhật ký</span></button><button type="button" data-mview="feat" title="Tính năng"><span>⚔️</span><span class="tn-mt-lb"> Tính năng</span></button><button type="button" data-mview="set" title="Cài đặt"><span>⚙️</span><span class="tn-mt-lb"> Cài đặt</span></button></div>
                </div>

                <!-- Chưa vào game (màn hình đăng nhập): chỉ hiện dòng nhắc này; class tn-wait-game gỡ khi nhận được Lv/LC của nhân vật. -->
                <div id="tn-wait-game">🎮 Hãy vào game để bắt đầu auto !</div>

                <!-- KHU VỰC THÂN HUD BỐ CỤC 2 CỘT DÀN NGANG -->
                <div id="tn-hud-body" class="tn-body-flex">
                    <!-- CỘT TRÁI: NHÂN VẬT, TÙY CHỌN CHUNG & NHẬT KÝ -->
                    <div class="tn-col-left">
                        <!-- THẺ NHÂN VẬT -->
                        <div class="tn-role-card">
                            <div id="tn-role-name" class="tn-role-name">Đang kết nối nhân vật...</div>
                            <div id="tn-role-info" class="tn-role-info">Lv: -- | LC: --</div>
                        </div>

                        <!-- BẢN QUYỀN (build có bản quyền; bản PC dev ẩn hàng này bằng CSS trong ui-styles.js) -->
                        <div class="tn-license-row" style="background:rgba(17,17,27,0.7); border-radius:8px; padding:8px; border:1px dashed rgba(203,166,247,0.45); margin-bottom:6px;">
                            <div style="font-size:9.5px; font-weight:bold; color:#cba6f7; margin-bottom:4px; text-transform:uppercase;">🔑 Bản quyền: <span id="tn-lic-ver" style="color:#a6adc8; text-transform:none; font-weight:normal;"></span></div>
                            <div id="tn-lic-status" style="font-size:12px; color:#f9e2af; margin-bottom:6px; word-break:break-word; line-height:1.35;">Chưa nhập key bản quyền.</div>
                            <div id="tn-lic-update" style="display:none; font-size:12px; color:#89dceb; margin-bottom:6px; word-break:break-word; line-height:1.35;"></div>
                            <input id="tn-lic-key" type="text" autocapitalize="characters" autocomplete="off" autocorrect="off" spellcheck="false" placeholder="TN-XXXXX-XXXXX-XXXXX-XXXXX" style="width:100%; box-sizing:border-box; font-size:16px; padding:8px; min-height:40px; border-radius:6px; border:1px solid #45475a; background:#181825; color:#cdd6f4;">
                            <div style="display:flex; gap:6px; margin-top:6px; flex-wrap:wrap;">
                                <button id="tn-lic-save" type="button" style="flex:1 1 120px; min-height:40px; border:0; border-radius:6px; background:#cba6f7; color:#1e1e2e; font-weight:bold;">Kích hoạt</button>
                                <button id="tn-lic-recheck" type="button" style="flex:1 1 120px; min-height:40px; border:0; border-radius:6px; background:#313244; color:#cdd6f4;">🔄 Kiểm tra lại</button>
                            </div>
                        </div>

                        <!-- TÙY CHỌN TOÀN CỤC CHẠY KÈM -->
                        <div class="tn-global-opts" style="background:rgba(17,17,27,0.7); border-radius:8px; padding:6px 8px; border:1px dashed rgba(166,227,161,0.35);">
                            <div style="font-size:9.5px; font-weight:bold; color:#a6e3a1; margin-bottom:4px; text-transform:uppercase;">⚡ Chạy song song toàn cục:</div>
                            <label class="tn-opt-item" style="padding:4px 8px; margin-bottom:3px;">
                                <span style="font-weight:bold; color:#cdd6f4;">⏩ Bỏ qua trận đánh thần tốc (Skip)</span>
                                <input type="checkbox" id="tn-opt-skip" ${CONFIG.autoSkipFight ? 'checked' : ''}>
                            </label>
                            <label class="tn-opt-item" style="padding:4px 8px; margin-bottom:3px;">
                                <span style="font-weight:bold; color:#cdd6f4;">🔌 Tự vào lại game khi bị ngắt kết nối</span>
                                <input type="checkbox" id="tn-opt-reconnect" ${CONFIG.autoReconnect ? 'checked' : ''}>
                            </label>
                            <label class="tn-opt-item tn-opt-gfx-row" style="padding:4px 8px; margin-bottom:3px;">
                                <span style="font-weight:bold; color:#cdd6f4;">✨ Nâng cao đồ họa (nét x3 + 60 khung/giây)</span>
                                <input type="checkbox" id="tn-opt-gfx" ${CONFIG.gfxBoost ? 'checked' : ''}>
                            </label>
                            
                        </div>

                        <!-- LOG CHI TIẾT ĐÃ LƯU: sao chép / xóa (tab Cài đặt). Bản rút gọn (build-content.js --release) cắt hẳn khối đánh dấu ngay dưới đây khỏi file (xem applyReleaseFlag trong build-content.js), không chỉ ẩn bằng CSS/JS. -->
                        

                        <!-- NHẬT KÝ HOẠT ĐỘNG CỘT TRÁI -->
                        <div class="tn-log-title" style="font-weight:bold; color:#888; font-size:10px; margin: 6px 0 3px 0;">NHẬT KÝ HOẠT ĐỘNG:</div>
                        <div id="tn-log-content"></div>
                    </div>

                    <!-- CỘT PHẢI: BẢNG CHỨC NĂNG 2 TAB DÀN NGANG -->
                    <div class="tn-col-right">
                        <div class="tn-section-title" style="margin:0 0 6px 0; font-size:12px; display:flex; justify-content:space-between; align-items:center;">
                            <span>⚙️ BẢNG TÍNH NĂNG TỰ ĐỘNG (2 TAB)</span>
                            <span style="font-size:10px; color:#a6adc8; font-weight:normal;">(Mỗi lần tải lại là mới)</span>
                        </div>

                        <!-- THANH ĐIỀU HƯỚNG 2 TAB -->
                        <div class="tn-tab-bar">
                            <button class="tn-tab-btn active" data-tab="tinhNang" title="Mọi tính năng chạy riêng (Đạo Thành, Lịch Luyện, Ma Đạo gộp chung)">⚔️ Tính Năng</button>
                            <button class="tn-tab-btn" data-tab="banner" title="Sự kiện đang mở (banner tướng Thần Lâm / Đạp Thiên)">🎴 Sự kiện đang mở</button>
                        </div>

                        <!-- DANH SÁCH TÍNH NĂNG TRONG 2 TAB -->
                        <div class="tn-feature-panels">
                            <!-- TAB: TÍNH NĂNG (gộp Đạo Thành + Lịch Luyện + Ma Đạo) -->
                            <div id="tn-tab-panel-tinh-nang" class="tn-tab-panel active">
                                <div class="tn-opt-list">
                                    <label class="tn-opt-item" style="border-left: 3px solid #a6e3a1;">
                                        <div style="min-width:0; flex:1;">
                                            <div class="tn-feat-title" style="color:#a6e3a1;"><span class="tn-feat-name">🏟️ Đấu Tiên Đài</span><button type="button" class="tn-gear-btn" data-gear="autoArena" title="Cài đặt">⚙</button></div>
                                            <div class="tn-feat-desc">Chọn đối thủ lực chiến thấp → Khiêu chiến tới giới hạn trận.</div>
                                            <div class="tn-feat-cfg" data-cfg-for="autoArena"></div>
                                        </div>
                                        <input type="checkbox" class="tn-mutex-feature" data-key="autoArena" ${CONFIG.activeFeature === 'autoArena' ? 'checked' : ''}>
                                    </label>
                                    <label class="tn-opt-item" style="border-left: 3px solid #f5c2e7;">
                                        <div style="min-width:0; flex:1;">
                                            <div class="tn-feat-title" style="color:#f5c2e7;"><span class="tn-feat-name">🗼 Tự Động Leo Thông Thiên Tháp</span></div>
                                            <div class="tn-feat-desc">Khiêu chiến liên tục từng tầng (bỏ qua hoạt ảnh) → tới khi bấm Tạm Dừng.</div>
                                            <div class="tn-feat-cfg" data-cfg-for="autoTongTian"></div>
                                        </div>
                                        <input type="checkbox" class="tn-mutex-feature" data-key="autoTongTian" ${CONFIG.activeFeature === 'autoTongTian' ? 'checked' : ''}>
                                    </label>
                                    <label class="tn-opt-item" style="border-left: 3px solid #94e2d5;">
                                        <div style="min-width:0; flex:1;">
                                            <div class="tn-feat-title" style="color:#94e2d5;"><span class="tn-feat-name">🏯 Cổ Thần Địa</span></div>
                                            <div class="tn-feat-desc">Xếp tướng → đánh 4 ải quanh + ải giữa → dùng vật phẩm đặc biệt → nhận thưởng Diệt Thủ Hộ.</div>
                                            <div class="tn-feat-cfg" data-cfg-for="autoOtherTrials"></div>
                                        </div>
                                        <input type="checkbox" class="tn-mutex-feature" data-key="autoOtherTrials" ${CONFIG.activeFeature === 'autoOtherTrials' ? 'checked' : ''}>
                                    </label>
                                    <label class="tn-opt-item" style="border-left: 3px solid #89b4fa;">
                                        <div style="min-width:0; flex:1;">
                                            <div class="tn-feat-title" style="color:#89b4fa;"><span class="tn-feat-name">🌌 Vực U Minh</span></div>
                                            <div class="tn-feat-desc">Đổi trận pháp → vượt ải thu thập bí bảo.</div>
                                            <div class="tn-feat-cfg" data-cfg-for="autoClimbYMAbyss"></div>
                                        </div>
                                        <input type="checkbox" class="tn-mutex-feature" data-key="autoClimbYMAbyss" ${CONFIG.activeFeature === 'autoClimbYMAbyss' ? 'checked' : ''}>
                                    </label>
                                </div>
                            </div>

                            <!-- TAB: SỰ KIỆN ĐANG MỞ -->
                            <div id="tn-tab-panel-banner" class="tn-tab-panel">
                                <div class="tn-opt-list">
                                    <div class="tn-feat-desc" style="padding:2px 4px 6px;">💡 Chỉ hiện khi sự kiện đang mở và không mua items bằng tiền</div>
                                    <label class="tn-opt-item" style="border-left: 3px solid #cba6f7;">
                                        <div style="min-width:0; flex:1;">
                                            <div class="tn-feat-title" style="color:#cba6f7;"><span class="tn-feat-name">🎴 Tướng Thần Lâm / Đạp Thiên</span></div>
                                            <div class="tn-feat-desc">Mọi banner đang mở: nhận quà (miễn phí + Tiên Ngọc ≤ ${CONFIG.bannerGoldPrice || 300}) → Chiêu mộ → Thí Luyện → nhiệm vụ → Chiến Lệnh.</div>
                                            <div class="tn-feat-cfg" data-cfg-for="autoBanner"></div>
                                        </div>
                                        <input type="checkbox" class="tn-mutex-feature" data-key="autoBanner" ${CONFIG.activeFeature === 'autoBanner' ? 'checked' : ''}>
                                    </label>
                                    <div id="tn-banner-extra"></div>
                                    <label class="tn-opt-item" style="border-left: 3px solid #f5c2e7;">
                                        <div style="min-width:0; flex:1;">
                                            <div class="tn-feat-title" style="color:#f5c2e7;"><span class="tn-feat-name">👘 Banner Skin Ảo Hình</span></div>
                                            <div class="tn-feat-desc">Quà Ảo Hình (miễn phí + 1 quà Tiên Ngọc ≤ ${CONFIG.bannerGoldPrice || 300}) → Chiêu mộ → nhiệm vụ → Chiến Lệnh.</div>
                                            <div class="tn-feat-cfg" data-cfg-for="autoSkinBanner"></div>
                                        </div>
                                        <input type="checkbox" class="tn-mutex-feature" data-key="autoSkinBanner" ${CONFIG.activeFeature === 'autoSkinBanner' ? 'checked' : ''}>
                                    </label>
${featureEventRowsHtml()}
                                </div>
                            </div>

                        </div>
                    </div>
                </div>

                <!-- THANH NÚT CHẠY CỐ ĐỊNH Ở ĐÁY HUD (STICKY / FIXED FOOTER) -->
                <div id="tn-hud-footer">
                    <button id="tn-btn-main" class="tn-action-btn tn-btn-start">▶ BẮT ĐẦU AUTO</button>
                    <div id="tn-quick-group">
                        <button id="tn-btn-sweep" class="tn-action-btn tn-btn-sweep" title="Chạy lần lượt: Nhận Thưởng Ngày, Tâm Tiên Đài, Tiên Hữu, Thái Cổ Thu Hà, Trợ Chiến, Tiên Minh, Thông Thiên (quét 3 lần) + Tứ Linh (10 ải), Phụ Bản Ngày & Bí Cảnh, Thủ Vệ, Cửu Uyển Nhi & Cổ Thần, Cực Âm, Di Tích, Ảo Cảnh, Kiếm Hành & Điêu Long, Vực U Minh, Đấu Tiên Đài, Ma Đạo, Banner, Banner Skin; cuối cùng Nhận Cuối Ngày."><span class="tn-qb-main">⚡ QUÉT NHANH</span><span class="tn-qb-sub">1 chạm</span></button>
                        <button id="tn-btn-quick-fresh" class="tn-action-btn tn-btn-sweep" style="display:none;" title="Chạy lại từ đầu (bỏ tiến độ đã lưu)">↺<span class="tn-fr-label"> CHẠY LẠI</span></button>
                        <button id="tn-btn-hourly" class="tn-action-btn tn-btn-sweep" title="THU HOẠCH THEO GIỜ (chạy tay): Ma Đạo (Treo Máy + Ủy Phái), Núi Cấm, Cực Âm Địa, Di Tích Tiên Giới, Trợ Chiến Linh Thú, rồi nhận Thư — nhận thưởng đã xong và nạp lại việc"><span class="tn-qb-main"><span class="tn-hr-icon">⏱</span><span class="tn-hr-label"> THU HOẠCH</span></span><span class="tn-qb-sub"></span></button>
                        <button id="tn-btn-quick-cfg" class="tn-action-btn tn-btn-sweep" title="Chọn các bước của QUÉT NHANH">⚙</button>
                    </div>
                </div>
            `;
            document.body.appendChild(hud);
        // Cài đặt con của từng tính năng: nút ⚙ cạnh tên tính năng mở cửa sổ popup; mô tả tính năng hiện giá trị đang dùng.
        // Thêm cài đặt mới: khai báo trong FEATURE_SETTINGS (key = data-key của tính năng) + giá trị mặc định trong CONFIG,
        // và thêm nút `<button class="tn-gear-btn" data-gear="<key>">` cạnh tên tính năng trong ui-markup.js.
        const FEATURE_SETTINGS = {
            autoArena: {
                title: 'Đấu Tiên Đài',
                fields: [
                    { key: 'arenaBattleLimit', type: 'number', min: 1, max: 99, def: 5, label: 'Giới hạn số trận mỗi lần chạy', hint: 'Tổng lượt miễn phí + lượt dùng Đấu Tiên Lệnh.' }
                ],
                summary: (c) => `Tối đa ${c.arenaBattleLimit} trận mỗi lần chạy.`
            },
            autoTienMinh: {
                title: 'Tiên Minh',
                fields: [
                    { key: 'tienMinhDungeonLimit', type: 'number', min: 1, max: 6, def: 3, label: 'Số trận Bí Cảnh Tông Môn', hint: '2 trận đầu miễn phí; trận thứ 3 trở đi tự mua lượt (20 Tiên Ngọc/lượt). Tối đa 6.' }
                ],
                summary: (c) => `Bí Cảnh Tông Môn ${c.tienMinhDungeonLimit} trận` + (c.tienMinhDungeonLimit > 2 ? ` (mua thêm ${c.tienMinhDungeonLimit - 2} lượt, ${(c.tienMinhDungeonLimit - 2) * 20} Tiên Ngọc).` : ' (chỉ lượt miễn phí).')
            }
        };

        // Popup Quét nhanh đang mở: chữ ký các sự kiện đã hiển thị (null = không mở) và hàm làm mới khi game báo dữ liệu mới.
        let quickPopupSig = null;
        let quickPopupRefresh = null;
        const quickEventSig = () => JSON.stringify(quickStepsCatalog.filter((st) => st.event)
            .map((st) => [st.key, st.open === undefined ? null : st.open, st.detail]));

        function featureSettingNormalize(field, raw) {
            if (field.type === 'checkbox') return Boolean(raw);
            const n = Number(raw);
            return Number.isInteger(n) && n >= field.min && n <= field.max ? n : field.def;
        }

        // Dòng "Hiện tại: ..." dưới mô tả mỗi tính năng có cài đặt.
        function refreshFeatureSummaries() {
            for (const key of Object.keys(FEATURE_SETTINGS)) {
                const el = document.querySelector(`.tn-feat-cfg[data-cfg-for="${key}"]`);
                if (el) el.textContent = '⚙ ' + FEATURE_SETTINGS[key].summary(CONFIG);
            }
        }

        function initFeatureSettings() {
            const hud = document.getElementById('tn-auto-hud');
            if (!hud) return;
            const overlay = document.createElement('div');
            overlay.id = 'tn-settings-overlay';
            const card = document.createElement('div');
            card.id = 'tn-settings-card';
            overlay.appendChild(card);
            hud.appendChild(overlay);

            const close = () => { overlay.classList.remove('open'); quickPopupSig = null; };
            overlay.addEventListener('mousedown', (e) => { if (e.target === overlay) close(); });
            document.addEventListener('keydown', (e) => { if (e.key === 'Escape') close(); });

            function open(key) {
                const def = FEATURE_SETTINGS[key];
                if (!def) return;
                card.textContent = '';
                const head = document.createElement('div');
                head.className = 'tn-set-head';
                const title = document.createElement('span');
                title.textContent = '⚙ Cài đặt: ' + def.title;
                const x = document.createElement('button');
                x.type = 'button';
                x.className = 'tn-set-close';
                x.textContent = '✕';
                x.addEventListener('click', close);
                head.append(title, x);
                card.appendChild(head);

                for (const f of def.fields) {
                    const row = document.createElement('label');
                    row.className = 'tn-set-field';
                    const text = document.createElement('div');
                    const label = document.createElement('div');
                    label.className = 'tn-set-label';
                    label.textContent = f.label;
                    const hint = document.createElement('div');
                    hint.className = 'tn-set-hint';
                    hint.textContent = f.hint || '';
                    text.append(label, hint);
                    const input = document.createElement('input');
                    input.type = f.type;
                    if (f.type === 'checkbox') input.checked = Boolean(CONFIG[f.key]);
                    else { input.min = f.min; input.max = f.max; input.step = 1; input.value = String(CONFIG[f.key]); }
                    input.addEventListener('change', () => {
                        CONFIG[f.key] = featureSettingNormalize(f, f.type === 'checkbox' ? input.checked : input.value);
                        if (f.type === 'checkbox') input.checked = CONFIG[f.key]; else input.value = String(CONFIG[f.key]);
                        sendCommandToGame('UPDATE_CONFIG', { config: CONFIG });
                        refreshFeatureSummaries();
                        addLogToUI(`⚙ ${def.title}: ${def.summary(CONFIG)}`, 'info');
                    });
                    row.append(text, input);
                    card.appendChild(row);
                }
                const done = document.createElement('button');
                done.type = 'button';
                done.className = 'tn-action-btn tn-btn-start';
                done.style.cssText = 'margin:6px 0 0 0;padding:6px 0;';
                done.textContent = 'Xong';
                done.addEventListener('click', close);
                card.appendChild(done);
                overlay.classList.add('open');
            }

            // Cài đặt QUÉT NHANH: tick chọn các bước (thứ tự cố định, không đổi được). Đổi lựa chọn thì bỏ tiến độ tạm dừng cũ.
            function openQuickSteps() {
                const prevScroll = (card.querySelector('.tn-set-list') || {}).scrollTop || 0;
                quickPopupSig = quickEventSig();
                card.textContent = '';
                const head = document.createElement('div');
                head.className = 'tn-set-head';
                const title = document.createElement('span');
                title.textContent = '⚙ Cài đặt: Quét Nhanh';
                const x = document.createElement('button');
                x.type = 'button';
                x.className = 'tn-set-close';
                x.textContent = '✕';
                x.addEventListener('click', close);
                head.append(title, x);
                card.appendChild(head);

                const note = document.createElement('div');
                note.className = 'tn-set-hint';
                note.style.margin = '0 0 6px 0';
                note.textContent = quickStepsCatalog.length
                    ? 'Tick các bước muốn chạy (thứ tự cố định). Đổi lựa chọn sẽ bỏ tiến độ tạm dừng trước đó.'
                    : 'Chưa nhận được danh sách bước từ game; đợi vài giây rồi mở lại.';
                card.appendChild(note);
                const locked = Boolean(CONFIG.running);
                if (locked) {
                    const warn = document.createElement('div');
                    warn.className = 'tn-set-hint';
                    warn.style.cssText = 'margin:0 0 6px 0;color:#f9e2af;';
                    warn.textContent = 'Auto đang chạy: tạm dừng trước khi đổi bước.';
                    card.appendChild(warn);
                }

                const boxes = [];
                // Bỏ chọn hết: không lưu (phải còn ít nhất một bước); lựa chọn đã lưu giữ nguyên tới khi tick lại.
                const noneWarn = document.createElement('div');
                noneWarn.className = 'tn-set-hint';
                noneWarn.style.cssText = 'margin:0 0 6px 0;color:#f9e2af;display:none;';
                noneWarn.textContent = 'Chưa chọn bước nào: tick ít nhất 1 bước (lựa chọn đã lưu trước đó vẫn được giữ).';
                card.appendChild(noneWarn);
                const list = document.createElement('div');
                list.className = 'tn-set-list';
                card.appendChild(list);
                const apply = (changedBox) => {
                    const keys = quickStepsCatalog.filter((st, i) => boxes[i].checked).map((st) => st.key);
                    noneWarn.style.display = keys.length ? 'none' : '';
                    if (!keys.length) return;                                  // phải còn ít nhất một bước mới lưu
                    CONFIG.quickSteps = keys.length === quickStepsCatalog.length ? null : keys;
                    try {
                        if (CONFIG.quickSteps) localStorage.setItem('TN_QUICK_STEPS_V1', JSON.stringify(CONFIG.quickSteps));
                        else localStorage.removeItem('TN_QUICK_STEPS_V1');
                    } catch (e) { }
                    sendCommandToGame('UPDATE_CONFIG', { config: CONFIG });
                    if (quickSavedInfo) {
                        updateQuickButtons(null, null);
                        addLogToUI('⚙ Quét nhanh: đã đổi các bước nên bỏ tiến độ tạm dừng cũ.', 'info');
                    }
                    addLogToUI('⚙ Quét nhanh: chạy ' + keys.length + '/' + quickStepsCatalog.length + ' bước.', 'info');
                };
                const selected = new Set(Array.isArray(CONFIG.quickSteps) ? CONFIG.quickSteps : quickStepsCatalog.map((st) => st.key));
                // Hai phần: các bước thường (đánh số) và phần "Sự kiện" riêng (tự bỏ qua khi game báo không có sự kiện đang mở).
                let evBox = null;     // phần Sự kiện cố định bên dưới, không cuộn theo danh sách bước thường
                let eventsLoading = false;
                let eventsShown = 0;      // số sự kiện đang mở được hiện trong phần Sự kiện (sự kiện đã đóng bị ẩn)
                let syncAllLabel = () => { };     // đổi chữ nút Chọn tất cả / Bỏ chọn tất cả theo trạng thái các ô
                let stepNo = 0;
                // Hiện đúng thứ tự chạy thật: bước thường, rồi khối Sự kiện, rồi các bước nằm SAU sự kiện cuối trong dãy (Thiên Thuẫn).
                let lastEventIdx = -1;
                quickStepsCatalog.forEach((st, i) => { if (st.event) lastEventIdx = i; });
                const groupOf = (i) => (quickStepsCatalog[i].event ? 1 : (i > lastEventIdx && lastEventIdx >= 0 ? 2 : 0));
                const order = quickStepsCatalog.map((st, i) => i).sort((x, y) => groupOf(x) - groupOf(y) || x - y);
                let tailBox = null;     // các bước sau khối Sự kiện, cố định bên dưới như khối Sự kiện
                order.forEach((i) => {
                    const st = quickStepsCatalog[i];
                    // Sự kiện chưa có dữ liệu từ game: chưa hiện lựa chọn (giữ nguyên trạng thái đã chọn), hiện khi game đã báo.
                    const unknown = st.event && (st.open === null || st.open === undefined);
                    if (st.event && !evBox) {
                        evBox = document.createElement('div');
                        evBox.className = 'tn-set-events';
                        card.appendChild(evBox);
                        const head2 = document.createElement('div');
                        head2.className = 'tn-set-hint';
                        head2.style.cssText = 'margin:8px 0 4px 0;padding-top:6px;border-top:1px solid rgba(203,166,247,0.35);color:#cba6f7;font-weight:bold;';
                        head2.textContent = '🎴 Sự kiện';
                        evBox.append(head2);
                    }
                    if (unknown) { boxes[i] = { checked: selected.has(st.key) }; eventsLoading = true; return; }
                    // Sự kiện đã đóng: ẩn hẳn khỏi bảng (giữ nguyên lựa chọn đã lưu; Quét nhanh tự bỏ qua bước này).
                    if (st.event && st.open !== true) { boxes[i] = { checked: selected.has(st.key) }; return; }
                    if (st.event) eventsShown++;
                    const row = document.createElement('label');
                    row.className = 'tn-set-field';
                    const text = document.createElement('div');
                    const label = document.createElement('div');
                    label.className = 'tn-set-label';
                    // Số thứ tự liên tục theo thứ tự chạy thật; sự kiện chỉ được đánh số khi đang mở (sự kiện đóng/chưa rõ không có dòng nên không chiếm số).
                    label.textContent = (++stepNo) + '. ' + st.label;
                    text.appendChild(label);
                    if (st.event) {
                        // Trạng thái nằm cạnh tên bước (cùng một dòng).
                        const state = document.createElement('span');
                        state.style.cssText = 'margin-left:8px;font-weight:normal;font-size:9.5px;color:' + (st.open === true ? '#a6e3a1' : '#fab387') + ';';
                        state.textContent = st.open === true ? '● Đang mở' : '○ Hiện không có (sẽ bỏ qua)';
                        label.appendChild(state);
                        // Mỗi tên một dòng.
                        if (st.open === true && st.detail) {
                            (Array.isArray(st.detail) ? st.detail : [st.detail]).forEach((n) => {
                                const name = document.createElement('div');
                                name.className = 'tn-set-hint';
                                name.style.cssText = 'color:#f5c2e7;font-weight:bold;';
                                name.textContent = n;
                                text.appendChild(name);
                            });
                        }
                    }
                    const input = document.createElement('input');
                    input.type = 'checkbox';
                    input.checked = selected.has(st.key);
                    input.disabled = locked;
                    input.addEventListener('change', () => { apply(input); syncAllLabel(); });
                    boxes[i] = input;
                    row.append(text, input);
                    if (!st.event && groupOf(i) === 2) {
                        if (!tailBox) { tailBox = document.createElement('div'); tailBox.className = 'tn-set-events'; tailBox.style.cssText = 'margin-top:8px;padding-top:6px;border-top:1px solid rgba(203,166,247,0.35);'; card.appendChild(tailBox); }
                        tailBox.appendChild(row);
                        return;
                    }
                    (st.event ? evBox : list).appendChild(row);
                });
                if (evBox && !eventsShown && !eventsLoading) {
                    const none = document.createElement('div');
                    none.className = 'tn-set-hint';
                    none.style.cssText = 'padding:6px 4px;';
                    none.textContent = 'Hiện không có sự kiện nào đang mở.';
                    evBox.appendChild(none);
                }
                // Còn sự kiện chưa có dữ liệu: hiện hiệu ứng tải bên dưới phần Sự kiện (tự thay bằng lựa chọn khi game báo).
                if (evBox && eventsLoading) {
                    const loading = document.createElement('div');
                    loading.className = 'tn-set-hint';
                    loading.style.cssText = 'padding:6px 4px;';
                    const spin = document.createElement('span');
                    spin.className = 'tn-spin';
                    loading.append(spin, 'Đang tải thông tin sự kiện...');
                    evBox.appendChild(loading);
                }
                // "Chọn tất cả" và "Xong" cùng một hàng.
                const btnRow = document.createElement('div');
                btnRow.className = 'tn-set-btnrow';
                if (quickStepsCatalog.length && !locked) {
                    const all = document.createElement('button');
                    all.type = 'button';
                    all.className = 'tn-action-btn tn-btn-start';
                    // Nút bật/tắt: tất cả đang chọn -> "Bỏ chọn tất cả", ngược lại -> "Chọn tất cả".
                    syncAllLabel = () => { all.textContent = boxes.every((b) => b.checked) ? 'Bỏ chọn tất cả' : 'Chọn tất cả'; };
                    syncAllLabel();
                    all.addEventListener('click', () => {
                        const next = !boxes.every((b) => b.checked);
                        boxes.forEach((b) => { b.checked = next; });
                        apply(boxes[0]);
                        syncAllLabel();
                    });
                    btnRow.appendChild(all);
                }
                const done = document.createElement('button');
                done.type = 'button';
                done.className = 'tn-action-btn tn-btn-start';
                done.textContent = 'Xong';
                done.addEventListener('click', close);
                btnRow.appendChild(done);
                card.appendChild(btnRow);
                const newList = card.querySelector('.tn-set-list');
                if (newList) newList.scrollTop = prevScroll;
                overlay.classList.add('open');
            }
            // Game báo trạng thái sự kiện mới trong lúc popup đang mở: dựng lại để hiện các sự kiện vừa có dữ liệu.
            // Tự theo dõi (không phụ thuộc nơi nhận tin nhắn): popup đang mở mà dữ liệu sự kiện đổi thì dựng lại.
            quickPopupRefresh = () => {
                if (quickPopupSig !== null && overlay.classList.contains('open') && quickEventSig() !== quickPopupSig) openQuickSteps();
            };
            setInterval(() => { try { quickPopupRefresh(); } catch (e) { } }, 700);
            const quickCfgBtn = document.getElementById('tn-btn-quick-cfg');
            if (quickCfgBtn) quickCfgBtn.addEventListener('click', (e) => { e.preventDefault(); e.stopPropagation(); openQuickSteps(); });

            document.querySelectorAll('.tn-gear-btn').forEach((btn) => {
                btn.addEventListener('click', (e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    open(btn.dataset.gear);
                });
            });
            refreshFeatureSummaries();
        }
            // PC: bố cục riêng của thẻ. Gọi từ ui-events.js (setupHudLayout) sau khi dựng ba tab: kéo bằng header, đổi cỡ bằng hai góc dưới
            // (rộng 600–700px, cao 600–1000px), nút — thu nhỏ còn header + hàng nút chạy. Chỉ hiển thị, không đụng CONFIG/chạy.
            function makeSmoothDraggable(el, handle) {
                let posX = 0, posY = 0, startX = 0, startY = 0;
                let isDragging = false;

                handle.addEventListener('pointerdown', (e) => {
                    isDragging = true;
                    startX = e.clientX;
                    startY = e.clientY;
                    const rect = el.getBoundingClientRect();
                    posX = rect.left;
                    posY = rect.top;
                    handle.setPointerCapture(e.pointerId);
                    el.style.transition = 'none';
                });

                handle.addEventListener('pointermove', (e) => {
                    if (!isDragging) return;
                    const dx = e.clientX - startX;
                    const dy = e.clientY - startY;
                    let newX = posX + dx;
                    let newY = posY + dy;

                    // CHO PHÉP DI CHUYỂN TỰ DO HOÀN TOÀN KHẮP MÀN HÌNH ĐIỆN THOẠI
                    // Giữ lại tối thiểu 35px mép màn hình để người dùng không bị mất nút kéo
                    const minVisible = 35;
                    const elWidth = el.offsetWidth || 255;
                    const minX = - (elWidth - minVisible);
                    const maxX = window.innerWidth - minVisible;
                    const minY = 0;
                    const maxY = window.innerHeight - minVisible;

                    newX = Math.max(minX, Math.min(newX, maxX));
                    newY = Math.max(minY, Math.min(newY, maxY));

                    el.style.left = `${newX}px`;
                    el.style.top = `${newY}px`;
                });

                const stopDrag = (e) => {
                    if (!isDragging) return;
                    isDragging = false;
                    try { handle.releasePointerCapture(e.pointerId); } catch (err) { }
                };

                handle.addEventListener('pointerup', stopDrag);
                handle.addEventListener('pointercancel', stopDrag);
            }

            function makeHudResizable(hud, handle, direction) {
                if (!handle) return;

                let startX = 0;
                let startY = 0;
                let startWidth = 0;
                let startHeight = 0;
                let startLeft = 0;
                let startRight = 0;
                let startTop = 0;

                handle.addEventListener('pointerdown', (event) => {
                    if (event.button !== 0) return;
                    event.preventDefault();
                    event.stopPropagation();

                    const rect = hud.getBoundingClientRect();
                    startX = event.clientX;
                    startY = event.clientY;
                    startWidth = rect.width;
                    startHeight = rect.height;
                    startLeft = rect.left;
                    startRight = rect.right;
                    startTop = rect.top;

                    handle.setPointerCapture(event.pointerId);
                    hud.style.transition = 'none';
                });

                handle.addEventListener('pointermove', (event) => {
                    if (!handle.hasPointerCapture(event.pointerId)) return;

                    const maxWidth = Math.max(360, Math.min(800, window.innerWidth - 16));   // PC: rộng tối đa 800px
                    const minWidth = Math.min(650, maxWidth);   // PC: rộng tối thiểu 650px (= cỡ mặc định)
                    const minHeight = 600;   // PC: cao tối thiểu 600px
                    const MAX_H = 1000;      // PC: cao tối đa 1000px
                    const maxHeight = Math.max(minHeight, Math.min(MAX_H, window.innerHeight - startTop - 8));
                    const nextHeight = Math.max(minHeight, Math.min(startHeight + event.clientY - startY, maxHeight));
                    hud.style.height = `${nextHeight}px`;

                    if (direction === 'left') {
                        const minLeft = Math.max(8, startRight - maxWidth);
                        const maxLeft = startRight - minWidth;
                        const nextLeft = Math.max(minLeft, Math.min(startLeft + event.clientX - startX, maxLeft));
                        hud.style.left = `${nextLeft}px`;
                        hud.style.width = `${startRight - nextLeft}px`;
                    } else {
                        const availableWidth = Math.max(minWidth, Math.min(maxWidth, window.innerWidth - startLeft - 8));
                        const nextWidth = Math.max(minWidth, Math.min(startWidth + event.clientX - startX, availableWidth));
                        hud.style.width = `${nextWidth}px`;
                    }
                });

                const stopResize = (event) => {
                    if (!handle.hasPointerCapture(event.pointerId)) return;
                    handle.releasePointerCapture(event.pointerId);
                    hud.style.transition = '';
                };

                handle.addEventListener('pointerup', stopResize);
                handle.addEventListener('pointercancel', stopResize);
            }

            function setupPlatformLayout(ctx) {
                const { hud, header, lsGet, lsSet } = ctx;
                makeSmoothDraggable(hud, header);

                const minBtn = document.createElement('button');
                minBtn.id = 'tn-hud-min'; minBtn.type = 'button';
                header.appendChild(minBtn);
                const setMini = (mini) => {
                    hud.classList.toggle('tn-hud-mini', mini);
                    if (!mini) { hud.style.width = ''; hud.style.height = ''; }   // mở lại = về cỡ mặc định (650px), bỏ cỡ đã kéo
                    minBtn.textContent = mini ? '▢' : '—'; minBtn.title = mini ? 'Mở rộng bảng' : 'Thu nhỏ (chỉ còn các nút chạy)';
                    lsSet('TN_HUD_MINI', mini ? '1' : '0');
                };
                setMini(lsGet('TN_HUD_MINI') === '1');
                minBtn.addEventListener('pointerdown', (ev) => ev.stopPropagation());   // không kích hoạt kéo bảng ở header
                minBtn.addEventListener('click', () => setMini(!hud.classList.contains('tn-hud-mini')));

                // Nút "Xuất file log" (chỉ PC): tải log đã lưu thành file .txt, nằm giữa Sao chép và Xóa (tab Cài đặt).
                const logBtns = document.getElementById('tn-log-tools-btns'), logClear = document.getElementById('tn-btn-log-clear');
                if (logBtns && logClear) {
                    const exportBtn = document.createElement('button');
                    exportBtn.type = 'button'; exportBtn.id = 'tn-btn-log-export'; exportBtn.className = 'tn-log-btn';
                    exportBtn.textContent = '💾 Xuất file log';
                    logBtns.insertBefore(exportBtn, logClear);
                    exportBtn.addEventListener('click', () => {
                        if (logBufTimer) { clearTimeout(logBufTimer); logBufSave(); }
                        if (!logBufLoad().length) { addLogToUI('💾 Chưa có log nào được lưu: bật "Log chi tiết" rồi chạy lại.', 'warn'); return; }
                        try {
                            const d = new Date(), p = (n) => String(n).padStart(2, '0');
                            const name = 'tien-nghich-log-' + d.getFullYear() + p(d.getMonth() + 1) + p(d.getDate()) + '-' + p(d.getHours()) + p(d.getMinutes()) + p(d.getSeconds()) + '.txt';
                            const url = URL.createObjectURL(new Blob([logBufText()], { type: 'text/plain;charset=utf-8' }));
                            const a = document.createElement('a');
                            a.href = url; a.download = name; document.body.appendChild(a); a.click(); a.remove();
                            setTimeout(() => URL.revokeObjectURL(url), 2000);
                            addLogToUI('💾 Đã xuất ' + logBufLoad().length + ' dòng log ra file ' + name + '.', 'run');
                        } catch (e) { addLogToUI('💾 Không xuất được file log: ' + (e && e.message), 'err'); }
                    });
                }

                ['left', 'right'].forEach((dir) => {
                    const h = document.createElement('div');
                    h.className = 'tn-resize-handle tn-resize-' + dir;
                    h.title = 'Kéo để đổi kích thước';
                    hud.appendChild(h);
                    makeHudResizable(hud, h, dir);
                });
            }

            // NẠP NGAY DỮ LIỆU NHÂN VẬT TỪ PHIÊN TRƯỚC (NẾU CÓ) TRÁNH HIỆN --
            try {
                const initCachedName = localStorage.getItem('TN_LAST_ROLE_NAME') || '';
                const nameEl = document.getElementById('tn-role-name');
                if (initCachedName && nameEl) nameEl.textContent = initCachedName;
            } catch(e) {}

            hud.classList.add('tn-wait-game');   // mặc định: chưa vào game (updateRoleDisplay gỡ khi có Lv/LC)
            // Đang tự vào lại game sau khi bị đá/mất kết nối (trạng thái ở sessionStorage, xem auto-reconnect.js): đổi dòng nhắc thành "Game đang vào lại...".
            const waitEl = document.getElementById('tn-wait-game');
            const WAIT_TEXT_DEFAULT = waitEl ? waitEl.textContent : '';
            const syncWaitText = () => {
                if (!waitEl) return;
                let st = null;
                try { st = typeof reconnectReadState === 'function' ? reconnectReadState() : null; } catch (e) { }
                const reconnecting = Boolean(st && Date.now() - st.startedAt < 180000);
                hud.classList.toggle('tn-reconnecting', reconnecting);
                const text = reconnecting ? '🔄 Game đang vào lại... (tự động kết nối)' : WAIT_TEXT_DEFAULT;
                if (waitEl.textContent !== text) waitEl.textContent = text;
            };
            syncWaitText();
            const waitTextTimer = setInterval(() => {
                if (!hud.classList.contains('tn-wait-game')) { clearInterval(waitTextTimer); hud.classList.remove('tn-reconnecting'); return; }
                syncWaitText();
            }, 1000);
            const header = document.getElementById('tn-hud-header');

            // Bố cục thẻ ba tab (Nhật ký | Tính năng | Cài đặt) dùng chung. Phần riêng từng nền tảng (PC: kéo/đổi cỡ/thu nhỏ; iPhone: bong bóng ⚡, vá Safari)
            // nằm trong platform/pc hoặc platform/phone (build chọn một) và được gọi ở cuối: setupPlatformLayout(ctx).
            (function setupHudLayout() {
                const lsGet = (k) => { try { return localStorage.getItem(k); } catch (err) { return null; } };
                const lsSet = (k, v) => { try { localStorage.setItem(k, v); } catch (err) { } };
                // Thẻ tài khoản: dời lên ngay dưới đầu bảng (một dòng, thấy ở cả hai tab). Chỉ điện thoại; PC giữ thẻ ở cột trái.
                // updateRoleDisplay tìm theo id nên dời nút DOM không ảnh hưởng.
                try {
                    const roleCard = hud.querySelector('.tn-role-card'), hudBody = document.getElementById('tn-hud-body');
                    if (roleCard && hudBody && hudBody.parentNode) hudBody.parentNode.insertBefore(roleCard, hudBody);
                } catch (err) { }
                // Ba tab ở đầu thẻ: Nhật ký / Tính năng / Cài đặt (một tab một lúc); bấm chạy thì quay về Nhật ký. Chỉ là hiển thị.
                const tabBtns = Array.from(hud.querySelectorAll('#tn-mtabs button[data-mview]'));
                const setView = (v) => {
                    if (v !== 'feat' && v !== 'set') v = 'chat';
                    hud.classList.toggle('tn-mview-chat', v === 'chat');
                    hud.classList.toggle('tn-mview-feat', v === 'feat');
                    hud.classList.toggle('tn-mview-set', v === 'set');
                    tabBtns.forEach((b) => b.classList.toggle('active', b.getAttribute('data-mview') === v));
                    if (v !== 'feat') { const lb = document.getElementById('tn-log-content'); if (lb) lb.scrollTop = lb.scrollHeight; }
                    lsSet('TN_HUD_MVIEW', v);
                };
                setView('feat');   // luôn mở ở tab Tính năng khi tải trang
                tabBtns.forEach((b) => {
                    b.addEventListener('pointerdown', (ev) => ev.stopPropagation());   // không kích hoạt kéo bảng ở header
                    b.addEventListener('click', () => setView(b.getAttribute('data-mview')));
                });
                ['tn-btn-main', 'tn-btn-sweep', 'tn-btn-quick-fresh', 'tn-btn-hourly'].forEach((id) => {
                    const el = document.getElementById(id);
                    if (el) el.addEventListener('click', () => setView('chat'));
                });

                setupPlatformLayout({ hud, header, setView, lsGet, lsSet });
            })();

            // Cấu hình các mục thu gọn / mở rộng (Accordion Collapsible Sections)
            function setupAccordion(headerId, contentId, arrowId, storageKey) {
                const hEl = document.getElementById(headerId);
                const cEl = document.getElementById(contentId);
                const aEl = document.getElementById(arrowId);
                if (!hEl || !cEl) return;

                let isOpen = localStorage.getItem(storageKey) !== '0'; // mặc định mở

                function updateView() {
                    if (isOpen) {
                        cEl.classList.remove('tn-collapsed');
                        if (aEl) aEl.textContent = '▼';
                    } else {
                        cEl.classList.add('tn-collapsed');
                        if (aEl) aEl.textContent = '▶';
                    }
                }
                updateView();

                hEl.addEventListener('click', (e) => {
                    e.stopPropagation();
                    isOpen = !isOpen;
                    try { localStorage.setItem(storageKey, isOpen ? '1' : '0'); } catch(err) {}
                    updateView();
                });
            }

            setupAccordion('tn-sec-header-acc', 'tn-sec-content-acc', 'tn-arrow-acc', 'TN_SEC_ACC_OPEN');
            setupAccordion('tn-sec-header-cfg', 'tn-sec-content-cfg', 'tn-arrow-cfg', 'TN_SEC_CFG_OPEN');
            setupAccordion('tn-sec-header-ctrl', 'tn-sec-content-ctrl', 'tn-arrow-ctrl', 'TN_SEC_CTRL_OPEN');

            // CẤU HÌNH TAB BAR & CHUYỂN ĐỔI 2 PHẦN
            const tabButtons = document.querySelectorAll('.tn-tab-btn');
            const tabPanels = {
                tinhNang: document.getElementById('tn-tab-panel-tinh-nang'),
                banner: document.getElementById('tn-tab-panel-banner')
            };

            function switchTab(tabKey) {
                tabButtons.forEach(btn => {
                    if (btn.dataset.tab === tabKey) btn.classList.add('active');
                    else btn.classList.remove('active');
                });
                for (const k in tabPanels) {
                    if (tabPanels[k]) {
                        if (k === tabKey) tabPanels[k].classList.add('active');
                        else tabPanels[k].classList.remove('active');
                    }
                }
                CONFIG.activeTab = tabKey;
            }

            tabButtons.forEach(btn => {
                btn.addEventListener('click', () => {
                    switchTab(btn.dataset.tab);
                });
            });

            if (CONFIG.activeTab && tabPanels[CONFIG.activeTab]) {
                switchTab(CONFIG.activeTab);
            }

            // CẤU HÌNH ĐỘC QUYỀN 1 CHỨC NĂNG DUY NHẤT (MUTEX) ĐỂ TRÁNH XUNG ĐỘT
            const mainFeatures = [
                'autoTongTian', 'autoClimbDailyDungeons', 'autoClimbYMAbyss', 'autoClimbCamp',
                'autoSweepDungeons', 'autoExtremeYin', 'autoArena',
                'autoMaDao', 'autoXianYuan', 'autoBanner', 'autoJadeMine'
            ];

            const mutexCheckboxes = document.querySelectorAll('.tn-mutex-feature');

            // Đồng bộ trạng thái ban đầu của các checkbox
            mutexCheckboxes.forEach(cb => {
                const key = cb.dataset.key;
                cb.checked = (CONFIG.activeFeature === key) || (Boolean(CONFIG[key]) && !CONFIG.activeFeature);
                if (cb.checked && !CONFIG.activeFeature) {
                    CONFIG.activeFeature = key;
                }
            });

            mutexCheckboxes.forEach(cb => {
                cb.addEventListener('change', (e) => {
                    const key = cb.dataset.key;
                    if (e.target.checked) {
                        // Tắt tất cả các chức năng chính khác
                        mutexCheckboxes.forEach(other => {
                            if (other !== cb) other.checked = false;
                        });
                        mainFeatures.forEach(k => {
                            CONFIG[k] = (k === key);
                        });
                        CONFIG.activeFeature = key;
                        sendCommandToGame('UPDATE_CONFIG', { config: CONFIG });
                        // Chỉ lấy tên tính năng (div tiêu đề), không lấy cả phần mô tả.
                        const titleEl = cb.closest('label').querySelector('.tn-feat-name');
                        const title = titleEl ? titleEl.innerText : key;
                        addLogToUI("🎯 Đã chọn: " + title, "run");
                    } else {
                        CONFIG[key] = false;
                        if (CONFIG.activeFeature === key) CONFIG.activeFeature = null;
                        sendCommandToGame('UPDATE_CONFIG', { config: CONFIG });
                        const offEl = cb.closest('label').querySelector('.tn-feat-name');
                        addLogToUI("⏸️ Đã bỏ chọn: " + (offEl ? offEl.innerText : key), "warn");
                    }
                });
            });

            // TÙY CHỌN BỔ TRỢ TOÀN CỤC (CHẠY KÈM TẤT CẢ)
            const skipEl = document.getElementById('tn-opt-skip');
            if (skipEl) {
                skipEl.checked = Boolean(CONFIG.autoSkipFight);
                skipEl.addEventListener('change', (e) => {
                    CONFIG.autoSkipFight = e.target.checked;
                    sendCommandToGame('UPDATE_CONFIG', { config: CONFIG });
                    addLogToUI(CONFIG.autoSkipFight ? "⏩ Bật bỏ qua trận đấu thần tốc!" : "⏸️ Tắt bỏ qua trận đấu", "info");
                });
            }

            // Log chi tiết: mặc định TẮT mỗi lần tải trang (không nhớ lựa chọn); log đã lưu (nếu có) vẫn còn ở localStorage.
            const logToolsInfo = document.getElementById('tn-log-tools-info');
            const refreshLogToolsInfo = () => { if (logToolsInfo) logToolsInfo.textContent = logBufInfoText(); };
            refreshLogToolsInfo();
            const copyLogBtn = document.getElementById('tn-btn-log-copy');
            if (copyLogBtn) copyLogBtn.addEventListener('click', async () => {
                if (logBufTimer) { clearTimeout(logBufTimer); logBufSave(); }
                const text = logBufText();
                if (!logBufLoad().length) { addLogToUI('📋 Chưa có log nào được lưu: bật "Log chi tiết" rồi chạy lại.', 'warn'); return; }
                let ok = false;
                try { await navigator.clipboard.writeText(text); ok = true; } catch (e) { }
                if (!ok) {
                    try {
                        const ta = document.createElement('textarea');
                        ta.value = text; ta.style.cssText = 'position:fixed;left:0;top:0;opacity:0;';
                        document.body.appendChild(ta); ta.focus(); ta.select();
                        ok = document.execCommand('copy'); ta.remove();
                    } catch (e) { }
                }
                // Nút đổi trạng thái ngắn: ✅ Đã sao chép (hoặc ⚠ Không chép được), rồi trở lại như cũ.
                copyLogBtn.textContent = ok ? '✅ Đã sao chép' : '⚠ Không chép được';
                copyLogBtn.classList.toggle('tn-log-btn-ok', ok);
                clearTimeout(copyLogBtn._tnResetTimer);
                copyLogBtn._tnResetTimer = setTimeout(() => { copyLogBtn.textContent = '📋 Sao chép log'; copyLogBtn.classList.remove('tn-log-btn-ok'); }, 1800);
                addLogToUI(ok ? '📋 Đã sao chép ' + logBufLoad().length + ' dòng log vào bộ nhớ tạm.' : '📋 Không sao chép được (trình duyệt chặn); thử lại sau khi chạm vào màn hình.', ok ? 'run' : 'warn');
            });
            const clearLogBtn = document.getElementById('tn-btn-log-clear');
            if (clearLogBtn) clearLogBtn.addEventListener('click', () => { logBufClear(); refreshLogToolsInfo(); addLogToUI('🗑 Đã xóa log đã lưu.', 'run'); });
            setInterval(() => { if (CONFIG.verboseLog) refreshLogToolsInfo(); }, 5000);

            const verboseEl = document.getElementById('tn-opt-verbose');
            if (verboseEl) {
                verboseEl.checked = Boolean(CONFIG.verboseLog);
                verboseEl.addEventListener('change', (e) => {
                    CONFIG.verboseLog = e.target.checked;
                    refreshLogToolsInfo();
                    sendCommandToGame('UPDATE_CONFIG', { config: CONFIG });
                    addLogToUI(CONFIG.verboseLog ? "📜 Đã bật log chi tiết (gỡ lỗi)." : "📜 Đã tắt log chi tiết; chỉ hiện thông tin quan trọng.", "run");
                });
            }

            // Nâng cao đồ họa (chỉ điện thoại, hàng này ẩn trên PC): luôn TẮT mỗi lần tải trang (không nhớ lựa chọn cũ); khi người dùng bật thì gửi sang khung game.
            const gfxEl = document.getElementById('tn-opt-gfx');
            if (gfxEl) {
                CONFIG.gfxBoost = false;
                gfxEl.checked = Boolean(CONFIG.gfxBoost);
                gfxEl.addEventListener('change', (e) => {
                    CONFIG.gfxBoost = e.target.checked;
                    sendCommandToGame('UPDATE_CONFIG', { config: CONFIG });
                    addLogToUI(CONFIG.gfxBoost ? "✨ Bật nâng cao đồ họa (x3, 60 khung/giây)." : "✨ Tắt nâng cao đồ họa (về mặc định của game).", "run");
                });
            }

            // Bản quyền (build có bản quyền: iPhone, PC --licensed; bản PC dev ẩn hàng này): key lưu ở localStorage của HUD, gửi sang khung game để kích hoạt.
            const licKeyEl = document.getElementById('tn-lic-key');
            if (licKeyEl && TN_LICENSED) {
                { const k0 = licStoreGet('TN_LICENSE_KEY'); licKeyEl.value = licMaskKey(k0); licKeyEl.disabled = !!k0; }
                const licSaveEl = document.getElementById('tn-lic-save');
                const licRecheckEl = document.getElementById('tn-lic-recheck');
                if (licSaveEl) licSaveEl.addEventListener('click', () => {
                    if (licSaveEl.getAttribute('data-mode') === 'change') {   // mở khóa để nhập key khác
                        licKeyEl.disabled = false; licKeyEl.value = ''; licKeyEl.setAttribute('data-unlocking', '1');
                        licSaveEl.textContent = 'Kích hoạt'; licSaveEl.setAttribute('data-mode', 'save'); licKeyEl.focus(); return;
                    }
                    licKeyEl.removeAttribute('data-unlocking');
                    const key = licNormalizeKey(licKeyEl.value);
                    if (!key) { licShowStatus({ state: 'denied', message: 'Key không đúng định dạng (TN-XXXXX-XXXXX-XXXXX-XXXXX).' }); return; }
                    licKeyEl.value = licMaskKey(key); licKeyEl.disabled = true;
                    licStoreSet('TN_LICENSE_KEY', key);
                    licSendConfig(true);
                });
                if (licRecheckEl) licRecheckEl.addEventListener('click', () => {
                    if (!licStoreGet('TN_LICENSE_KEY')) { licShowStatus({ state: 'nokey', message: 'Chưa nhập key bản quyền.' }); return; }
                    licSendConfig(true);
                });
                // Khung game có thể tải sau HUD: gửi cấu hình vài lần (khung game cũng tự xin qua LICENSE_NEED_CONFIG).
                [1500, 4000, 9000].forEach((ms) => setTimeout(() => { if (licStoreGet('TN_LICENSE_KEY')) licSendConfig(false); }, ms));
            }

            const reconnectEl = document.getElementById('tn-opt-reconnect');
            if (reconnectEl) {
                reconnectEl.checked = Boolean(CONFIG.autoReconnect);
                reconnectEl.addEventListener('change', (e) => {
                    CONFIG.autoReconnect = e.target.checked;
                    sendCommandToGame('UPDATE_CONFIG', { config: CONFIG });
                    addLogToUI(
                        CONFIG.autoReconnect
                            ? "🟢 Đã bật tự vào lại game khi bị ngắt kết nối."
                            : "⏸️ Đã tắt tự vào lại game khi bị ngắt kết nối.",
                        "info"
                    );
                });
            }

            initFeatureSettings();

            const btnMain = document.getElementById('tn-btn-main');
            if (btnMain) {
                btnMain.addEventListener('click', () => {
                    if (!CONFIG.running && !hasRunnableSelection()) {
                        addLogToUI("⚠️ Hãy chọn 1 tính năng (mỗi lần chỉ chạy một tính năng) trước khi bắt đầu.", "warn");
                        return;
                    }
                    CONFIG.running = !CONFIG.running;
                    updateBadge(CONFIG.running);
                    sendCommandToGame('TOGGLE_AUTO', { running: CONFIG.running, config: CONFIG });
                    addLogToUI(CONFIG.running ? "🚀 Đã bắt đầu Auto." : "⏸ Đã dừng Auto.", CONFIG.running ? "run" : "warn");
                });
            }

            const btnSweep = document.getElementById('tn-btn-sweep');
            btnSweep.dataset.baseTitle = btnSweep.title;
            function stopAuto() {
                CONFIG.running = false;
                updateBadge(false);
                sendCommandToGame('TOGGLE_AUTO', { running: false, config: CONFIG });
                addLogToUI("⏸ Đã dừng Auto.", "warn");
            }
            // Mỗi nút Quét nhanh / Thu hoạch vừa bắt đầu vừa dừng chính dãy của nó (bấm lúc đang chạy = dừng).
            function startQuick(mode) {
                if (CONFIG.running) {
                    if (quickActiveInfo && (mode === 'hourly') === Boolean(quickActiveInfo.hourly)) { stopAuto(); return; }
                    addLogToUI("⚠️ Auto đang chạy; hãy dừng nó trước khi bắt đầu " + (mode === 'hourly' ? 'THU HOẠCH' : 'QUÉT NHANH') + ".", "warn");
                    return;
                }
                quickPendingUntil = Date.now() + 4000;
                setTimeout(syncMainBtnVisibility, 4100);
                CONFIG.running = true;
                updateBadge(true);
                sendCommandToGame('TOGGLE_AUTO', { running: true, quick: true, quickMode: mode, config: CONFIG });
            }
            btnSweep.addEventListener('click', () => startQuick(quickSavedInfo ? 'resume' : 'fresh'));
            const btnQuickFresh = document.getElementById('tn-btn-quick-fresh');
            // ↺ chỉ đặt lại: xóa tiến độ đã lưu để nút về QUÉT NHANH; bấm QUÉT NHANH sau đó mới chạy từ đầu.
            if (btnQuickFresh) btnQuickFresh.addEventListener('click', () => {
                if (CONFIG.running) return;
                sendCommandToGame('QUICK_RUN_RESET');
                updateQuickButtons(null, null);
                addLogToUI("↺ Đã xóa tiến độ Quét nhanh đã lưu (chưa chạy gì).", "warn");
            });
            const btnHourly = document.getElementById('tn-btn-hourly');
            if (btnHourly) btnHourly.addEventListener('click', () => startQuick('hourly'));

            updateBadge(CONFIG.running);
            addLogToUI(`✨ Auto Tiên Nghịch Mobile v${CURRENT_AUTO_VERSION} (Bảng tính năng 2 tab, chạy cục bộ) đã sẵn sàng!`, "action");
            // Định kỳ yêu cầu Game gửi thông tin nhân vật lên HUD
            // Hỏi thông tin nhân vật/Quét nhanh: 1.5s khi bảng mở, thưa hơn (6s) khi bảng đóng trên điện thoại để đỡ việc cho luồng game
            // (mỗi lần game dựng báo cáo Quét nhanh); mở bảng sẽ hỏi ngay một lần.
            let roleTick = 0;
            setInterval(() => {
                roleTick++;
                if (hud.classList.contains('tn-minimized') && roleTick % 4 !== 0) return;
                sendCommandToGame('REQUEST_ROLE_INFO');
            }, 1500);
            sendCommandToGame('REQUEST_ROLE_INFO');
            // Đồng bộ lựa chọn bước Quét nhanh (đã nhớ) sang game để kiểm tra tiến độ tạm dừng đúng dãy.
            [300, 1200, 3000].forEach((ms) => setTimeout(() => sendCommandToGame('UPDATE_CONFIG', { config: CONFIG }), ms));
            setTimeout(() => sendCommandToGame('REQUEST_ROLE_INFO'), 500);
            setTimeout(() => sendCommandToGame('REQUEST_ROLE_INFO'), 1500);
            setTimeout(() => sendCommandToGame('REQUEST_ROLE_INFO'), 3000);
        }

        function startInitUI() {
            if (document.getElementById('tn-auto-hud')) return;
            if (!document.body) {
                setTimeout(startInitUI, 200);
                return;
            }
            initUI();
        }

        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', startInitUI);
        } else {
            startInitUI();
        }
        setTimeout(startInitUI, 500);
        setTimeout(startInitUI, 1500);
        setTimeout(startInitUI, 3000);
    }

    // =========================================================================
    // PHẦN 2: ENGINE XỬ LÝ GAME (CHẠY BÊN TRONG NGỮ CẢNH CỦA GAME ENGINE)
    // =========================================================================
    // =========================================================================
    // SỰ KIỆN ĐANG MỞ: tab điều khiển ở cửa sổ trên cùng (một tính năng "Tướng Thần Lâm / Đạp Thiên" cho mọi banner đang mở)
    // =========================================================================
    const BANNER_REQ_SOURCE = 'TIEN_NGHICH_AUTO_BANNER_REQ';
    const BANNER_RES_SOURCE = 'TIEN_NGHICH_AUTO_BANNER_RES';
    const BANNER_POLL_MS = 30000;

    if (isTopWindow) {
        let bannerUiBuilt = false;

        function bannerUiPost(message) {
            document.querySelectorAll('iframe').forEach((f) => {
                try { f.contentWindow.postMessage(message, '*'); } catch (e) { }
            });
            try { window.postMessage(message, '*'); } catch (e) { }
        }

        function bannerUiLog(message, logType) {
            try {
                window.postMessage({ source: 'TIEN_NGHICH_AUTO_GAME', action: 'LOG', message, logType: logType || 'info' }, '*');
            } catch (e) { }
        }

        function bannerUiRequest() {
            bannerUiPost({ source: BANNER_REQ_SOURCE });
        }

        function bannerUiFormatRemain(sec) {
            const s = sec > 1e9 ? sec / 1000 : sec;
            if (!(s > 0)) return 'đã đóng';
            return 'còn ' + Math.floor(s / 86400) + 'd ' + Math.floor(s % 86400 / 3600) + 'h';
        }

        // Trạng thái tải: vòng xoay + khung xương cho danh sách banner hero, vòng xoay cho dòng thông tin banner skin.
        const BANNER_UI_LOADING_MAX_MS = 8000;
        const BANNER_UI_MIN_LOADING_MS = 600;
        let bannerUiLoadingTimer = null;

        function bannerUiSpinnerText(text) {
            const frag = document.createDocumentFragment();
            const spin = document.createElement('span');
            spin.className = 'tn-spin';
            frag.append(spin, document.createTextNode(text));
            return frag;
        }

        function bannerUiBuild() {
            if (bannerUiBuilt) return true;
            const holder = document.getElementById('tn-banner-extra');
            if (!holder) return false;
            bannerUiBuilt = true;

            // Danh sách banner đang mở: nằm dưới tính năng, chỉ để xem.
            const bar = document.createElement('div');
            bar.style.cssText = 'display:flex;gap:6px;align-items:center;margin:0 0 0 10px;';
            const refresh = document.createElement('button');
            refresh.textContent = 'Tải lại danh sách';
            refresh.style.cssText = 'background:#45475a;color:#cdd6f4;border:0;border-radius:4px;padding:3px 8px;cursor:pointer;font-size:10px;';
            const status = document.createElement('span');
            status.style.cssText = 'font-size:10px;color:#a6adc8;';
            status.textContent = 'Đang tải...';
            bar.append(refresh, status);

            const listBox = document.createElement('div');
            listBox.style.cssText = 'display:flex;flex-direction:column;gap:5px;margin-left:10px;';

            const skinLine = () => document.querySelector('.tn-feat-cfg[data-cfg-for="autoSkinBanner"]');

            // Bắt đầu tải: hiện hiệu ứng; không có phản hồi từ game sau BANNER_UI_LOADING_MAX_MS thì dừng hiệu ứng và báo chưa có dữ liệu.
            let loadingStartedAt = 0;
            function setLoading() {
                loadingStartedAt = Date.now();
                status.textContent = '';
                status.appendChild(bannerUiSpinnerText('Đang tải banner...'));
                listBox.textContent = '';
                for (let i = 0; i < 2; i++) {
                    const sk = document.createElement('div');
                    sk.className = 'tn-skeleton';
                    sk.append(document.createElement('i'), document.createElement('i'));
                    listBox.appendChild(sk);
                }
                const line = skinLine();
                if (line) { line.textContent = ''; line.appendChild(bannerUiSpinnerText('Đang tải sự kiện skin...')); }
                // Quá lâu chưa có dữ liệu (đang ở màn đăng nhập...): giữ hiệu ứng nhưng đổi lời cho rõ ràng.
                clearTimeout(bannerUiLoadingTimer);
                bannerUiLoadingTimer = setTimeout(() => {
                    if (listBox.querySelector('.tn-skeleton')) { status.textContent = ''; status.appendChild(bannerUiSpinnerText('Đang chờ game tải dữ liệu banner...')); }
                    const l = skinLine();
                    if (l && l.querySelector('.tn-spin')) { l.textContent = ''; l.appendChild(bannerUiSpinnerText('Đang chờ game tải dữ liệu sự kiện skin...')); }
                }, BANNER_UI_LOADING_MAX_MS);
            }

            refresh.addEventListener('click', () => { setLoading(); bannerUiRequest(); });

            holder.append(bar, listBox);

            function render(res) {
                listBox.textContent = '';
                if (res.error) { status.textContent = 'Lỗi: ' + res.error; return; }
                if (!res.ready) { status.textContent = 'Chưa có dữ liệu banner từ game.'; return; }
                status.textContent = res.banners.length ? res.banners.length + ' banner đang mở' : 'Hiện không có banner nào đang mở.';
                for (const b of res.banners) {
                    const item = document.createElement('div');
                    item.className = 'tn-opt-item';
                    item.style.cssText = 'border-left:3px solid #cba6f7;padding:4px 8px;cursor:default;';
                    const text = document.createElement('div');
                    const title = document.createElement('div');
                    title.style.cssText = 'font-weight:bold;color:#cba6f7;font-size:10.5px;';
                    title.textContent = '🎴 ' + b.series + (b.heroName ? ' · ' + b.heroName : '');
                    const desc = document.createElement('div');
                    desc.style.cssText = 'font-size:9.5px;color:#a6adc8;margin-top:2px;line-height:1.3;';
                    desc.textContent = '#' + b.uniqueId + (b.heroName ? '' : ' · hero ' + b.heroId) + ' · ' + bannerUiFormatRemain(b.remainSec);
                    text.append(title, desc);
                    item.appendChild(text);
                    listBox.appendChild(item);
                }
            }

            window.addEventListener('message', (event) => {
                const data = event.data;
                if (!data || data.source !== BANNER_RES_SOURCE) return;
                const frames = [...document.querySelectorAll('iframe')].map((f) => f.contentWindow);
                if (event.source !== window && !frames.includes(event.source)) return;
                // Giữ hiệu ứng tải ít nhất BANNER_UI_MIN_LOADING_MS để người dùng kịp thấy (game thường trả lời gần như ngay).
                const wait = loadingStartedAt + BANNER_UI_MIN_LOADING_MS - Date.now();
                if (wait > 0 && (listBox.querySelector('.tn-skeleton') || (skinLine() && skinLine().querySelector('.tn-spin')))) {
                    setTimeout(() => applyResponse(data), wait);
                    return;
                }
                applyResponse(data);
            });

            function applyResponse(data) {
                // Frame game trả về dữ liệu thật; frame rỗng trả ready=false nên bỏ qua nếu đã có kết quả tốt.
                if (data.skin && !data.skin.unknown) {
                    const el = document.querySelector('.tn-feat-cfg[data-cfg-for="autoSkinBanner"]');
                    if (el) {
                        el.textContent = data.skin.open
                            ? '🎴 ' + (data.skin.name || 'Skin') + ' · #' + data.skin.uniqueId + ' · ' + bannerUiFormatRemain(data.skin.remainSec)
                            : 'ℹ️ ' + (() => { const r = String(data.skin.reason || 'sự kiện skin chưa mở'); return r.charAt(0).toUpperCase() + r.slice(1) + '.'; })();
                    }
                }
                // Sự kiện (registry): dòng chỉ hiện khi game báo sự kiện đang mở (chưa biết = giữ nguyên trạng thái hiện tại).
                featureKeys((d) => d.event).forEach((k) => {
                    const st = data.events && data.events[k];
                    if (!st || st.unknown) return;
                    const ev = featureDesc(k).event;
                    const row = document.getElementById(ev.rowId);
                    const line = document.querySelector('.tn-feat-cfg[data-cfg-for="' + k + '"]');
                    if (row) row.style.display = st.open ? '' : 'none';
                    if (line && st.open) line.textContent = ev.hudLine(st, bannerUiFormatRemain);
                });
                if (!data.ready && listBox.childElementCount > 0 && !listBox.querySelector('.tn-skeleton')) return;
                if (!data.ready && listBox.querySelector('.tn-skeleton')) return;     // vẫn đang tải: đợi khung game trả lời
                render(data);
            }

            setLoading();
            // Hỏi lại mỗi 2 giây khi còn đang tải (tới khi game có dữ liệu), sau đó mỗi BANNER_POLL_MS.
            let lastRequestAt = 0;
            const request = () => { lastRequestAt = Date.now(); bannerUiRequest(); };
            request();
            setInterval(() => {
                const loading = listBox.querySelector('.tn-skeleton') || (skinLine() && skinLine().querySelector('.tn-spin'));
                if (loading || Date.now() - lastRequestAt >= BANNER_POLL_MS) request();
            }, 2000);
            return true;
        }

        const bannerUiTimer = setInterval(() => { if (bannerUiBuild()) clearInterval(bannerUiTimer); }, 400);
    }


    // =========================================================================
    // TỰ ĐỘNG VÀO LẠI GAME KHI BỊ NGẮT KẾT NỐI (CONFIG.autoReconnect)
    // Chạy ở mọi frame. Phát hiện mất kết nối bằng trạng thái nội bộ của game
    // (không dựa vào hình ảnh trên màn hình), làm mới trang rồi bấm "Vào Game".
    // =========================================================================
    const RECONNECT_STORAGE_KEY = 'TN_AUTO_RECONNECT_V2';
    const RECONNECT_HISTORY_KEY = 'TN_AUTO_RECONNECT_HISTORY_V2';
    const RECONNECT_CONFIRM_TICKS = 3;          // số nhịp 1s trạng thái mất kết nối phải giữ nguyên
    const RECONNECT_ENTRY_RETRY_MS = 3000;
    const RECONNECT_LOGIN_UI_DELAY_MS = 3000;   // chờ nút DOM trước khi dùng nút trong LoginUi
    const RECONNECT_TTL_MS = 3 * 60 * 1000;
    const RECONNECT_MAX_PER_WINDOW = 3;
    const RECONNECT_WINDOW_MS = 15 * 60 * 1000;
    const RECONNECT_SELF_RELOAD_MS = 6000;
    const RECONNECT_SIGN_WAIT_MS = 6000;        // chờ máy chủ trả chữ ký đăng nhập mới trước khi game tự nối lại

    const reconnectPageStart = Date.now();
    let reconnectLossTicks = 0;
    let reconnectWasInGame = false;
    let reconnectReloadTimer = null;
    let reconnectGaveUp = false;

    function reconnectLog(message, logType = 'info') {
        try {
            window.top.postMessage({
                source: 'TIEN_NGHICH_AUTO_GAME',
                action: 'LOG',
                message: message,
                logType: logType
            }, '*');
        } catch (e) { }
    }

    function reconnectReadState() {
        try {
            const raw = sessionStorage.getItem(RECONNECT_STORAGE_KEY);
            if (!raw) return null;
            const state = JSON.parse(raw);
            if (state && typeof state.startedAt === 'number') return state;
        } catch (e) { }
        reconnectClearState();
        return null;
    }

    function reconnectWriteState(state) {
        try {
            sessionStorage.setItem(RECONNECT_STORAGE_KEY, JSON.stringify(state));
            return true;
        } catch (e) {
            return false;
        }
    }

    function reconnectClearState() {
        try { sessionStorage.removeItem(RECONNECT_STORAGE_KEY); } catch (e) { }
    }

    // Đếm số lần khôi phục gần đây để tránh vòng lặp làm mới vô hạn (vd: bị đá do đăng nhập nơi khác).
    function reconnectRecordAttempt() {
        const now = Date.now();
        let history = [];
        try {
            history = JSON.parse(sessionStorage.getItem(RECONNECT_HISTORY_KEY) || '[]')
                .filter((t) => typeof t === 'number' && now - t < RECONNECT_WINDOW_MS);
        } catch (e) { }
        if (history.length >= RECONNECT_MAX_PER_WINDOW) return false;
        history.push(now);
        try { sessionStorage.setItem(RECONNECT_HISTORY_KEY, JSON.stringify(history)); } catch (e) { }
        return true;
    }

    function reconnectGameGlobals() {
        const g = window;
        if (!g.LoginCtrl || !g.StateMgr || !g.EStateGroup ||
            typeof g.LoginCtrl.gInst !== 'function' || typeof g.StateMgr.gInst !== 'function') return null;
        const login = g.LoginCtrl.gInst();
        const stateMgr = g.StateMgr.gInst();
        if (!login || !stateMgr) return null;
        return { login, stateMgr, net: g.NetMgr && g.NetMgr.gInst ? g.NetMgr.gInst() : null, group: g.EStateGroup };
    }

    // Trạng thái kết nối đọc thẳng từ game: hộp thoại "Đăng nhập lại", cờ bị đá/xác minh thất bại, socket.
    function reconnectReadConnection() {
        const ctx = reconnectGameGlobals();
        if (!ctx) return null;
        let dialog = false;
        try {
            const viewMgr = window.ViewMgr && window.ViewMgr.gInst();
            const viewName = (window.ViewConst && window.ViewConst.disconnectUi) || 'disconnectUi';
            dialog = !!(viewMgr && viewMgr.isUpViewVisible(viewName));
        } catch (e) { }
        return {
            inLogin: !!ctx.stateMgr.isCurState(ctx.group.login),
            inMain: !!ctx.stateMgr.isCurState(ctx.group.main),
            connected: ctx.net ? ctx.net.m_isConnectServer !== false : true,
            kicked: ctx.login.m_isKick === true,
            dialog: dialog
        };
    }

    function reconnectIsGameEntered() {
        const c = reconnectReadConnection();
        return !!(c && c.inMain && c.connected && !c.kicked && !c.dialog);
    }

    function reconnectFindEnterGameButton() {
        const candidates = document.querySelectorAll(
            'button, a, [role="button"], input[type="button"], input[type="submit"], div, span'
        );
        for (const el of candidates) {
            if (el.children.length > 0 && !/^(BUTTON|A)$/.test(el.tagName)) continue;
            const text = (el.innerText || el.textContent || el.value || '').replace(/\s+/g, ' ').trim().toLowerCase();
            if (text !== 'vào game') continue;
            const rect = el.getBoundingClientRect();
            const style = getComputedStyle(el);
            if (rect.width > 0 && rect.height > 0 && style.display !== 'none' &&
                style.visibility !== 'hidden' && !el.disabled) return el;
        }
        return null;
    }

    // Nút "Vào game" vẽ trong canvas: màn chọn server (selectServerUi.startBtnClick) hoặc màn loginUi.
    function reconnectFindEntryView() {
        try {
            const viewMgr = window.ViewMgr && window.ViewMgr.gInst();
            if (!viewMgr) return null;
            for (const [name, handler] of [['selectServerUi', 'startBtnClick'], ['loginUi', 'loginBtnClick']]) {
                if (!viewMgr.viewIsVisible(name)) continue;
                const view = viewMgr.getViewByName(name);
                if (view && typeof view[handler] === 'function') return { view, handler, name };
            }
        } catch (e) { }
        return null;
    }

    // Game tự nối lại bằng chữ ký/thời gian đăng nhập (sign/time) lấy từ lần tải trang đầu; để lâu máy chủ từ chối
    // ("Xác minh đăng ký thất bại") và phải làm mới trang. Trước mỗi lần game gọi reconnectServer, xin lại danh sách
    // server (cùng lệnh game dùng ở màn chọn server) để có sign/time mới, rồi mới để game nối lại.
    let reconnectSignHooked = false;
    function reconnectHookSignRefresh() {
        if (reconnectSignHooked) return;
        const g = window;
        if (!g.LoginCtrl || !g.LoginCtrl.prototype || typeof g.LoginCtrl.prototype.reconnectServer !== 'function' ||
            !g.PlatformMgr || typeof g.PlatformMgr.gInst !== 'function') return;
        const proto = g.LoginCtrl.prototype;
        reconnectSignHooked = true;
        if (proto.__tnSignHooked) return;
        proto.__tnSignHooked = true;
        const orig = proto.reconnectServer;
        proto.reconnectServer = function () {
            const self = this;
            const args = arguments;
            if (!CONFIG.autoReconnect || self.__tnSignRefreshing) {
                return self.__tnSignRefreshing ? undefined : orig.apply(self, args);
            }
            let platform = null;
            try { platform = g.PlatformMgr.gInst(); } catch (e) { }
            if (!platform || typeof platform.requestServerList !== 'function' || (typeof platform.isOutside === 'function' && !platform.isOutside())) {
                return orig.apply(self, args);
            }
            const before = { sign: self.sign, time: self.time };
            self.__tnSignRefreshing = true;
            const startedAt = Date.now();
            try { platform.requestServerList(); } catch (e) { }
            let done = false;
            const finish = (fresh) => {
                if (done) return;
                done = true;
                self.__tnSignRefreshing = false;
                reconnectLog(fresh
                    ? '🔑 [Vào lại game] Đã lấy chữ ký đăng nhập mới từ máy chủ; cho game nối lại.'
                    : 'ℹ️ [Vào lại game] Chưa nhận được chữ ký đăng nhập mới; cho game nối lại bằng chữ ký cũ (nếu bị từ chối sẽ làm mới trang).', fresh ? 'action' : 'info');
                try { orig.apply(self, args); } catch (e) { console.error('[Tiên Nghịch Auto] reconnectServer lỗi.', e); }
            };
            const wait = setInterval(() => {
                const fresh = self.sign !== before.sign || self.time !== before.time;
                if (fresh || Date.now() - startedAt >= RECONNECT_SIGN_WAIT_MS) {
                    clearInterval(wait);
                    finish(fresh);
                }
            }, 200);
        };
    }

    // Frame game phát hiện mất kết nối -> nhờ cửa sổ trên cùng làm mới trang (frame con khác origin không tự reload được top).
    function reconnectBegin(reason) {
        if (reconnectReadState()) return;
        if (!reconnectRecordAttempt()) {
            if (!reconnectGaveUp) {
                reconnectGaveUp = true;
                reconnectLog(`❌ [Vào lại game] Đã tự vào lại ${RECONNECT_MAX_PER_WINDOW} lần trong ${RECONNECT_WINDOW_MS / 60000} phút mà vẫn mất kết nối (${reason}); dừng tự động để tránh lặp vô hạn. Hãy kiểm tra tài khoản/mạng.`, 'err');
            }
            return;
        }
        const resume = !!CONFIG.running;
        reconnectWriteState({ phase: 'reload', reason, resume, startedAt: Date.now(), lastAttemptAt: 0, attempts: 0 });
        reconnectLog(`⚠️ [Vào lại game] Phát hiện mất kết nối (${reason}); sẽ làm mới trang và bấm “Vào Game”${resume ? ', sau đó tự chạy lại Auto' : ''}.`, 'warn');
        try {
            window.top.postMessage({
                source: 'TIEN_NGHICH_AUTO_GAME',
                action: 'AUTO_RECONNECT_RELOAD',
                reason: reason,
                resume: resume
            }, '*');
        } catch (e) { }
        clearTimeout(reconnectReloadTimer);
        reconnectReloadTimer = setTimeout(() => {
            // Top không phản hồi: tự làm mới frame hiện tại.
            reconnectLog('ℹ️ [Vào lại game] Cửa sổ chính chưa làm mới; tự làm mới frame game.', 'info');
            try { location.reload(); } catch (e) { }
        }, RECONNECT_SELF_RELOAD_MS);
    }

    // Cửa sổ trên cùng: đánh dấu đang chờ vào lại (để tìm nút "Vào Game" trên trang bọc game) rồi làm mới.
    function reconnectTopPrepare(reason, resume) {
        const existing = reconnectReadState();
        if (existing && existing.phase === 'reload' && existing.topMarked) return false;
        const runConfig = Object.assign({}, CONFIG, { running: false });
        reconnectWriteState({
            phase: 'reload', reason, resume: !!resume, startedAt: Date.now(),
            lastAttemptAt: 0, attempts: 0, topMarked: true,
            runConfig: resume ? runConfig : undefined
        });
        return true;
    }

    // Cửa sổ trên cùng: game đã báo vào lại xong -> bỏ trạng thái chờ.
    function reconnectTopDone() {
        reconnectClearState();
    }

    function reconnectFinish(state) {
        clearTimeout(reconnectReloadTimer);
        reconnectClearState();
        reconnectLossTicks = 0;
        reconnectGaveUp = false;
        if (!state) return;
        reconnectLog('✅ [Vào lại game] Đã xác nhận vào lại game (trạng thái game: đã vào màn chính, kết nối ổn định).', 'run');
        try {
            window.top.postMessage({
                source: 'TIEN_NGHICH_AUTO_GAME',
                action: 'AUTO_RECONNECT_GAME_READY',
                resume: !!state.resume
            }, '*');
        } catch (e) { }
    }

    function reconnectPendingTick(state) {
        const now = Date.now();
        if (state.phase === 'reload') {
            // Còn ở trang cũ (đang chờ làm mới): chưa làm gì.
            if (state.startedAt >= reconnectPageStart) return;
            state.phase = 'await-entry';
            state.pageLoadedAt = now;
            reconnectWriteState(state);
            if (reconnectGameGlobals()) reconnectLog('🔄 [Vào lại game] Trang đã làm mới; đang chờ nút “Vào Game”.', 'info');
        }

        if (reconnectIsGameEntered()) {
            reconnectFinish(state);
            return;
        }

        if (now - state.startedAt > RECONNECT_TTL_MS) {
            reconnectClearState();
            if (window === window.top) {
                reconnectLog('❌ [Vào lại game] Quá thời gian chờ vào lại game (không xác nhận được trạng thái vào game); hãy vào game thủ công.', 'err');
            }
            return;
        }

        if (now - (state.lastAttemptAt || 0) < RECONNECT_ENTRY_RETRY_MS) return;

        let clicked = false;
        try {
            const button = reconnectFindEnterGameButton();
            if (button) {
                button.click();
                clicked = true;
            } else if (now - (state.pageLoadedAt || state.startedAt) >= RECONNECT_LOGIN_UI_DELAY_MS) {
                const entry = reconnectFindEntryView();
                const ctx = reconnectGameGlobals();
                if (entry && !(ctx && ctx.login.m_isLoginServer)) {
                    entry.view[entry.handler]({
                        target: entry.view, currentTarget: entry.view,
                        preventDefault() { }, stopPropagation() { }
                    });
                    clicked = true;
                }
            }
        } catch (e) {
            console.error('[Tiên Nghịch Auto] Không thể bấm “Vào Game”.', e);
            reconnectLog('❌ [Vào lại game] Không thể bấm “Vào Game”; xem console để biết chi tiết.', 'err');
        }
        if (clicked) {
            state.lastAttemptAt = now;
            state.attempts = (state.attempts || 0) + 1;
            reconnectWriteState(state);
            if (state.attempts === 1) reconnectLog('🎮 [Vào lại game] Đã bấm “Vào Game”; đang chờ game xác nhận.', 'action');
        }
    }

    function reconnectDetectTick() {
        if (!CONFIG.autoReconnect) { reconnectLossTicks = 0; return; }
        const c = reconnectReadConnection();
        if (!c) return;

        if (c.inMain && c.connected && !c.kicked && !c.dialog) {
            reconnectWasInGame = true;
            reconnectLossTicks = 0;
            reconnectGaveUp = false;
            return;
        }

        let reason = '';
        if (c.dialog && !c.inLogin) reason = 'hộp thoại “Đăng nhập lại”';
        // Xác minh thất bại: game đặt cờ bị đá và có thể về màn đăng nhập; vẫn phải làm mới trang (đã từng ở trong game ở trang này).
        else if (c.kicked && reconnectWasInGame) reason = 'Xác minh thất bại / bị ngắt phiên';
        if (!reason) { reconnectLossTicks = 0; return; }

        reconnectLossTicks++;
        if (reconnectLossTicks >= RECONNECT_CONFIRM_TICKS) {
            reconnectLossTicks = 0;
            reconnectBegin(reason);
        }
    }

    setInterval(() => {
        try {
            reconnectHookSignRefresh();
            const state = reconnectReadState();
            if (state) reconnectPendingTick(state);
            else reconnectDetectTick();
        } catch (e) {
            console.error('[Tiên Nghịch Auto] Lỗi theo dõi kết nối.', e);
        }
    }, 1000);
    const isGameContext = !!window.DailyDungeonCtrl || !isTopWindow;
    if (isGameContext) {
        // ĐỨNG HÌNH KHI BẤM BẢNG/BONG BÓNG (iPhone, tìm ra 2026-11-14): engine Egret của game tự TẠM DỪNG khi cửa sổ khung game mất focus
        // (egret.web WebLifeCycleHandler: window "blur" -> lifecycle.pause() dừng ticker/vẽ, chỉ "focus" hoặc visibilitychange mới tiếp tục).
        // Bấm bất kỳ thứ gì ở trang cha (bong bóng ⚡, thẻ HUD) làm khung game mất focus, mà Safari iPhone không trả focus khi bấm lại game
        // nên hình đứng cho tới khi rời trang rồi quay lại (visibilitychange). Chặn "blur" khi trang vẫn đang hiển thị; việc tạm dừng thật
        // (rời tab/khóa màn hình) vẫn đi qua visibilitychange/pagehide của engine. Đăng ký ở pha bắt (capture) để chạy trước engine.
        window.addEventListener('blur', (ev) => {
            if (document.visibilityState === 'visible') ev.stopImmediatePropagation();
        }, true);
        // Từ đây trở xuống là logic tính năng: bản iPhone không đóng gói vào userscript mà tải từ máy chủ (xem platform/phone/license.js).
        /*@BLOCK-START*/
        // =========================================================================
        // BẢN QUYỀN (build có bản quyền: iPhone, và PC khi build --licensed; chạy trong khung game; file nằm ngoài platform/ vì dùng chung). Máy chủ: auto-tn-server (Render), xem docs/license-plan.md.
        // - Key + mã thiết bị lưu ở HUD (localStorage của trang chính, bền hơn khung game) và được HUD gửi sang đây (LICENSE_CONFIG).
        // - Kích hoạt (/v1/activate) khi đã có key + ID nhân vật; kiểm tra lại (/v1/heartbeat) mỗi 5 phút để giữ "ghế" chạy.
        //   Mỗi key tối đa 2 thiết bị, mỗi lúc chỉ 1 thiết bị chạy; thiết bị khác kích hoạt sẽ giành ghế (409 session_taken).
        // - Cổng: TOGGLE_AUTO (game-bridge.js) hỏi licenseGate() trước khi chạy. Mất ghế / hết hạn / thu hồi -> dừng Auto.
        // - Máy chủ miễn phí ngủ sau 15 phút: lần gọi đầu có thể mất ~1 phút. Máy chủ không liên lạc được: vẫn chạy tối đa
        //   grace_seconds (mặc định 1 giờ) kể từ lần kiểm tra thành công gần nhất, rồi dừng.
        // Không ghi token/key đầy đủ vào log.
        // PHASE 2: file này là phần "vỏ" luôn nằm trong userscript. Toàn bộ logic tính năng (khối game trong game-bridge.js ... scheduler.js)
        // KHÔNG nằm trong userscript: sau khi kích hoạt, vỏ tải nó từ máy chủ (POST /v1/bundle, chỉ thiết bị đang giữ ghế) MỘT lần mỗi phiên,
        // chạy bằng eval trong bộ nhớ và không lưu xuống đâu cả. Tải lại trang = tải lại bundle.
        // =========================================================================
        const LICENSE_API = 'https://auto-tn-server.onrender.com';
        const LICENSE_VERSION = '1.0.12';   // phải khớp @version trong userscript-header.js (build-userscript.js kiểm tra)
        const LICENSE_ACTIVATE_TIMEOUT_MS = 90000;   // chờ máy chủ miễn phí thức dậy
        const LICENSE_RETRY_MS = 30000;
        const LICENSE_GATE_MAX_TRIES = 240;           // 240 x 1s chờ kích hoạt + tải tính năng khi bấm BẮT ĐẦU / tự vào lại game
        const LICENSE_BUNDLE_API = 1;                 // phải khớp `api=` trong dòng đầu của bundle (build-content.js); lệch = cần cập nhật vỏ
        const LICENSE_PLATFORM = TN_IS_PHONE ? 'phone' : 'pc';   // gửi kèm activate/heartbeat/bundle; máy chủ đối chiếu với quyền của key (phone | pc | both)
        const licenseHooks = { abort: null, sendLog: null };   // bundle đăng ký runAbort/sendLog vào đây (game-bridge.js)

        const lic = {
            key: '', deviceId: '', deviceLabel: '',
            state: 'nokey',      // nokey | waiting | checking | ok | denied | offline
            message: '', plan: '', expiresAt: '', token: '',
            hbSec: 300, graceSec: 3600, lastGoodAt: 0,
            roleUid: '', server: '',
            timer: null, busy: false, startedLoop: false,
            bundleReady: false, okMessage: '',
            update: null,        // { version, note } khi máy chủ có bản mới hơn bản đang chạy (chỉ nhắc, không chặn)
            updateLogged: false,
        };
        const LICENSE_KEY_RE = /^TN-[A-Z0-9]{5}(-[A-Z0-9]{5}){3}$/;

        function licenseMaskKey(k) { const p = String(k || '').split('-'); return p.length === 5 ? p[0] + '-' + p[1] + '-•••••-•••••-' + p[4] : ''; }

        function licensePush() {
            try {
                window.top.postMessage({
                    source: 'TIEN_NGHICH_AUTO_GAME', action: 'LICENSE_STATUS',
                    state: lic.state, message: lic.message, plan: lic.plan, expiresAt: lic.expiresAt, keyMasked: licenseMaskKey(lic.key),
                    update: lic.update, platform: LICENSE_PLATFORM, version: LICENSE_VERSION,
                }, '*');
            } catch (e) { }
        }

        // Cách cập nhật theo nền tảng (iPhone: chạy lại phím tắt; PC: tải lại file zip). Dùng cho cả nhắc nhẹ lẫn bị chặn.
        function licenseUpdateHow() {
            return LICENSE_PLATFORM === 'phone'
                ? 'Chạy lại phím tắt cập nhật, đóng hẳn Safari rồi mở lại.'
                : 'Tải file zip mới (bản cập nhật), giải nén đè lên thư mục tiện ích rồi tải lại tiện ích trong trình duyệt.';
        }
        function licenseVerNewer(a, b) {   // true nếu a > b (dạng x.y.z)
            const p = (v) => String(v || '').split('.').map((n) => parseInt(n, 10) || 0);
            const x = p(a), y = p(b);
            for (let i = 0; i < 3; i++) { if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) > (y[i] || 0); }
            return false;
        }
        // Máy chủ báo phiên bản mới nhất trong phản hồi activate/heartbeat: chỉ nhắc, không dừng Auto.
        function licenseNoteLatest(j) {
            const v = j && typeof j.latest_version === 'string' ? j.latest_version : '';
            const next = v && licenseVerNewer(v, LICENSE_VERSION) ? { version: v, note: j.latest_note ? String(j.latest_note).slice(0, 120) : '' } : null;
            const changed = JSON.stringify(next) !== JSON.stringify(lic.update);
            lic.update = next;
            if (next && !lic.updateLogged) {
                lic.updateLogged = true;   // một dòng nhắc cho mỗi phiên, không lặp lại
                try { const line = '🆕 Có bản mới ' + next.version + ' (đang dùng ' + LICENSE_VERSION + '). ' + licenseUpdateHow(); if (licenseHooks.sendLog) licenseHooks.sendLog(line, 'warn'); else window.top.postMessage({ source: 'TIEN_NGHICH_AUTO_GAME', action: 'LOG', message: line, logType: 'warn' }, '*'); } catch (e) { }
            }
            if (changed) licensePush();
        }

        function licenseSet(state, message) {
            const changed = lic.state !== state || lic.message !== message;
            lic.state = state; lic.message = message || '';
            if (changed) licensePush();
        }

        // Được gọi từ sendRoleInfo (game-bridge.js) mỗi khi có thông tin nhân vật.
        function licenseNoteRole(role) {
            try {
                if (!role || !role.uid || String(role.uid) === String(role.name)) return;   // uid rơi về tên nhân vật = chưa có ID thật
                lic.roleUid = String(role.uid);
                lic.server = 'tn';   // khóa chỉ theo ID nhân vật (duy nhất toàn game); không dùng ID máy chủ game vì đọc không ổn định có thể làm key bị từ chối sai
                if (lic.state === 'waiting') licenseStart();
            } catch (e) { }
        }

        // Đọc ID nhân vật (cùng cách lấy như sendRoleInfo trong game-bridge.js để ID khóa key không đổi). Vỏ phải tự đọc vì bundle chưa tải.
        function licParseLong(val) {
            if (val === null || val === undefined) return 0;
            if (typeof val === 'number') return val;
            if (typeof val === 'string') return Number(val) || 0;
            if (typeof val === 'object') {
                if (window.CommonUtils && typeof window.CommonUtils.to64Num === 'function') { try { const n = window.CommonUtils.to64Num(val); if (n) return n; } catch (e) { } }
                if (typeof val.dataNum === 'number') return val.dataNum;
                if (val.dataStr) return Number(val.dataStr) || 0;
                if (typeof val.toNumber === 'function') { try { return val.toNumber(); } catch (e) { } }
                if (typeof val.toString === 'function') { try { const s = val.toString(); if (s && s !== '[object Object]') return Number(s) || 0; } catch (e) { } }
                if (val.low !== undefined && val.high !== undefined) return (val.high * 4294967296) + (val.low >>> 0);
            }
            return 0;
        }
        function licParseUid(val) {
            if (val === null || val === undefined) return '';
            if (typeof val === 'string') return val.trim();
            if (typeof val === 'number') return String(val);
            if (typeof val === 'object') {
                if (val.dataStr) return String(val.dataStr);
                if (typeof val.dataNum === 'number') return String(val.dataNum);
                if (typeof val.toString === 'function') { try { const s = val.toString(); if (s && s !== '[object Object]') return s; } catch (e) { } }
                if (val.low !== undefined && val.high !== undefined) return String(licParseLong(val));
            }
            return '';
        }
        function licenseReadRole() {
            let role = null, curl = null, inst = null;
            if (window.RoleCtrl && window.RoleCtrl.gInst) {
                try {
                    inst = window.RoleCtrl.gInst();
                    if (typeof inst.getRoleInfo === 'function') role = inst.getRoleInfo();
                    if (!role && inst.roleData) role = inst.roleData;
                    if (!role && typeof inst.getCurlModel === 'function') curl = inst.getCurlModel();
                } catch (e) { }
            }
            if (!role && window.PlayerCtrl && window.PlayerCtrl.gInst) {
                try { const p = window.PlayerCtrl.gInst(); if (p && typeof p.getRoleInfo === 'function') role = p.getRoleInfo(); } catch (e) { }
            }
            let name = '', uid = '', level = 0, power = 0;
            if (role) {
                name = role.name || role.role_name || role.roleName || role.nick || '';
                if (role.lev !== undefined && role.lev !== null) level = Number(role.lev) || 0;
                else if (role.level !== undefined && role.level !== null) level = Number(role.level) || 0;
                else if (role.lv !== undefined && role.lv !== null) level = Number(role.lv) || 0;
                power = licParseLong(role.fc) || licParseLong(role.power) || licParseLong(role.fight) || 0;
                uid = licParseUid(role.rid) || licParseUid(role.uid) || licParseUid(role.role_id) || licParseUid(role.roleId) || licParseUid(role.id) || licParseUid(role.playerId) || '';
            }
            if (!name && curl) {
                name = curl.name || '';
                if (!level) level = Number(curl.lev || curl.level || 0);
                if (!power) power = licParseLong(curl.fc) || 0;
                if (!uid) uid = licParseUid(curl.uid) || licParseUid(curl.rid) || '';
            }
            if (!uid && role && role.rid) { if (role.rid.dataStr) uid = String(role.rid.dataStr); else if (typeof role.rid === 'object' && role.rid.low !== undefined) uid = licParseLong(role.rid).toString(); }
            if (!uid && role && role.id) { if (role.id.dataStr) uid = String(role.id.dataStr); else if (typeof role.id === 'object' && role.id.low !== undefined) uid = licParseLong(role.id).toString(); }
            if (!uid && window.zsSdk && window.zsSdk.roleId) uid = String(window.zsSdk.roleId);
            if (!name && window.zsSdk && window.zsSdk.roleName) name = String(window.zsSdk.roleName);
            if (!uid && window.zsChannelSdk && window.zsChannelSdk.roleId) uid = String(window.zsChannelSdk.roleId);
            if (!level && inst && typeof inst.getRoleLv === 'function') { try { level = Number(inst.getRoleLv()) || 0; } catch (e) { } }
            return { uid, name, level, power };
        }

        async function licenseCall(path, body, timeoutMs) {
            const ctrl = new AbortController();
            const timer = setTimeout(() => ctrl.abort(), timeoutMs);
            try {
                const resp = await fetch(LICENSE_API + path, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body), signal: ctrl.signal, cache: 'no-store' });
                let json = null; try { json = await resp.json(); } catch (e) { }
                return { status: resp.status, json: json || {} };
            } catch (e) {
                return { status: 0, json: { error: e && e.name === 'AbortError' ? 'timeout' : 'network' } };
            } finally { clearTimeout(timer); }
        }

        function licenseSchedule(ms) {
            clearTimeout(lic.timer);
            lic.timer = setTimeout(licenseLoop, ms);
        }

        // Dừng Auto đang chạy vì mất bản quyền (không đụng trạng thái game; giống người dùng bấm TẠM DỪNG).
        function licenseStopAuto(reason) {
            try {
                if (!CONFIG.running) return;
                CONFIG.running = false;
                if (licenseHooks.abort) licenseHooks.abort();
                const line = '🔒 ' + reason + ' Auto đã dừng.';
                if (licenseHooks.sendLog) licenseHooks.sendLog(line, 'err'); else window.top.postMessage({ source: 'TIEN_NGHICH_AUTO_GAME', action: 'LOG', message: line, logType: 'err' }, '*');
                window.top.postMessage({ source: 'TIEN_NGHICH_AUTO_GAME', action: 'AUTO_FINISHED', message: '🔒 Auto dừng: ' + reason }, '*');
            } catch (e) { }
        }

        async function licenseActivate() {
            licenseSet('checking', 'Đang kiểm tra bản quyền… (máy chủ miễn phí có thể mất ~1 phút để thức dậy)');
            const r = await licenseCall('/v1/activate', {
                key: lic.key, device_id: lic.deviceId, device_label: lic.deviceLabel,
                game_server: lic.server, game_uid: lic.roleUid, version: LICENSE_VERSION, platform: LICENSE_PLATFORM,
            }, LICENSE_ACTIVATE_TIMEOUT_MS);
            const j = r.json;
            if (r.status === 200 && j.ok) {
                lic.token = j.session_token; lic.plan = j.plan; lic.expiresAt = j.license_expires_at;
                lic.hbSec = Math.max(60, Number(j.heartbeat_seconds) || 300); lic.graceSec = Math.max(60, Number(j.grace_seconds) || 3600);
                lic.lastGoodAt = Date.now();
                licenseNoteLatest(j);
                const days = Math.max(0, Math.ceil((new Date(j.license_expires_at).getTime() - Date.now()) / 86400000));
                const planName = j.plan === 'trial' ? 'Dùng thử' : 'Tháng';
                lic.okMessage = `Đã kích hoạt (${planName}, còn ${days} ngày).`;
                licenseSet(lic.bundleReady ? 'ok' : 'checking', lic.bundleReady ? lic.okMessage : 'Đang tải tính năng từ máy chủ…');
                return 'ok';
            }
            if (r.status === 0 || r.status >= 500 || r.status === 429) {
                // Không liên lạc được / máy chủ bận: giữ chạy trong thời gian ân hạn nếu từng kiểm tra thành công.
                const withinGrace = lic.lastGoodAt && Date.now() - lic.lastGoodAt < lic.graceSec * 1000;
                licenseSet(withinGrace ? 'ok' : 'offline', withinGrace ? 'Máy chủ bản quyền chưa phản hồi, đang chạy trong thời gian ân hạn.' : 'Không kết nối được máy chủ bản quyền, sẽ thử lại.');
                return 'retry';
            }
            // Bị từ chối rõ ràng (sai key, hết hạn, thu hồi, khác tài khoản, đủ thiết bị, cần cập nhật...): chờ người dùng xử lý.
            lic.token = '';
            licenseSet('denied', j.error === 'update_required' ? 'Phiên bản này đã quá cũ, bắt buộc cập nhật mới dùng tiếp được. ' + licenseUpdateHow() : (j.message || 'Bản quyền bị từ chối.'));
            licenseStopAuto(lic.message);
            return 'denied';
        }

        async function licenseHeartbeat() {
            const r = await licenseCall('/v1/heartbeat', { key: lic.key, device_id: lic.deviceId, session_token: lic.token, platform: LICENSE_PLATFORM }, 30000);
            const j = r.json;
            if (r.status === 200 && j.ok) { lic.lastGoodAt = Date.now(); licenseNoteLatest(j); lic.expiresAt = j.license_expires_at || lic.expiresAt; if (lic.state !== 'ok' && lic.bundleReady) licenseSet('ok', lic.okMessage || 'Bản quyền hợp lệ.'); return 'ok'; }
            if (r.status === 401) return 'reactivate';   // no_session | bad_token | session_expired: lấy lại ghế
            if (r.status === 409 || r.status === 403 || r.status === 400) {
                lic.token = '';
                licenseSet('denied', j.message || 'Bản quyền bị từ chối.');
                licenseStopAuto(lic.message);
                return 'denied';
            }
            // Mạng / máy chủ lỗi: chạy tiếp trong thời gian ân hạn, hết thì dừng.
            if (Date.now() - lic.lastGoodAt > lic.graceSec * 1000) {
                licenseSet('offline', 'Mất kết nối máy chủ bản quyền quá lâu.');
                licenseStopAuto(lic.message);
                return 'denied';
            }
            return 'retry';
        }

        // Chạy bundle bằng eval TRỰC TIẾP (strict): thấy các biến của vỏ (CONFIG, lic, licenseGate...) nhưng khai báo của bundle nằm trong phạm vi riêng.
        function licenseRunBundle(code) { eval(code); }

        async function licenseLoadBundle() {
            if (lic.bundleReady) return 'ok';
            licenseSet('checking', 'Đang tải tính năng từ máy chủ…');
            const ctrl = new AbortController();
            const timer = setTimeout(() => ctrl.abort(), LICENSE_ACTIVATE_TIMEOUT_MS);
            try {
                const resp = await fetch(LICENSE_API + '/v1/bundle', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ key: lic.key, device_id: lic.deviceId, session_token: lic.token, platform: LICENSE_PLATFORM }), signal: ctrl.signal, cache: 'no-store' });
                if (resp.status !== 200) {
                    let j = {}; try { j = await resp.json(); } catch (e) { }
                    if (resp.status === 401) { lic.token = ''; return 'reactivate'; }   // phiên hết: lấy lại ghế rồi tải lại
                    if (resp.status >= 500 || resp.status === 429) { licenseSet('offline', 'Máy chủ bản quyền bận, sẽ thử tải tính năng lại.'); return 'retry'; }
                    lic.token = '';
                    licenseSet('denied', j.message || 'Không tải được tính năng.');
                    licenseStopAuto(lic.message);
                    return 'denied';
                }
                const code = await resp.text();
                const m = /^\/\*TN-BUNDLE api=(\d+)/.exec(code);
                if (!m || Number(m[1]) !== LICENSE_BUNDLE_API) { licenseSet('denied', 'Phiên bản ứng dụng cũ, cần cập nhật. ' + licenseUpdateHow()); return 'denied'; }
                try { licenseRunBundle(code); }
                catch (e) { licenseSet('denied', 'Không chạy được tính năng: ' + String(e && e.message || e).slice(0, 80)); return 'denied'; }
                lic.bundleReady = true;
                licenseSet('ok', lic.okMessage || 'Bản quyền hợp lệ.');
                return 'ok';
            } catch (e) {
                licenseSet('offline', 'Không tải được tính năng (mạng/máy chủ), sẽ thử lại.');
                return 'retry';
            } finally { clearTimeout(timer); }
        }

        async function licenseLoop() {
            if (lic.busy) return;
            lic.busy = true;
            try {
                if (!lic.key || !lic.deviceId) { licenseSet('nokey', 'Chưa nhập key bản quyền.'); return; }
                if (!lic.roleUid) { licenseSet('waiting', 'Đang chờ đăng nhập game để kích hoạt…'); return; }
                let res;
                if (lic.token) {
                    res = await licenseHeartbeat();
                    if (res === 'reactivate') res = await licenseActivate();
                } else {
                    res = await licenseActivate();
                }
                if (res === 'ok' && !lic.bundleReady) { res = await licenseLoadBundle(); if (res === 'reactivate') res = await licenseActivate(); if (res === 'ok' && !lic.bundleReady) res = await licenseLoadBundle(); }
                if (res === 'ok') licenseSchedule(lic.hbSec * 1000);
                else if (res === 'retry') licenseSchedule(LICENSE_RETRY_MS);
                // 'denied': không tự thử lại; người dùng sửa key / bấm "Kiểm tra lại".
            } catch (e) {
                licenseSchedule(LICENSE_RETRY_MS);
            } finally { lic.busy = false; }
        }

        function licenseStart() { clearTimeout(lic.timer); lic.token = ''; licenseSchedule(50); }

        // HUD gửi key + mã thiết bị (và khi người dùng nhập key mới / bấm kiểm tra lại).
        function licenseConfigure(data) {
            const key = String(data && data.key || '').toUpperCase().trim();
            const changed = key !== lic.key;
            lic.key = LICENSE_KEY_RE.test(key) ? key : '';
            lic.deviceId = String(data && data.device_id || '');
            lic.deviceLabel = String(data && data.device_label || '').slice(0, 80);
            if (!lic.key) { clearTimeout(lic.timer); lic.token = ''; licenseSet('nokey', key ? 'Key không đúng định dạng (TN-XXXXX-XXXXX-XXXXX-XXXXX).' : 'Chưa nhập key bản quyền.'); return; }
            if (changed || (data && data.force)) licenseStart();
            else if (!lic.startedLoop) licenseStart();
            lic.startedLoop = true;
        }

        // Cổng chạy Auto: null = được chạy; { pending: true } = chờ kích hoạt xong; { message } = chặn.
        function licenseGate() {
            if (lic.state === 'ok') return null;
            if (lic.state === 'offline' && lic.lastGoodAt && Date.now() - lic.lastGoodAt < lic.graceSec * 1000) return null;
            if (lic.state === 'checking' || lic.state === 'waiting') return { pending: true, message: 'Đang kiểm tra bản quyền…' };
            if (lic.state === 'nokey') return { message: '🔒 Chưa có key bản quyền: vào ⚙️ Cài đặt → Bản quyền, nhập key rồi bấm Kích hoạt.' };
            return { message: '🔒 ' + (lic.message || 'Bản quyền không hợp lệ.') + ' Vào ⚙️ Cài đặt → Bản quyền để xử lý.' };
        }

        // Khung game hỏi HUD cấu hình cho tới khi nhận được (HUD có thể tải sau khung game).
        setInterval(() => {
            if (lic.key && lic.deviceId) return;
            try { window.top.postMessage({ source: 'TIEN_NGHICH_AUTO_GAME', action: 'LICENSE_NEED_CONFIG' }, '*'); } catch (e) { }
        }, 2500);
        setInterval(licensePush, 30000);   // HUD luôn có trạng thái mới nhất
        // Vỏ tự đọc ID nhân vật (bundle chưa tải) cho tới khi có ID thật.
        const licenseRoleTimer = setInterval(() => {
            if (lic.roleUid) { clearInterval(licenseRoleTimer); return; }
            try { const r = licenseReadRole(); licenseNoteRole({ uid: r.uid, name: r.name }); } catch (e) { }
        }, 2000);

        // Báo nhân vật cho HUD (ROLE_INFO) khi bundle chưa tải: HUD ẩn toàn bộ bảng (kể cả ô nhập key) cho tới khi nhận Lv/LC, nên vỏ phải tự báo,
        // nếu không người dùng mới không bao giờ thấy ô Bản quyền. Khi bundle chạy, sendRoleInfo của bundle thay thế.
        setInterval(() => {
            if (lic.bundleReady) return;
            try {
                const r = licenseReadRole();
                if (!r.name && !r.uid) return;
                window.top.postMessage({ source: 'TIEN_NGHICH_AUTO_GAME', action: 'ROLE_INFO', role: { uid: r.uid || r.name, name: r.name, level: r.level, power: r.power } }, '*');
            } catch (e) { }
        }, 3000);

        // Tin nhắn từ HUD mà vỏ phải xử lý trước khi bundle tải xong; sau đó bundle (game-bridge.js) tự xử lý phần còn lại.
        window.addEventListener('message', (event) => {
            const data = event.data;
            if (!data || data.source !== 'TIEN_NGHICH_AUTO_HUD') return;
            if (data.action === 'LICENSE_CONFIG') { licenseConfigure(data); return; }
            if (data.action === 'REQUEST_LICENSE_STATUS') { licensePush(); return; }
            if (lic.bundleReady) return;
            if (data.action === 'TOGGLE_AUTO' && data.running) {
                // Chưa có tính năng: chờ kích hoạt + tải xong rồi chạy lại đúng yêu cầu này (cùng cơ chế với cổng trong game-bridge.js).
                let block = licenseGate();
                if (!block) block = { pending: true, message: 'Đang tải tính năng…' };
                if (block.pending) {
                    const tries = (data.__licTries || 0) + 1;
                    if (tries <= LICENSE_GATE_MAX_TRIES) { setTimeout(() => window.postMessage(Object.assign({}, data, { __licTries: tries }), '*'), 1000); return; }
                    block = { message: '🔒 Chưa tải được tính năng (máy chủ không phản hồi). Thử lại sau.' };
                }
                CONFIG.running = false;
                try { window.top.postMessage({ source: 'TIEN_NGHICH_AUTO_GAME', action: 'AUTO_FINISHED', message: block.message }, '*'); } catch (e) { }
            }
        });

/*@BLOCK-END*/
    }
})();
